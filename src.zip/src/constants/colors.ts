export const COLORS = {
  background: "#F5F7FA",
  surface: "#FFFFFF",
  primary: "#00A859",
  primaryDark: "#00894A",
  text: "#172033",
  muted: "#7A8499",
  border: "#E6EAF0",
  parentSoft: "#E8F8F0",
  childSoft: "#EAF3FF",
  danger: "#F05252",
} as const;
