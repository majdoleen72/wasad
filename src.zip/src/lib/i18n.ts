export type Lang = "en" | "ar";

export const dict = {
  // brand / generic
  appName: { en: "WASD", ar: "وسد" },
  tagline: { en: "Learn by Living", ar: "تعلّم بالتجربة" },
  continue: { en: "Continue", ar: "متابعة" },
  back: { en: "Back", ar: "رجوع" },
  sar: { en: "SAR", ar: "ريال" },
  level: { en: "Level", ar: "المستوى" },
  xp: { en: "XP", ar: "نقاط" },
  day: { en: "day", ar: "يوم" },
  days: { en: "days", ar: "أيام" },
  done: { en: "Done", ar: "تم" },
  all: { en: "All", ar: "الكل" },

  // role select

  chooseSub: {
    en: "Pick your adventure to get started",
    ar: "اختر مغامرتك لتبدأ",
  },
  child: { en: "Kid", ar: "طفل" },
  childDesc: { en: "Earn, save & go on quests", ar: "اربح، ادّخر، وخض المهام" },
  parent: { en: "Parent", ar: "ولي الأمر" },
  parentDesc: { en: "Guide & approve", ar: "الإشراف والموافقة " },
  org: { en: "Organization", ar: "مؤسسة" },
  orgDesc: {
    en: "Manage groups (coming soon)",
    ar: "إدارة المجموعات (قريباً)",
  },
  comingSoon: { en: "Coming soon", ar: "قريباً" },

  // welcome
  helloName: { en: "Hi, Layla!", ar: "أهلاً يا ليلى!" },
  welcomeMsg: {
    en: "You have 3 new quests today. Let's earn some rewards together!",
    ar: "لديك ٣ مهام جديدة اليوم. لنربح المكافآت معاً!",
  },
  todaysStreak: { en: "Today's streak", ar: "سلسلة اليوم" },
  startJourney: { en: "Continue Journey", ar: "أكمل المغامرة" },
  claimReward: { en: "Claim daily reward", ar: "استلم مكافأة اليوم" },

  // nav
  home: { en: "Home", ar: "الرئيسية" },
  wallet: { en: "Wallet", ar: "المحفظة" },
  quests: { en: "Quests", ar: "المهام" },
  goals: { en: "Goals", ar: "الأهداف" },
  pet: { en: "Pet", ar: "الصديق" },
  stories: { en: "Stories", ar: "القصص" },
  profile: { en: "Profile", ar: "الملف" },

  // home
  balance: { en: "My Balance", ar: "رصيدي" },
  todaysMissions: { en: "Today's Missions", ar: "مهام اليوم" },
  currentGoal: { en: "Current Goal", ar: "هدفي الحالي" },
  quickActions: { en: "Quick Actions", ar: "إجراءات سريعة" },
  myAchievements: { en: "Achievements", ar: "الإنجازات" },
  seeAll: { en: "See all", ar: "عرض الكل" },
  addMoney: { en: "Add", ar: "إضافة" },
  save: { en: "Save", ar: "ادّخار" },
  spend: { en: "Spend", ar: "إنفاق" },
  scan: { en: "AR Scan", ar: "مسح" },

  // wallet
  treasureChest: { en: "My Treasure Chest", ar: "صندوق كنزي" },
  available: { en: "Available", ar: "المتاح" },
  savings: { en: "Savings", ar: "الادّخار" },
  locked: { en: "Locked", ar: "مقفل" },
  rewardsEarned: { en: "Rewards earned", ar: "المكافآت" },
  weekly: { en: "This week", ar: "هذا الأسبوع" },
  monthly: { en: "This month", ar: "هذا الشهر" },
  transactions: { en: "Transaction History", ar: "سجل المعاملات" },
  addCoins: { en: "Add coins", ar: "أضف عملات" },
  coinAdded: { en: "Amazing! You earned", ar: "رائع! لقد ربحت" },
  closerGoal: {
    en: "You're one step closer to your goal!",
    ar: "أنت أقرب خطوة إلى هدفك!",
  },

  // quests
  questsTitle: { en: "Real-World Quests", ar: "مهام الحياة" },
  questsSub: {
    en: "Finish missions to earn coins",
    ar: "أنجز المهام لتربح العملات",
  },
  active: { en: "Active", ar: "النشطة" },
  completed: { en: "Completed", ar: "المكتملة" },
  accept: { en: "Accept quest", ar: "اقبل المهمة" },
  uploadProof: { en: "Upload proof", ar: "ارفع الإثبات" },
  aiVerifying: { en: "AI is checking…", ar: "الذكاء يتحقق…" },
  aiMatch: { en: "Match", ar: "تطابق" },
  recommendApprove: {
    en: "Looks completed. Sent to parent.",
    ar: "يبدو مكتملاً. أُرسل لولي الأمر.",
  },
  reward: { en: "Reward", ar: "المكافأة" },
  due: { en: "Due", ar: "الموعد" },

  // goals
  goalsTitle: { en: "Saving Goals", ar: "أهداف الادّخار" },
  goalsSub: {
    en: "Dream it, save for it, get it!",
    ar: "احلم، ادّخر، واحصل عليه!",
  },
  newGoal: { en: "New goal", ar: "هدف جديد" },
  target: { en: "Target", ar: "المبلغ المطلوب" },
  saved: { en: "Saved", ar: "المدّخر" },
  remaining: { en: "Remaining", ar: "المتبقي" },
  perWeek: { en: "/week", ar: "/أسبوع" },
  weeksLeft: { en: "weeks to go", ar: "أسابيع متبقية" },
  addToGoal: { en: "Add to goal", ar: "أضف للهدف" },
  aiPlan: { en: "AI plan", ar: "خطة الذكاء" },

  // pet
  petTitle: { en: "My Buddy", ar: "صديقي" },
  happiness: { en: "Happiness", ar: "السعادة" },
  energy: { en: "Energy", ar: "الطاقة" },
  friendship: { en: "Friendship", ar: "الصداقة" },
  feed: { en: "Play", ar: "العب" },
  evolution: { en: "Evolution", ar: "التطور" },
  wardrobe: { en: "Wardrobe", ar: "الإكسسوارات" },
  unlocked: { en: "Unlocked", ar: "مفتوح" },
  locked2: { en: "Locked", ar: "مقفل" },

  // stories
  storiesTitle: { en: "Money Stories", ar: "قصص المال" },
  storiesSub: {
    en: "Fun tales that teach smart money habits",
    ar: "حكايات ممتعة تعلّم عادات المال الذكية",
  },
  read: { en: "Read", ar: "اقرأ" },
  newStory: { en: "Generate a new story", ar: "أنشئ قصة جديدة" },
  minRead: { en: "min read", ar: "دقيقة قراءة" },

  // profile
  myProfile: { en: "My Profile", ar: "ملفي" },
  language: { en: "Language", ar: "اللغة" },
  totalEarned: { en: "Total earned", ar: "إجمالي الأرباح" },
  goalsDone: { en: "Goals done", ar: "أهداف مكتملة" },
  badges: { en: "Badges", ar: "الأوسمة" },
  switchRole: { en: "Switch user", ar: "تغيير المستخدم" },

  // companion
  companionTip: {
    en: "Great job saving today! Keep it up and your bike is almost yours.",
    ar: "أحسنت الادّخار اليوم! واصل وستحصل على دراجتك قريباً.",
  },
} as const;

export type DictKey = keyof typeof dict;

export function t(key: DictKey, lang: Lang): string {
  return dict[key][lang];
}
