import type { Lang } from './i18n'

type Bi = { en: string; ar: string }

export type Quest = {
  id: string
  title: Bi
  category: Bi
  icon: string // lucide icon name
  reward: number
  difficulty: 'easy' | 'medium' | 'hard'
  due: Bi
  color: 'sky' | 'mint' | 'sunny' | 'coral' | 'lavender' | 'pink'
  status: 'active' | 'verifying' | 'completed'
}

export type Goal = {
  id: string
  title: Bi
  image: string
  target: number
  saved: number
  perWeek: number
  color: 'sky' | 'mint' | 'sunny' | 'coral' | 'lavender' | 'pink'
}

export type Achievement = {
  id: string
  title: Bi
  icon: string
  unlocked: boolean
  color: 'sky' | 'mint' | 'sunny' | 'coral' | 'lavender' | 'pink' | 'gold'
}

export type Txn = {
  id: string
  label: Bi
  amount: number
  kind: 'earn' | 'spend' | 'save'
  icon: string
  when: Bi
}

export type Story = {
  id: string
  title: Bi
  blurb: Bi
  minutes: number
  image: string
  color: 'sky' | 'mint' | 'sunny' | 'coral' | 'lavender' | 'pink'
}

export const child = {
  name: { en: 'Layla', ar: 'ليلى' },
  level: 7,
  xp: 640,
  xpForNext: 800,
  streak: 5,
  balance: 185,
  savings: 240,
  locked: 60,
  weekly: 65,
  monthly: 310,
  totalEarned: 1240,
}

export const quests: Quest[] = [
  {
    id: 'q1',
    title: { en: 'Clean your room', ar: 'نظّف غرفتك' },
    category: { en: 'Cleaning', ar: 'تنظيف' },
    icon: 'Sparkles',
    reward: 10,
    difficulty: 'easy',
    due: { en: 'Today', ar: 'اليوم' },
    color: 'sky',
    status: 'active',
  },
  {
    id: 'q2',
    title: { en: 'Read 20 pages', ar: 'اقرأ ٢٠ صفحة' },
    category: { en: 'Reading', ar: 'قراءة' },
    icon: 'BookOpen',
    reward: 15,
    difficulty: 'medium',
    due: { en: 'Today', ar: 'اليوم' },
    color: 'lavender',
    status: 'active',
  },
  {
    id: 'q3',
    title: { en: 'Help prepare dinner', ar: 'ساعد في تحضير العشاء' },
    category: { en: 'Helping Parents', ar: 'مساعدة الأهل' },
    icon: 'ChefHat',
    reward: 20,
    difficulty: 'medium',
    due: { en: 'Tomorrow', ar: 'غداً' },
    color: 'coral',
    status: 'active',
  },
  {
    id: 'q4',
    title: { en: 'Drink enough water', ar: 'اشرب ماءً كافياً' },
    category: { en: 'Healthy Habits', ar: 'عادات صحية' },
    icon: 'Droplets',
    reward: 5,
    difficulty: 'easy',
    due: { en: 'Today', ar: 'اليوم' },
    color: 'mint',
    status: 'active',
  },
  {
    id: 'q5',
    title: { en: 'Complete homework', ar: 'أنهِ الواجب' },
    category: { en: 'Homework', ar: 'الواجبات' },
    icon: 'GraduationCap',
    reward: 15,
    difficulty: 'hard',
    due: { en: 'Done', ar: 'منجز' },
    color: 'sunny',
    status: 'completed',
  },
  {
    id: 'q6',
    title: { en: 'Morning exercise', ar: 'تمارين الصباح' },
    category: { en: 'Exercise', ar: 'رياضة' },
    icon: 'Dumbbell',
    reward: 10,
    difficulty: 'easy',
    due: { en: 'Done', ar: 'منجز' },
    color: 'pink',
    status: 'completed',
  },
]

export const goals: Goal[] = [
  {
    id: 'g1',
    title: { en: 'Mountain Bike', ar: 'دراجة جبلية' },
    image: '/goals/bike.png',
    target: 400,
    saved: 240,
    perWeek: 20,
    color: 'sky',
  },
  {
    id: 'g2',
    title: { en: 'Game Console', ar: 'جهاز ألعاب' },
    image: '/goals/console.png',
    target: 900,
    saved: 180,
    perWeek: 25,
    color: 'lavender',
  },
  {
    id: 'g3',
    title: { en: 'Football', ar: 'كرة قدم' },
    image: '/goals/football.png',
    target: 80,
    saved: 65,
    perWeek: 10,
    color: 'mint',
  },
]

export const achievements: Achievement[] = [
  { id: 'a1', title: { en: 'First Savings', ar: 'أول ادّخار' }, icon: 'PiggyBank', unlocked: true, color: 'mint' },
  { id: 'a2', title: { en: '7-Day Streak', ar: 'سلسلة ٧ أيام' }, icon: 'Flame', unlocked: true, color: 'coral' },
  { id: 'a3', title: { en: 'Reading Champ', ar: 'بطل القراءة' }, icon: 'BookOpen', unlocked: true, color: 'lavender' },
  { id: 'a4', title: { en: 'Smart Shopper', ar: 'متسوّق ذكي' }, icon: 'ShoppingBag', unlocked: true, color: 'sky' },
  { id: 'a5', title: { en: 'Budget Master', ar: 'سيّد الميزانية' }, icon: 'Wallet', unlocked: false, color: 'sunny' },
  { id: 'a6', title: { en: 'Investor', ar: 'مستثمر' }, icon: 'TrendingUp', unlocked: false, color: 'gold' },
  { id: 'a7', title: { en: 'Goal Crusher', ar: 'محقق الأهداف' }, icon: 'Trophy', unlocked: false, color: 'pink' },
  { id: 'a8', title: { en: 'Family Helper', ar: 'مساعد العائلة' }, icon: 'HeartHandshake', unlocked: false, color: 'mint' },
]

export const txns: Txn[] = [
  { id: 't1', label: { en: 'Cleaned room', ar: 'تنظيف الغرفة' }, amount: 10, kind: 'earn', icon: 'Sparkles', when: { en: '2h ago', ar: 'قبل ساعتين' } },
  { id: 't2', label: { en: 'Saved to bike', ar: 'ادّخار للدراجة' }, amount: 20, kind: 'save', icon: 'PiggyBank', when: { en: 'Yesterday', ar: 'أمس' } },
  { id: 't3', label: { en: 'Allowance', ar: 'مصروف' }, amount: 50, kind: 'earn', icon: 'Gift', when: { en: 'Sun', ar: 'الأحد' } },
  { id: 't4', label: { en: 'Bought stickers', ar: 'شراء ملصقات' }, amount: 8, kind: 'spend', icon: 'ShoppingBag', when: { en: 'Sat', ar: 'السبت' } },
  { id: 't5', label: { en: 'Reading reward', ar: 'مكافأة القراءة' }, amount: 15, kind: 'earn', icon: 'BookOpen', when: { en: 'Fri', ar: 'الجمعة' } },
]

export const stories: Story[] = [
  {
    id: 's1',
    title: { en: 'The Coin That Grew', ar: 'العملة التي كبرت' },
    blurb: { en: 'Zaid learns how saving a little every day adds up to something big.', ar: 'يتعلّم زيد كيف يتحول الادّخار القليل يومياً إلى شيء كبير.' },
    minutes: 4,
    image: '/stories/coin-tree.png',
    color: 'mint',
  },
  {
    id: 's2',
    title: { en: 'Needs vs Wants Island', ar: 'جزيرة الحاجة والرغبة' },
    blurb: { en: 'A treasure map that only opens for smart spenders.', ar: 'خريطة كنز لا تُفتح إلا للمنفقين الأذكياء.' },
    minutes: 6,
    image: '/stories/island.png',
    color: 'sky',
  },
  {
    id: 's3',
    title: { en: 'The Patient Planet', ar: 'الكوكب الصبور' },
    blurb: { en: 'Why waiting a little can make your reward much bigger.', ar: 'لماذا الانتظار قليلاً يجعل مكافأتك أكبر بكثير.' },
    minutes: 5,
    image: '/stories/planet.png',
    color: 'lavender',
  },
]

export function colorClasses(c: string) {
  const map: Record<string, { bg: string; soft: string; text: string; ring: string }> = {
    sky: { bg: 'bg-sky', soft: 'bg-sky-soft', text: 'text-sky', ring: 'ring-sky' },
    mint: { bg: 'bg-mint', soft: 'bg-mint-soft', text: 'text-mint', ring: 'ring-mint' },
    sunny: { bg: 'bg-sunny', soft: 'bg-sunny-soft', text: 'text-sunny', ring: 'ring-sunny' },
    coral: { bg: 'bg-coral', soft: 'bg-coral-soft', text: 'text-coral', ring: 'ring-coral' },
    lavender: { bg: 'bg-lavender', soft: 'bg-lavender-soft', text: 'text-lavender', ring: 'ring-lavender' },
    pink: { bg: 'bg-pink', soft: 'bg-pink-soft', text: 'text-pink', ring: 'ring-pink' },
    gold: { bg: 'bg-gold', soft: 'bg-sunny-soft', text: 'text-gold', ring: 'ring-gold' },
  }
  return map[c] ?? map.sky
}

export function bi(v: Bi, lang: Lang) {
  return v[lang]
}
