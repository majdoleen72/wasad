import { Pressable, StyleSheet, Text } from "react-native";
import { COLORS } from "@/constants/colors";

type Props = {
  title: string;
  onPress: () => void;
  variant?: "primary" | "secondary";
};

export function PrimaryButton({
  title,
  onPress,
  variant = "primary",
}: Props) {
  const isPrimary = variant === "primary";

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        isPrimary ? styles.primary : styles.secondary,
        pressed && styles.pressed,
      ]}
    >
      <Text
        style={[
          styles.text,
          isPrimary ? styles.primaryText : styles.secondaryText,
        ]}
      >
        {title}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    width: "100%",
    minHeight: 56,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  primary: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  secondary: {
    backgroundColor: COLORS.surface,
    borderColor: COLORS.border,
  },
  text: {
    fontSize: 17,
    fontWeight: "700",
  },
  primaryText: {
    color: "#FFFFFF",
  },
  secondaryText: {
    color: COLORS.text,
  },
  pressed: {
    opacity: 0.82,
  },
});
