import { router, usePathname } from "expo-router";
import { Image, Pressable, Text, View } from "react-native";

export function BottomNav() {
  const pathname = usePathname();

  const tabs = [
    {
      title: "Pet",
      image: require("../../../assts/images/pet-logo.png"),
      route: "/child/pet",
    },
    {
      title: "Tasks",
      image: require("../../../assts/images/icons8-task-64-removebg-preview.png"),
      route: "/child/tasks",
    },
    {
      title: "Home",
      image: require("../../../assts/images/home-logo.png"),
      route: "/child",
    },
    {
      title: "Wallet",
      image: require("../../../assts/images/image-removebg-preview (16).png"),
      route: "/child/wallet",
    },
    {
      title: "Stories",
      image: require("../../../assts/images/read-logo.png"),
      route: "/child/stories",
    },
  ];

  return (
    <View
      style={{
        height: 95,
        backgroundColor: "#FFFFFF",
        borderTopLeftRadius: 28,
        borderTopRightRadius: 28,
        flexDirection: "row",
        justifyContent: "space-around",
        alignItems: "center",
        shadowColor: "#000",
        shadowOpacity: 0.08,
        shadowRadius: 10,
        elevation: 12,
      }}
    >
      {tabs.map((tab) => (
        <NavItem key={tab.route} tab={tab} pathname={pathname} />
      ))}
    </View>
  );
}

// 👇 يكون خارج BottomNav
function NavItem({
  tab,
  pathname,
}: {
  tab: {
    title: string;
    image: any;
    route: string;
  };
  pathname: string;
}) {
  const active = pathname === tab.route;

  return (
    <Pressable
      onPress={() => router.replace(tab.route as any)}
      style={{
        flex: 1,
        alignItems: "center",
        marginTop: active ? -32 : 0,
      }}
    >
      <View
        style={{
          width: active ? 56 : 48,
          height: active ? 56 : 48,
          borderRadius: 28,
          backgroundColor: active ? "rgb(164,190,255)" : "transparent",
          justifyContent: "center",
          alignItems: "center",
          shadowColor: "#5B5CEB",
          shadowOpacity: active ? 0.35 : 0,
          shadowRadius: 10,
          elevation: active ? 10 : 0,
        }}
      >
        <Image
          source={tab.image}
          style={{
            width: active ? 34 : 26,
            height: active ? 34 : 26,
            resizeMode: "contain",
            opacity: active ? 1 : 0.55,
          }}
        />
      </View>

      <Text
        style={{
          marginTop: 6,
          fontSize: 12,
          fontWeight: "700",
          color: active ? "#5B5CEB" : "#94A3B8",
        }}
      >
        {tab.title}
      </Text>
    </Pressable>
  );
}
