import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";

import { type DictKey, type Lang, t as translate } from "@/lib/i18n";
import { child as childSeed } from "@/lib/wasd-data";

type Stage = "role" | "welcome" | "app";

type Role = "child" | "parent" | "org" | null;

type Celebration = {
  amount: number;
  message: string;
} | null;

type Ctx = {
  lang: Lang;
  dir: "ltr" | "rtl";
  setLang: (l: Lang) => void;
  toggleLang: () => void;
  t: (key: DictKey) => string;

  stage: Stage;
  setStage: (s: Stage) => void;

  role: Role;
  setRole: (r: Role) => void;

  balance: number;
  savings: number;

  earn: (amount: number, message?: string) => void;
  saveToGoal: (amount: number) => void;

  celebration: Celebration;
  clearCelebration: () => void;

  xp: number;
  level: number;

  showLevelUp: boolean;
  lastLevel: number;
  hideLevelUp: () => void;

  achievements: any[];

  ownedItems: number[];
  buyItem: (id: number, price: number) => boolean;

  equippedHat: string;
  setEquippedHat: (hat: string) => void;
};

const AppContext = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  const [stage, setStage] = useState<Stage>("role");
  const [role, setRole] = useState<Role>(null);

  const [balance, setBalance] = useState(childSeed.balance);
  const [savings, setSavings] = useState(childSeed.savings);

  const [celebration, setCelebration] = useState<Celebration>(null);

  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);

  const [ownedItems, setOwnedItems] = useState<number[]>([]);

  const [equippedHat, setEquippedHat] = useState("🧢");

  const buyItem = useCallback(
    (id: number, price: number) => {
      if (balance < price) return false;

      if (ownedItems.includes(id)) return false;

      setBalance((b) => b - price);

      setOwnedItems((prev) => [...prev, id]);

      return true;
    },
    [balance, ownedItems],
  );

  const [achievements, setAchievements] = useState([
    {
      id: 1,
      title: "First Quest",
      icon: "🥉",
      unlocked: false,
    },
    {
      id: 2,
      title: "100 Coins",
      icon: "💰",
      unlocked: false,
    },
    {
      id: 3,
      title: "Level 5",
      icon: "⭐",
      unlocked: false,
    },
  ]);

  const [showLevelUp, setShowLevelUp] = useState(false);
  const [lastLevel, setLastLevel] = useState(1);

  const dir = lang === "ar" ? "rtl" : "ltr";

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
  }, []);

  const toggleLang = useCallback(() => {
    setLangState((p) => (p === "en" ? "ar" : "en"));
  }, []);

  const t = useCallback((key: DictKey) => translate(key, lang), [lang]);

  const hideLevelUp = useCallback(() => {
    setShowLevelUp(false);
  }, []);

  const earn = useCallback(
    (amount: number, message?: string) => {
      setBalance((b) => b + amount);

      setAchievements((prev) =>
        prev.map((a) => {
          if (a.id === 1)
            return {
              ...a,
              unlocked: true,
            };

          return a;
        }),
      );

      setBalance((b) => {
        const newBalance = b + amount;

        if (newBalance >= 100) {
          setAchievements((prev) =>
            prev.map((a) => (a.id === 2 ? { ...a, unlocked: true } : a)),
          );
        }

        return newBalance;
      });

      setXp((currentXp) => {
        const totalXp = currentXp + amount;
        const needed = level * 20;

        if (totalXp >= needed) {
          const newLevel = level + 1;

          setLevel(newLevel);
          setLastLevel(newLevel);

          setShowLevelUp(true);

          return totalXp - needed;
        }

        return totalXp;
      });

      setCelebration({
        amount,
        message: message ?? (lang === "ar" ? "أحسنت!" : "Great job!"),
      });
    },
    [level, lang],
  );

  const saveToGoal = useCallback((amount: number) => {
    setBalance((b) => Math.max(0, b - amount));
    setSavings((s) => s + amount);
  }, []);

  const clearCelebration = useCallback(() => {
    setCelebration(null);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      lang,
      dir,
      setLang,
      toggleLang,
      t,

      stage,
      setStage,

      role,
      setRole,

      balance,
      savings,

      earn,
      saveToGoal,

      celebration,
      clearCelebration,

      xp,
      level,

      showLevelUp,
      lastLevel,
      hideLevelUp,

      achievements,

      ownedItems,
      buyItem,

      equippedHat,
      setEquippedHat,
    }),
    [
      lang,
      dir,
      stage,
      role,
      balance,
      savings,
      celebration,
      xp,
      level,
      showLevelUp,
      lastLevel,
      earn,
      saveToGoal,
      clearCelebration,
      hideLevelUp,
      achievements,
      ownedItems,
      buyItem,
      equippedHat,
      setEquippedHat,
      t,
      toggleLang,
      setLang,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);

  if (!ctx) {
    throw new Error("useApp must be used within AppProvider");
  }

  return ctx;
}
