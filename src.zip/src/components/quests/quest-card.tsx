import { Image, Pressable, Text, View } from "react-native";
import { Quest } from "./quest-data";

type Props = {
  quest: Quest;
  phase: string;
  onAccept: () => void;
  onUpload: () => void;
  onClaim: () => void;
};

export default function QuestCard({
  quest,
  phase,
  onAccept,
  onUpload,
  onClaim,
}: Props) {
  const progress = (quest.progress / quest.total) * 100;

  const difficultyColor = {
    easy: "#22c55e",
    medium: "#f59e0b",
    hard: "#ef4444",
  };

  return (
    <View
      style={{
        backgroundColor: "white",
        borderRadius: 24,
        padding: 20,
        marginBottom: 18,
      }}
    >
      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <View
          style={{
            width: 60,
            height: 60,
            borderRadius: 18,
            backgroundColor: quest.color + "20",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Image
            source={quest.icon}
            style={{
              width: 34,
              height: 34,
              resizeMode: "contain",
            }}
          />
        </View>

        <View
          style={{
            flex: 1,
            marginLeft: 15,
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "bold",
            }}
          >
            {quest.title}
          </Text>

          <View
            style={{
              flexDirection: "row",
              marginTop: 6,
            }}
          >
            <View
              style={{
                backgroundColor: difficultyColor[quest.difficulty],
                borderRadius: 20,
                paddingHorizontal: 10,
                paddingVertical: 3,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontWeight: "bold",
                  fontSize: 11,
                }}
              >
                {quest.difficulty.toUpperCase()}
              </Text>
            </View>

            <Text
              style={{
                marginLeft: 8,
                color: "gray",
              }}
            >
              {quest.category}
            </Text>
          </View>
        </View>

        <View
          style={{
            backgroundColor: "#fef3c7",
            borderRadius: 20,
            paddingHorizontal: 12,
            paddingVertical: 8,
          }}
        >
          <Text
            style={{
              fontWeight: "bold",
            }}
          >
            💰 {quest.reward}
          </Text>
        </View>
      </View>

      {/* Progress */}
      <View
        style={{
          marginTop: 20,
        }}
      >
        <View
          style={{
            height: 10,
            backgroundColor: "#e5e7eb",
            borderRadius: 10,
            overflow: "hidden",
          }}
        >
          <View
            style={{
              width: `${progress}%`,
              height: "100%",
              backgroundColor: quest.color,
            }}
          />
        </View>

        <Text
          style={{
            marginTop: 8,
            color: "gray",
          }}
        >
          {quest.progress}/{quest.total}
        </Text>
      </View>

      {/* Buttons */}
      {phase === "idle" && (
        <Pressable
          onPress={onAccept}
          style={{
            marginTop: 18,
            backgroundColor: quest.color,
            padding: 14,
            borderRadius: 16,
          }}
        >
          <Text
            style={{
              textAlign: "center",
              color: "white",
              fontWeight: "bold",
            }}
          >
            Accept Quest
          </Text>
        </Pressable>
      )}

      {phase === "accepted" && (
        <Pressable
          onPress={onUpload}
          style={{
            marginTop: 18,
            backgroundColor: "#111827",
            padding: 14,
            borderRadius: 16,
          }}
        >
          <Text
            style={{
              color: "white",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            📷 Upload Proof
          </Text>
        </Pressable>
      )}

      {phase === "verifying" && (
        <View
          style={{
            marginTop: 18,
            backgroundColor: "#f1f5f9",
            borderRadius: 16,
            padding: 14,
          }}
        >
          <Text
            style={{
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            🤖 AI Verifying...
          </Text>
        </View>
      )}

      {phase === "verified" && (
        <>
          <View
            style={{
              marginTop: 18,
              backgroundColor: "#dcfce7",
              padding: 14,
              borderRadius: 16,
            }}
          >
            <Text
              style={{
                color: "#15803d",
                fontWeight: "bold",
              }}
            >
              ✅ 94% AI Match
            </Text>

            <Text
              style={{
                marginTop: 5,
                color: "#166534",
              }}
            >
              Recommended for approval
            </Text>
          </View>

          <Pressable
            onPress={onClaim}
            style={{
              marginTop: 15,
              backgroundColor: "#22c55e",
              padding: 14,
              borderRadius: 16,
            }}
          >
            <Text
              style={{
                color: "white",
                textAlign: "center",
                fontWeight: "bold",
              }}
            >
              Claim Reward 🎉
            </Text>
          </Pressable>
        </>
      )}
    </View>
  );
}
