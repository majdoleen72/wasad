export type QuestStatus = "active" | "completed";

export type QuestPhase = "idle" | "accepted" | "verifying" | "verified";

export type Quest = {
  id: number;
  title: string;
  category: string;
  difficulty: "easy" | "medium" | "hard";
  reward: number;
  xp: number;
  progress: number;
  total: number;
  icon: any;
  color: string;
  status: QuestStatus;
};

export const quests: Quest[] = [
  {
    id: 1,
    title: "Read Saving Story",
    category: "Learning",
    difficulty: "easy",
    reward: 20,
    xp: 10,
    progress: 0,
    total: 1,
    icon: require("../../../assts/images/chest.png"),
    color: "#38bdf8",
    status: "active",
  },

  {
    id: 2,
    title: "Feed Buddy",
    category: "Pet",
    difficulty: "easy",
    reward: 10,
    xp: 5,
    progress: 0,
    total: 1,
    icon: require("../../../assts/images/pet.png"),
    color: "#22c55e",
    status: "active",
  },

  {
    id: 3,
    title: "Save 50 Coins",
    category: "Saving",
    difficulty: "medium",
    reward: 40,
    xp: 20,
    progress: 20,
    total: 50,
    icon: require("../../../assts/images/bike.png"),
    color: "#f59e0b",
    status: "active",
  },

  {
    id: 4,
    title: "Buy First Item",
    category: "Shop",
    difficulty: "hard",
    reward: 60,
    xp: 30,
    progress: 0,
    total: 1,
    icon: require("../../../assts/images/football.png"),
    color: "#ef4444",
    status: "active",
  },
];
