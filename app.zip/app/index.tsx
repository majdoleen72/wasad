import { router } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { PrimaryButton } from "@/components/primary-button";
import { COLORS } from "@/constants/colors";
import { SPACING } from "@/constants/spacing";

export default function WelcomeScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>وَسَد</Text>
        </View>

        <View style={styles.content}>
          <Text style={styles.title}>أهلًا بك في وَسَد</Text>
          <Text style={styles.subtitle}>
            منصة تربوية مالية تساعد الأسرة والطفل على التعلم والادخار
            بطريقة ممتعة.
          </Text>
        </View>

        <View style={styles.actions}>
          <PrimaryButton
            title="الدخول كولي أمر"
            onPress={() => router.push("/parent" as any)}
          />

          <PrimaryButton
            title="الدخول كطفل"
            variant="secondary"
            onPress={() => router.push("/child" as any)}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.xl,
    justifyContent: "space-between",
  },
  logo: {
    width: 92,
    height: 92,
    alignSelf: "center",
    borderRadius: 28,
    backgroundColor: COLORS.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  logoText: {
    color: "#FFFFFF",
    fontSize: 26,
    fontWeight: "900",
  },
  content: {
    alignItems: "center",
    paddingHorizontal: SPACING.sm,
  },
  title: {
    color: COLORS.text,
    fontSize: 30,
    fontWeight: "900",
    textAlign: "center",
  },
  subtitle: {
    marginTop: SPACING.md,
    color: COLORS.muted,
    fontSize: 16,
    lineHeight: 26,
    textAlign: "center",
  },
  actions: {
    gap: SPACING.md,
  },
});
