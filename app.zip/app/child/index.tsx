import { BottomNav } from "@/components/child/bottom-nav";
import { useApp } from "@/components/providers/app-provider";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import {
    BarChart3,
    BookOpen,
    Flame,
    Lock,
    MessageCircle,
    PiggyBank,
    Plus,
    ShieldCheck,
    ShoppingBag,
    Star,
    Target,
    Wallet,
} from "lucide-react-native";

import { useRef, useState } from "react";
import {
    Animated,
    Image,
    Modal,
    Pressable,
    ScrollView,
    Text,
    View,
} from "react-native";
import Svg, { Circle } from "react-native-svg";

function CircularProgress({
  value,
  radius,
  activeStrokeWidth,
  inActiveStrokeWidth,
  activeStrokeColor,
  inActiveStrokeColor,
  children,
}: {
  value: number;
  radius: number;
  activeStrokeWidth: number;
  inActiveStrokeWidth: number;
  activeStrokeColor: string;
  inActiveStrokeColor: string;
  progressValueColor?: string;
  children?: React.ReactNode;
}) {
  const size = radius * 2 + activeStrokeWidth * 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, value));
  const dashOffset = circumference * (1 - clamped / 100);

  return (
    <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      <Svg width={size} height={size} style={{ position: "absolute", transform: [{ rotate: "-90deg" }] }}>
        <Circle cx={center} cy={center} r={radius} stroke={inActiveStrokeColor} strokeWidth={inActiveStrokeWidth} fill="none" />
        <Circle cx={center} cy={center} r={radius} stroke={activeStrokeColor} strokeWidth={activeStrokeWidth} fill="none" strokeLinecap="round" strokeDasharray={`${circumference} ${circumference}`} strokeDashoffset={dashOffset} />
      </Svg>
      {children}
    </View>
  );
}

type Mission = {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  rewardValue: number;
  color: string;
  completed: boolean;
};

type Achievement = {
  id: string;
  title: string;
  description: string;
  icon: (color: string) => React.ReactNode;
  color: string;
  unlockedColor: string;
  unlocked: boolean;
};

export default function Home() {
  const { balance, level, xp } = useApp();

  const xpNeeded = level * 20;
  const progress = (xp / xpNeeded) * 100;
  const [showActions, setShowActions] = useState(false);

  // Current goal — progress is now calculated from real numbers instead of a fixed value
  const goalCurrent = 680;
  const goalTarget = 1000;
  const goalProgress = Math.min(
    100,
    Math.round((goalCurrent / goalTarget) * 100),
  );

  const [missions, setMissions] = useState<Mission[]>([
    {
      id: "clean-room",
      emoji: "🧹",
      title: "Clean your room",
      subtitle: "Cleaning",
      rewardValue: 10,
      color: "#DCFCE7",
      completed: true,
    },
    {
      id: "read-pages",
      emoji: "📖",
      title: "Read 20 pages",
      subtitle: "Reading",
      rewardValue: 15,
      color: "#DBEAFE",
      completed: false,
    },
    {
      id: "prepare-dinner",
      emoji: "🥗",
      title: "Help prepare dinner",
      subtitle: "Helping Parents",
      rewardValue: 20,
      color: "#FEF3C7",
      completed: false,
    },
  ]);

  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: "first-savings",
      title: "First Savings",
      description: "Saved money for the very first time.",
      icon: (color) => <PiggyBank size={22} color={color} />,
      color: "#DCFCE7",
      unlockedColor: "#22A06B",
      unlocked: true,
    },
    {
      id: "streak-7",
      title: "7-Day Streak",
      description: "Completed a mission every day for 7 days in a row.",
      icon: (color) => <Flame size={22} color={color} />,
      color: "#FFE1EC",
      unlockedColor: "#F0538E",
      unlocked: true,
    },
    {
      id: "reading-champ",
      title: "Reading Champ",
      description: "Complete 10 reading missions to unlock this badge.",
      icon: (color) => <BookOpen size={22} color={color} />,
      color: "#EDEBFF",
      unlockedColor: "#5B5CEB",
      unlocked: false,
    },
    {
      id: "smart-shopper",
      title: "Smart Shopper",
      description: "Make your first purchase from the shop wisely.",
      icon: (color) => <ShoppingBag size={22} color={color} />,
      color: "#DBEAFE",
      unlockedColor: "#2C7FA8",
      unlocked: false,
    },
    {
      id: "badge-master",
      title: "Badge Master",
      description: "Unlock every other badge to earn this one.",
      icon: (color) => <ShieldCheck size={22} color={color} />,
      color: "#FFF3D6",
      unlockedColor: "#B4780A",
      unlocked: false,
    },
  ]);

  const [selectedAchievement, setSelectedAchievement] =
    useState<Achievement | null>(null);

  // Celebration toast shown when a mission is completed
  const [celebrationText, setCelebrationText] = useState("");
  const celebrationAnim = useRef(new Animated.Value(0)).current;

  const showCelebration = (text: string) => {
    setCelebrationText(text);
    Animated.sequence([
      Animated.timing(celebrationAnim, {
        toValue: 1,
        duration: 220,
        useNativeDriver: true,
      }),
      Animated.delay(1200),
      Animated.timing(celebrationAnim, {
        toValue: 0,
        duration: 220,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeMission = (mission: Mission) => {
    if (mission.completed) return;

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    setMissions((prev) =>
      prev.map((m) => (m.id === mission.id ? { ...m, completed: true } : m)),
    );

    showCelebration(`🎉 +${mission.rewardValue} SAR earned!`);
  };

  // Streak and badges count used by the new stat cards
  const streak = 3;
  const unlockedBadges = achievements.filter((a) => a.unlocked).length;

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#EEF7FF",
      }}
    >
      {/* Celebration toast */}
      <Animated.View
        pointerEvents="none"
        style={{
          position: "absolute",
          top: 60,
          left: 20,
          right: 20,
          zIndex: 50,
          alignItems: "center",
          opacity: celebrationAnim,
          transform: [
            {
              translateY: celebrationAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [-20, 0],
              }),
            },
          ],
        }}
      >
        <View
          style={{
            backgroundColor: "#0F172A",
            paddingHorizontal: 20,
            paddingVertical: 12,
            borderRadius: 20,
          }}
        >
          <Text style={{ color: "white", fontWeight: "900", fontSize: 14 }}>
            {celebrationText}
          </Text>
        </View>
      </Animated.View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 130,
        }}
      >
        {/* Header */}
        <View
          style={{
            marginTop: 25,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <View
              style={{
                width: 46,
                height: 46,
                borderRadius: 23,
                backgroundColor: "#FFFFFF",
                justifyContent: "center",
                alignItems: "center",
                overflow: "hidden",
                shadowColor: "#000",
                shadowOpacity: 0.1,
                shadowRadius: 8,
                shadowOffset: { width: 0, height: 3 },
                elevation: 4,
              }}
            >
              <Image
                source={require("../../assts/images/kide-girl.png")}
                style={{
                  width: 46,
                  height: 46,
                  borderRadius: 23,
                }}
              />
            </View>

            <View style={{ marginLeft: 10 }}>
              <Text
                style={{
                  color: "#64748B",
                  fontSize: 13,
                }}
              ></Text>

              <Text
                style={{
                  fontSize: 20,
                  fontWeight: "900",
                  color: "#0F172A",
                }}
              >
                Dana
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            {/* Notification pill */}
            <Pressable
              style={{
                width: 38,
                height: 38,
                borderRadius: 19,
                backgroundColor: "#EDEBFF",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <MessageCircle size={18} color="#5B5CEB" />
            </Pressable>
          </View>
        </View>

        {/* Buddy Card */}
        <Pressable
          onPress={() => router.push("/child/pet" as any)}
          style={{
            marginTop: 20,
            backgroundColor: "#E9DFFF",
            borderRadius: 26,
            paddingHorizontal: 20,
            paddingVertical: 18,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          {/* Pet */}
          <Image
            source={require("../../assts/images/pet.png")}
            style={{
              width: 95,
              height: 95,
              resizeMode: "contain",
              marginLeft: -8,
            }}
          />

          {/* Text */}
          <View
            style={{
              flex: 1,
              marginLeft: 14,
            }}
          >
            <Text
              style={{
                fontSize: 34,
                fontWeight: "900",
                color: "#6B4EFF",
              }}
            >
              Buddy
            </Text>

            <Text
              style={{
                marginTop: 6,
                fontSize: 13,
                lineHeight: 22,
                color: "#7C74A9",
              }}
            >
              Your adorable companion is here{"\n"}
              to make every moment special.
            </Text>
          </View>
        </Pressable>
        {/* Stats: Wallet, Goals, Streak, Badges — flat icon style, light backgrounds */}
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
            rowGap: 14,
            marginTop: 18,
          }}
        >
          <StatCard
            icon={<Wallet size={30} color="#3B82F6" />}
            title="Wallet"
            value={`${balance}`}
            bg="hsl(213, 100%, 92%)"
            valueColor="#136b97"
            onPress={() => router.push("/child/wallet" as any)}
          />

          <StatCard
            icon={<Target size={30} color="#F59E0B" />}
            title="Goals"
            value={`${level}`}
            bg="#faedd4"
            valueColor="#B4780A"
            onPress={() => router.push("/child/goals" as any)}
          />

          <StatCard
            icon={<BarChart3 size={30} color="#22A06B" />}
            title="Streak"
            value={`${streak}`}
            bg="#d2f9e2"
            valueColor="#16A34A"
          />

          <StatCard
            icon={<Star size={30} color="#F0538E" />}
            title="Level"
            value={`${unlockedBadges}`}
            bg="#fad9e3"
            valueColor="#F0538E"
          />
        </View>
        {/* Quick Actions */}
        <View
          style={{
            marginTop: 28,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 18,
            }}
          >
            <Text
              style={{
                fontSize: 22,
                fontWeight: "900",
                color: "#0F172A",
              }}
            >
              Quick Actions
            </Text>

            <Pressable>
              <Text
                style={{
                  color: "#5B5CEB",
                  fontWeight: "700",
                }}
              >
                See All
              </Text>
            </Pressable>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <CircleAction
              icon={<Plus size={28} color="white" />}
              title="More"
              color="#5B5CEB"
              onPress={() => setShowActions(true)}
            />

            <CircleAction
              icon={<Target size={26} color="#22A06B" />}
              title="Shop"
              color="#DCFCE7"
              onPress={() => router.push("/child/store" as any)}
            />

            <CircleAction
              icon={<BookOpen size={26} color="#B94A7C" />}
              title="Stories"
              color="#FCE7F3"
              onPress={() => router.push("/child/stories" as any)}
            />

            <CircleAction
              icon={<Wallet size={26} color="#195d7e" />}
              title="AI"
              color="#DBEAFE"
              onPress={() => router.push("/child/wallet" as any)}
            />
          </View>
        </View>

        {/* Today's Missions */}
        <View
          style={{
            marginTop: 30,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 14,
            }}
          >
            <Text
              style={{
                fontSize: 22,
                fontWeight: "900",
                color: "#0F172A",
              }}
            >
              Today's Missions
            </Text>

            <Pressable>
              <Text
                style={{
                  color: "#5B5CEB",
                  fontWeight: "700",
                }}
              >
                See All
              </Text>
            </Pressable>
          </View>

          {missions.map((mission) => (
            <MissionCard
              key={mission.id}
              mission={mission}
              onPress={() => completeMission(mission)}
            />
          ))}
        </View>

        {/* Current Goal */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginTop: 8,
            marginBottom: 12,
          }}
        >
          <Text
            style={{
              fontSize: 22,
              fontWeight: "900",
              color: "#0F172A",
            }}
          >
            Current Goal
          </Text>

          <Pressable onPress={() => router.push("/child/goals" as any)}>
            <Text
              style={{
                color: "#5B5CEB",
                fontWeight: "700",
              }}
            >
              See All
            </Text>
          </Pressable>
        </View>

        <Pressable
          onPress={() => router.push("/child/goals" as any)}
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 26,
            padding: 16,
            shadowColor: "#000",
            shadowOpacity: 0.06,
            shadowRadius: 12,
            shadowOffset: { width: 0, height: 5 },
            elevation: 5,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            {/* Progress Circle */}
            <CircularProgress
              value={goalProgress}
              radius={30}
              activeStrokeWidth={7}
              inActiveStrokeWidth={7}
              activeStrokeColor="#5B5CEB"
              inActiveStrokeColor="#ECECEC"
              progressValueColor="transparent"
            >
              <Image
                source={require("../../assts/images/console.png")}
                style={{
                  width: 28,
                  height: 28,
                  resizeMode: "contain",
                }}
              />
            </CircularProgress>

            {/* Goal Info */}
            <View
              style={{
                flex: 1,
                marginLeft: 16,
              }}
            >
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "900",
                  color: "#0F172A",
                }}
              >
                Console
              </Text>

              <View
                style={{
                  marginTop: 4,
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text
                  style={{
                    color: "#64748B",
                    fontSize: 13,
                    fontWeight: "700",
                  }}
                >
                  {goalCurrent} / {goalTarget} SAR
                </Text>
              </View>
            </View>

            <Text
              style={{
                color: "#57577a",
                fontSize: 20,
                fontWeight: "900",
                marginLeft: 6,
              }}
            >
              ❯
            </Text>
          </View>
        </Pressable>

        {/* Achievements */}
        <View
          style={{
            marginTop: 30,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Text
              style={{
                fontSize: 22,
                fontWeight: "900",
                color: "#0F172A",
              }}
            >
              Achievements
            </Text>

            <Pressable>
              <Text
                style={{
                  color: "#5B5CEB",
                  fontWeight: "700",
                }}
              >
                See All
              </Text>
            </Pressable>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            {achievements.map((achievement) => (
              <AchievementBadge
                key={achievement.id}
                achievement={achievement}
                onPress={() => setSelectedAchievement(achievement)}
              />
            ))}
          </View>
        </View>
      </ScrollView>

      {/* Quick Actions modal */}
      <Modal visible={showActions} transparent animationType="slide">
        <Pressable
          onPress={() => setShowActions(false)}
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,.35)",
            justifyContent: "flex-end",
          }}
        >
          <Pressable
            onPress={() => {}}
            style={{
              backgroundColor: "#FFFFFF",
              borderTopLeftRadius: 35,
              borderTopRightRadius: 35,
              paddingHorizontal: 24,
              paddingTop: 18,
              paddingBottom: 35,
            }}
          >
            {/* Handle */}
            <View
              style={{
                width: 60,
                height: 5,
                borderRadius: 10,
                backgroundColor: "#CBD5E1",
                alignSelf: "center",
                marginBottom: 20,
              }}
            />

            <Text
              style={{
                fontSize: 26,
                fontWeight: "900",
                color: "#0F172A",
              }}
            >
              Quick Actions
            </Text>

            <Text
              style={{
                color: "#64748B",
                marginTop: 4,
                marginBottom: 24,
              }}
            >
              Choose what you want to do
            </Text>

            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                justifyContent: "space-between",
              }}
            >
              <PopupAction
                title="Shop"
                color="#E0F2FE"
                image={require("../../assts/images/shop-logo.png")}
                onPress={() => {
                  setShowActions(false);
                  router.push("/child/store" as any);
                }}
              />

              <PopupAction
                title="Goals"
                color="#FEF3C7"
                image={require("../../assts/images/goal-logo.png")}
                onPress={() => {
                  setShowActions(false);
                  router.push("/child/goals" as any);
                }}
              />

              <PopupAction
                title="Wallet"
                color="#DCFCE7"
                image={require("../../assts/images/image-removebg-preview (16).png")}
                onPress={() => {
                  setShowActions(false);
                  router.push("/child/wallet" as any);
                }}
              />

              <PopupAction
                title="Stories"
                color="#FCE7F3"
                image={require("../../assts/images/read-logo.png")}
                onPress={() => {
                  setShowActions(false);
                  router.push("/child/stories" as any);
                }}
              />
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Achievement detail modal */}
      <Modal visible={!!selectedAchievement} transparent animationType="fade">
        <Pressable
          onPress={() => setSelectedAchievement(null)}
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,.4)",
            justifyContent: "center",
            alignItems: "center",
            padding: 30,
          }}
        >
          <Pressable
            onPress={() => {}}
            style={{
              backgroundColor: "white",
              borderRadius: 28,
              padding: 26,
              width: "100%",
              alignItems: "center",
            }}
          >
            {selectedAchievement && (
              <>
                <View
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 36,
                    backgroundColor: selectedAchievement.unlocked
                      ? selectedAchievement.color
                      : "#F1F5F9",
                    justifyContent: "center",
                    alignItems: "center",
                    marginBottom: 14,
                  }}
                >
                  {selectedAchievement.unlocked ? (
                    selectedAchievement.icon(selectedAchievement.unlockedColor)
                  ) : (
                    <Lock size={26} color="#94A3B8" />
                  )}
                </View>

                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "900",
                    color: "#0F172A",
                  }}
                >
                  {selectedAchievement.title}
                </Text>

                <Text
                  style={{
                    marginTop: 8,
                    fontSize: 13,
                    color: "#64748B",
                    textAlign: "center",
                    lineHeight: 19,
                  }}
                >
                  {selectedAchievement.description}
                </Text>

                <View
                  style={{
                    marginTop: 16,
                    paddingHorizontal: 16,
                    paddingVertical: 8,
                    borderRadius: 16,
                    backgroundColor: selectedAchievement.unlocked
                      ? "#DCFCE7"
                      : "#F1F5F9",
                  }}
                >
                  <Text
                    style={{
                      fontWeight: "800",
                      fontSize: 12,
                      color: selectedAchievement.unlocked
                        ? "#22A06B"
                        : "#94A3B8",
                    }}
                  >
                    {selectedAchievement.unlocked
                      ? "✅ Unlocked"
                      : "🔒 Locked — keep going!"}
                  </Text>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      <BottomNav />
    </View>
  );
}

function StatCard({
  icon,
  title,
  value,
  bg,
  valueColor,
  onPress,
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  bg: string;
  valueColor: string;
  onPress?: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        width: "48%",
        height: 165,
        backgroundColor: bg,
        borderRadius: 26,
        padding: 20,
        overflow: "hidden",
      }}
    >
      {icon}

      <Text
        style={{
          marginTop: 18,
          fontSize: 18,
          fontWeight: "500",
          color: valueColor,
        }}
      >
        {title}
      </Text>

      <Text
        style={{
          marginTop: 10,
          fontSize: 30,
          fontWeight: "500",
          color: valueColor,
        }}
      >
        {value}
      </Text>

      {/* Decorative Circle */}

      <View
        style={{
          position: "absolute",
          right: -35,
          bottom: -35,
          width: 120,
          height: 120,
          borderRadius: 60,
          backgroundColor: "rgba(255,255,255,0.25)",
        }}
      />
    </Pressable>
  );
}

function CircleAction({
  icon,
  title,
  color,
  onPress,
}: {
  icon: React.ReactNode;
  title: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        alignItems: "center",
      }}
    >
      <View
        style={{
          width: 60,
          height: 60,
          borderRadius: 30,
          backgroundColor: color,
          justifyContent: "center",
          alignItems: "center",

          shadowColor: "#000",
          shadowOpacity: 0.06,
          shadowRadius: 8,
          elevation: 3,
        }}
      >
        {icon}
      </View>

      <Text
        style={{
          marginTop: 8,
          fontWeight: "700",
          fontSize: 12,
          color: "#64748B",
        }}
      >
        {title}
      </Text>
    </Pressable>
  );
}

function PopupAction({
  title,
  image,
  color,
  onPress,
}: {
  title: string;
  image: any;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        width: "47%",
        backgroundColor: "#fff",
        borderRadius: 24,
        padding: 18,
        marginBottom: 18,
        alignItems: "center",

        shadowColor: "#000",
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 4,
      }}
    >
      <View
        style={{
          width: 70,
          height: 70,
          borderRadius: 35,
          backgroundColor: color,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Image
          source={image}
          style={{
            width: 34,
            height: 34,
            resizeMode: "contain",
          }}
        />
      </View>

      <Text
        style={{
          marginTop: 14,
          fontWeight: "800",
          fontSize: 16,
          color: "#1E293B",
        }}
      >
        {title}
      </Text>
    </Pressable>
  );
}

function MissionCard({
  mission,
  onPress,
}: {
  mission: Mission;
  onPress: () => void;
}) {
  const { emoji, title, subtitle, rewardValue, color, completed } = mission;
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePress = () => {
    if (completed) return;

    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.96,
        duration: 90,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 120,
        useNativeDriver: true,
      }),
    ]).start();

    onPress();
  };

  return (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <Pressable
        onPress={handlePress}
        style={{
          backgroundColor: "white",
          borderRadius: 22,
          padding: 16,
          marginBottom: 12,

          shadowColor: "#000",
          shadowOpacity: 0.05,
          shadowRadius: 8,
          elevation: 3,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 42,
              height: 42,
              borderRadius: 21,
              backgroundColor: color,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 20 }}>{emoji}</Text>
          </View>

          <View
            style={{
              flex: 1,
              marginLeft: 14,
            }}
          >
            <Text
              style={{
                fontWeight: "900",
                fontSize: 14,
                color: "#0F172A",
              }}
            >
              {title}
            </Text>

            <Text
              style={{
                marginTop: 2,
                fontSize: 12,
                color: "#94A3B8",
                fontWeight: "600",
              }}
            >
              {subtitle}
            </Text>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
              backgroundColor: completed ? "#DCFCE7" : "#FFF3D6",
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 16,
            }}
          >
            <Text style={{ fontSize: 13 }}>{completed ? "" : "🪙"}</Text>
            <Text
              style={{
                color: completed ? "#22A06B" : "#B4780A",
                fontWeight: "900",
                fontSize: 13,
              }}
            >
              {completed ? "Done" : rewardValue}
            </Text>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

function AchievementBadge({
  achievement,
  onPress,
}: {
  achievement: Achievement;
  onPress: () => void;
}) {
  const { title, icon, color, unlockedColor, unlocked } = achievement;

  return (
    <Pressable
      onPress={onPress}
      style={{
        alignItems: "center",
        width: 58,
      }}
    >
      <View
        style={{
          width: 52,
          height: 52,
          borderRadius: 26,
          backgroundColor: unlocked ? color : "#F1F5F9",
          justifyContent: "center",
          alignItems: "center",
          opacity: unlocked ? 1 : 0.7,
        }}
      >
        {unlocked ? icon(unlockedColor) : <Lock size={20} color="#94A3B8" />}
      </View>

      <Text
        numberOfLines={2}
        style={{
          marginTop: 6,
          fontSize: 10,
          fontWeight: "700",
          color: unlocked ? "#64748B" : "#CBD5E1",
          textAlign: "center",
        }}
      >
        {title}
      </Text>
    </Pressable>
  );
}
