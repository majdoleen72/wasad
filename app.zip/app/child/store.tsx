import React, { useMemo, useState } from "react";
import {
  FlatList,
  Image,
  ImageBackground,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { BlurView } from "expo-blur";
import * as Haptics from "expo-haptics";
import { StatusBar } from "expo-status-bar";
import {
  ArrowRight,
  Check,
  ChevronLeft,
  Coins,
  Crown,
  Home,
  Heart,
  RotateCcw,
  Save,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  Star,
  Users,
  X,
} from "lucide-react-native";
import {
  Nunito_400Regular,
  Nunito_500Medium,
  Nunito_700Bold,
  Nunito_800ExtraBold,
  Nunito_900Black,
  useFonts,
} from "@expo-google-fonts/nunito";

import { BottomNav } from "@/components/child/bottom-nav";

const A = {
  // Backgrounds
  island: require("../../assts/images/pet-shop/lolo.jpeg"),
  // Temporary room background until you add a separate room image.
  room: require("../../assts/images/pet-shop/lolo.jpeg"),

  // Pets
  fox: require("../../assts/images/pet-shop/fox.png"),
  pig: require("../../assts/images/pet-shop/pig.png"),
  crocodile: require("../../assts/images/pet-shop/crocodile.png"),
  dog: require("../../assts/images/pet-shop/dog.png"),
  polarBear: require("../../assts/images/pet-shop/polar-bear.png"),
  penguin: require("../../assts/images/pet-shop/penguin.png"),

  // Clothes
  shirtYellow: require("../../assts/images/pet-shop/yellshert.png"),
  shirtBlue: require("../../assts/images/pet-shop/blueshirt.png"),
  shirtGreen: require("../../assts/images/pet-shop/grshirt.png"),

  // Accessories
  glassesRound: require("../../assts/images/pet-shop/galss.png"),
  glassesSun: require("../../assts/images/pet-shop/sun.png"),
  glassesGold: require("../../assts/images/pet-shop/sungold.png"),
  scarfBlue: require("../../assts/images/pet-shop/blueshal.png"),
  scarfRed: require("../../assts/images/pet-shop/redshal.png"),
  headphones: require("../../assts/images/pet-shop/headphone.png"),
  camera: require("../../assts/images/pet-shop/camera.png"),

  // Hats
  crown: require("../../assts/images/pet-shop/tag.png"),
};

const C = {
  ink: "#20213A",
  muted: "#777A94",
  purple: "#7357DF",
  purpleDark: "#5536C8",
  purpleSoft: "#EEE9FF",
  green: "#48CFA4",
  greenDark: "#159B79",
  coral: "#FF8E9E",
  peach: "#FFB47D",
  sky: "#5DB8EE",
  yellow: "#FFD467",
  surface: "#FFFFFF",
  bg: "#F8F6FF",
  border: "#ECE9F5",
};

type Screen = "myPets" | "island" | "room" | "store" | "success";
type Category = "animals" | "clothes" | "accessories" | "hats";

type Pet = {
  id: string;
  name: string;
  image: any;
  level: number;
  xp: number;
  maxXp: number;
  price: number;
  color: string;
};

type ShopItem = {
  id: string;
  name: string;
  image: any;
  price: number;
  category: Exclude<Category, "animals">;
  slot: "body" | "face" | "head" | "neck" | "hand";
};

const pets: Pet[] = [
  { id: "fox", name: "Fox", image: A.fox, level: 5, xp: 85, maxXp: 120, price: 2000, color: "#FFE2B9" },
  { id: "pig", name: "Pig", image: A.pig, level: 3, xp: 40, maxXp: 80, price: 2000, color: "#FFD8E5" },
  { id: "crocodile", name: "Crocodile", image: A.crocodile, level: 4, xp: 62, maxXp: 100, price: 2000, color: "#DBF4C8" },
  { id: "dog", name: "Dog", image: A.dog, level: 2, xp: 24, maxXp: 60, price: 2000, color: "#FFE6C9" },
  { id: "polarBear", name: "Polar Bear", image: A.polarBear, level: 2, xp: 28, maxXp: 60, price: 2000, color: "#E8F2FF" },
  { id: "penguin", name: "Penguin", image: A.penguin, level: 3, xp: 51, maxXp: 80, price: 2000, color: "#E2E4FF" },
];

const friends = [
  { id: "me", name: "You", pet: pets[0], level: 5, color: "#F6C15D" },
  { id: "sarah", name: "Sarah", pet: pets[5], level: 8, color: "#73D5DF" },
  { id: "faisal", name: "Faisal", pet: pets[1], level: 6, color: "#F793A7" },
  { id: "mohammed", name: "Mohammed", pet: pets[2], level: 4, color: "#A9D66E" },
  { id: "leen", name: "Leen", pet: pets[3], level: 5, color: "#79C3EE" },
  { id: "noura", name: "Noura", pet: pets[4], level: 3, color: "#D4A0F4" },
];

const items: ShopItem[] = [
  {
    id: "shirtYellow",
    name: "Yellow Shirt",
    image: A.shirtYellow,
    price: 500,
    category: "clothes",
    slot: "body",
  },
  {
    id: "shirtBlue",
    name: "Blue Shirt",
    image: A.shirtBlue,
    price: 500,
    category: "clothes",
    slot: "body",
  },
  {
    id: "shirtGreen",
    name: "Green Shirt",
    image: A.shirtGreen,
    price: 500,
    category: "clothes",
    slot: "body",
  },

  {
    id: "glassesSun",
    name: "Sunglasses",
    image: A.glassesSun,
    price: 300,
    category: "accessories",
    slot: "face",
  },
  {
    id: "glassesRound",
    name: "Round Glasses",
    image: A.glassesRound,
    price: 300,
    category: "accessories",
    slot: "face",
  },
  {
    id: "scarfRed",
    name: "Red Scarf",
    image: A.scarfRed,
    price: 300,
    category: "accessories",
    slot: "neck",
  },
  {
    id: "scarfBlue",
    name: "Blue Scarf",
    image: A.scarfBlue,
    price: 300,
    category: "accessories",
    slot: "neck",
  },
  {
    id: "headphones",
    name: "Headphones",
    image: A.headphones,
    price: 600,
    category: "accessories",
    slot: "head",
  },
  {
    id: "camera",
    name: "Camera",
    image: A.camera,
    price: 700,
    category: "accessories",
    slot: "hand",
  },

  {
    id: "crown",
    name: "Royal Crown",
    image: A.crown,
    price: 600,
    category: "hats",
    slot: "head",
  },
  {
    id: "glassesGold",
    name: "Golden Glasses",
    image: A.glassesGold,
    price: 450,
    category: "hats",
    slot: "face",
  },
];

const categoryLabels: Record<Category, string> = {
  animals: "Animals",
  clothes: "Clothes",
  accessories: "Accessories",
  hats: "Hats",
};

const FONT = {
  regular: "Nunito_400Regular",
  medium: "Nunito_500Medium",
  bold: "Nunito_700Bold",
  extra: "Nunito_800ExtraBold",
  black: "Nunito_900Black",
};

const tap = () => {
  Haptics.selectionAsync().catch(() => undefined);
};

const successHaptic = () => {
  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
};

export default function StoreScreen() {
  const [fontsLoaded] = useFonts({
    Nunito_400Regular,
    Nunito_500Medium,
    Nunito_700Bold,
    Nunito_800ExtraBold,
    Nunito_900Black,
  });

  const [screen, setScreen] = useState<Screen>("myPets");
  const [coins, setCoins] = useState(2450);
  const [activePetId, setActivePetId] = useState("fox");
  const [category, setCategory] = useState<Category>("animals");
  const [ownedPets, setOwnedPets] = useState(["fox", "pig", "crocodile"]);
  const [ownedItems, setOwnedItems] = useState<string[]>(["shirtYellow", "glassesSun"]);
  const [equipped, setEquipped] = useState<Record<string, string>>({});
  const [lastPurchase, setLastPurchase] = useState<{ name: string; image: any } | null>(null);

  const activePet = pets.find((pet) => pet.id === activePetId) ?? pets[0];

  const visibleShop = useMemo(() => {
    if (category === "animals") return [];
    return items.filter((item) => item.category === category);
  }, [category]);

  if (!fontsLoaded) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  const buyPet = (pet: Pet) => {
    tap();
    if (ownedPets.includes(pet.id)) {
      setActivePetId(pet.id);
      setScreen("room");
      return;
    }
    if (coins < pet.price) return;
    setCoins((value) => value - pet.price);
    setOwnedPets((value) => [...value, pet.id]);
    setActivePetId(pet.id);
    setLastPurchase({ name: pet.name, image: pet.image });
    successHaptic();
    setScreen("success");
  };

  const buyItem = (item: ShopItem) => {
    tap();
    if (ownedItems.includes(item.id)) {
      setEquipped((current) => {
        const copy = { ...current };
        if (copy[item.slot] === item.id) delete copy[item.slot];
        else copy[item.slot] = item.id;
        return copy;
      });
      return;
    }
    if (coins < item.price) return;
    setCoins((value) => value - item.price);
    setOwnedItems((value) => [...value, item.id]);
    setEquipped((current) => ({ ...current, [item.slot]: item.id }));
    setLastPurchase({ name: item.name, image: item.image });
    successHaptic();
    setScreen("success");
  };

  const Header = ({ title, onBack }: { title: string; onBack?: () => void }) => (
    <View style={styles.header}>
      <View style={styles.headerSide}>
        {onBack ? (
          <Pressable style={styles.iconButton} onPress={() => { tap(); onBack?.(); }}>
            <ChevronLeft size={23} color={C.ink} />
          </Pressable>
        ) : null}
      </View>
      <Text style={styles.headerTitle}>{title}</Text>
      <View style={[styles.headerSide, { alignItems: "flex-end" }]}>
        <View style={styles.coinPill}>
          <Coins size={17} color="#D99508" />
          <Text style={styles.coinText}>{coins.toLocaleString()}</Text>
        </View>
      </View>
    </View>
  );

  const renderMyPets = () => {
    const myPets = pets.filter((pet) => ownedPets.includes(pet.id));
    const mainPet = myPets.find((pet) => pet.id === activePetId) ?? myPets[0];
    const otherPets = myPets.filter((pet) => pet.id !== mainPet?.id);

    return (
      <SafeAreaView style={styles.page}>
        <StatusBar style="dark" />

        <View style={styles.myPetsHeader}>
          <View style={styles.headerTitleWrap}>
            <Text style={styles.myPetsTitle}>My Pets</Text>
            <Text style={styles.myPetsSub}>Choose a buddy and visit its room.</Text>
          </View>

          <View style={styles.coinPill}>
            <Coins size={17} color="#D99508" />
            <Text style={styles.coinText}>{coins.toLocaleString()}</Text>
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.myPetsContent}
        >
          {mainPet && (
            <Pressable
              style={styles.mainPetCard}
              onPress={() => {
                tap();
                setScreen("room");
              }}
            >
              <LinearGradient
                colors={["#BDEFD9", "#DDF8ED"]}
                style={styles.mainPetGradient}
              >
                <View style={styles.mainPetTextWrap}>
                  <View style={styles.petTitleRow}>
                    <View>
                      <Text style={styles.mainPetName}>{mainPet.name}</Text>
                      <Text style={styles.mainPetLevel}>Level {mainPet.level}</Text>
                    </View>

                    <Heart size={21} color="#F66D8B" fill="#F66D8B" />
                  </View>

                  <View style={styles.mainProgressTrack}>
                    <View
                      style={[
                        styles.mainProgressFill,
                        {
                          width: `${(mainPet.xp / mainPet.maxXp) * 100}%`,
                        },
                      ]}
                    />
                  </View>

                  <Text style={styles.mainXpText}>
                    {mainPet.xp} / {mainPet.maxXp}
                  </Text>

                  <View style={styles.roomButton}>
                    <Home size={17} color="#FFFFFF" />
                    <Text style={styles.roomButtonText}>My Room</Text>
                  </View>
                </View>

                <Image
                  source={mainPet.image}
                  style={styles.mainPetImage}
                  resizeMode="contain"
                />
              </LinearGradient>
            </Pressable>
          )}

          <View style={styles.sectionHead}>
            <Text style={styles.sectionTitle}>My Buddies</Text>

            <Pressable
              style={styles.storeLinkButton}
              onPress={() => {
                tap();
                setScreen("store");
              }}
            >
              <ShoppingBag size={16} color={C.purple} />
              <Text style={styles.sectionLink}>Visit Store</Text>
            </Pressable>
          </View>

          <View style={styles.myPetsGrid}>
            {otherPets.map((pet) => (
              <Pressable
                key={pet.id}
                style={styles.petMiniCard}
                onPress={() => {
                  tap();
                  setActivePetId(pet.id);
                }}
              >
                <View
                  style={[
                    styles.petMiniImageBox,
                    { backgroundColor: pet.color },
                  ]}
                >
                  <Image
                    source={pet.image}
                    style={styles.petMiniImage}
                    resizeMode="contain"
                  />
                </View>

                <Text style={styles.petMiniName}>{pet.name}</Text>
                <Text style={styles.petMiniLevel}>Level {pet.level}</Text>

                <View style={styles.petMiniProgressTrack}>
                  <View
                    style={[
                      styles.petMiniProgressFill,
                      {
                        width: `${(pet.xp / pet.maxXp) * 100}%`,
                      },
                    ]}
                  />
                </View>

                <Text style={styles.petMiniXp}>
                  {pet.xp} / {pet.maxXp}
                </Text>
              </Pressable>
            ))}
          </View>

          <Pressable
            style={styles.addPetButton}
            onPress={() => {
              tap();
              setScreen("store");
            }}
          >
            <ShoppingCart size={18} color="#FFFFFF" />
            <Text style={styles.addPetButtonText}>Get Another Buddy</Text>
          </Pressable>
        </ScrollView>

        <BottomNav />
      </SafeAreaView>
    );
  };

  const renderIsland = () => (
    <SafeAreaView style={styles.page}>
      <StatusBar style="light" />
      <ImageBackground source={A.island} style={styles.islandPageBg} resizeMode="cover">
        <LinearGradient colors={["rgba(32,199,190,0.2)", "rgba(25,87,104,0.8)"]} style={StyleSheet.absoluteFill} />

        <View style={styles.islandTop}>
          <Pressable style={styles.glassButton} onPress={() => { tap(); setScreen("myPets"); }}>
            <ChevronLeft size={23} color="#FFF" />
          </Pressable>
          <View style={styles.islandHeading}>
            <Text style={styles.islandPageTitle}>Pearl Island</Text>
            <Text style={styles.islandPageSub}>Your friends and their levels</Text>
          </View>
          <View style={styles.glassCoins}>
            <Coins size={16} color="#FFE280" />
            <Text style={styles.glassCoinsText}>{coins.toLocaleString()}</Text>
          </View>
        </View>

        <ScrollView contentContainerStyle={styles.friendsContent}>
          <View style={styles.pearlTitleCard}>
            <Crown size={22} color="#A66D00" />
            <View>
              <Text style={styles.pearlCardTitle}>Island Community</Text>
              <Text style={styles.pearlCardSub}>Tap your pet to go to its room.</Text>
            </View>
          </View>

          <View style={styles.friendGrid}>
            {friends.map((friend) => {
              const mine = friend.id === "me";
              return (
                <Pressable
                  key={friend.id}
                  style={[styles.friendCard, mine && styles.friendCardMine]}
                  onPress={() => {
                    tap();
                    if (mine) {
                      setActivePetId(friend.pet.id);
                      setScreen("room");
                    }
                  }}
                >
                  <View style={[styles.friendPlatform, { backgroundColor: friend.color }]}>
                    <Image source={friend.pet.image} style={styles.friendPet} resizeMode="contain" />
                  </View>

                  <View style={styles.friendInfo}>
                    <View>
                      <Text style={styles.friendName}>{friend.name}</Text>
                      <Text style={styles.friendLevel}>Level {friend.level}</Text>
                    </View>
                    <View style={[styles.levelBubble, { backgroundColor: friend.color }]}>
                      <Text style={styles.levelBubbleText}>{friend.level}</Text>
                    </View>
                  </View>

                  {mine ? (
                    <View style={styles.mineTag}>
                      <Home size={13} color="#FFF" />
                      <Text style={styles.mineTagText}>My Room</Text>
                    </View>
                  ) : (
                    <View style={styles.friendMiniProgress}>
                      <View style={[styles.friendMiniFill, { width: `${42 + friend.level * 6}%` }]} />
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );

  const renderRoom = () => {
    const equippedItems = Object.values(equipped)
      .map((id) => items.find((item) => item.id === id))
      .filter(Boolean) as ShopItem[];

    return (
      <SafeAreaView style={styles.page}>
        <StatusBar style="light" />
        <ImageBackground source={A.room} style={styles.roomBg} resizeMode="cover">
          <LinearGradient colors={["rgba(255,244,217,0.54)", "rgba(74,46,115,0.38)"]} style={StyleSheet.absoluteFill} />

          <View style={styles.roomTop}>
            <Pressable style={styles.glassButton} onPress={() => { tap(); setScreen("island"); }}>
              <ChevronLeft size={23} color="#FFF" />
            </Pressable>
            <View>
              <Text style={styles.roomTitle}>{activePet.name} Room</Text>
              <Text style={styles.roomSub}>Create the perfect look</Text>
            </View>
            <Pressable style={styles.glassButton} onPress={() => { tap(); setScreen("store"); }}>
              <ShoppingBag size={21} color="#FFF" />
            </Pressable>
          </View>

          <View style={styles.petStage}>
            <View style={styles.stageGlow} />
            <Image source={activePet.image} style={styles.roomPet} resizeMode="contain" />

            {equippedItems.map((item) => (
              <Image
                key={item.id}
                source={item.image}
                resizeMode="contain"
                style={[
                  styles.equippedLayer,
                  item.slot === "body" && styles.layerBody,
                  item.slot === "face" && styles.layerFace,
                  item.slot === "head" && styles.layerHead,
                  item.slot === "neck" && styles.layerNeck,
                  item.slot === "hand" && styles.layerHand,
                ]}
              />
            ))}
          </View>

          <View style={styles.wardrobeSheet}>
            <View style={styles.wardrobeHandle} />
            <View style={styles.wardrobeTitleRow}>
              <View>
                <Text style={styles.wardrobeTitle}>My Wardrobe</Text>
                <Text style={styles.wardrobeSub}>Tap an item to try it on.</Text>
              </View>
              <Pressable style={styles.shopMiniButton} onPress={() => { tap(); setScreen("store"); }}>
                <ShoppingCart size={17} color="#FFF" />
                <Text style={styles.shopMiniText}>Store</Text>
              </Pressable>
            </View>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.wardrobeList}>
              {ownedItems.map((id) => {
                const item = items.find((entry) => entry.id === id);
                if (!item) return null;
                const isEquipped = equipped[item.slot] === item.id;
                return (
                  <Pressable
                    key={item.id}
                    style={[styles.wardrobeCard, isEquipped && styles.wardrobeCardActive]}
                    onPress={() =>
                      setEquipped((current) => {
                        const copy = { ...current };
                        if (copy[item.slot] === item.id) delete copy[item.slot];
                        else copy[item.slot] = item.id;
                        return copy;
                      })
                    }
                  >
                    <Image source={item.image} style={styles.wardrobeAsset} resizeMode="contain" />
                    {isEquipped && (
                      <View style={styles.selectedCheck}>
                        <Check size={12} color="#FFF" />
                      </View>
                    )}
                  </Pressable>
                );
              })}
            </ScrollView>

            <View style={styles.roomActions}>
              <Pressable style={styles.resetButton} onPress={() => { tap(); setEquipped({}); }}>
                <RotateCcw size={18} color={C.ink} />
                <Text style={styles.resetText}>Reset</Text>
              </Pressable>
              <Pressable style={styles.saveButton} onPress={() => { tap(); setScreen("myPets"); }}>
                <Save size={18} color="#FFF" />
                <Text style={styles.saveText}>Save Look</Text>
              </Pressable>
            </View>
          </View>
        </ImageBackground>
      </SafeAreaView>
    );
  };

  const renderStore = () => (
    <SafeAreaView style={[styles.page, { backgroundColor: category === "hats" ? "#FFF0ED" : "#F4F1FF" }]}>
      <StatusBar style="dark" />
      <View style={styles.storeContainer}>
        <Header title="Store" onBack={() => setScreen("room")} />

        <LinearGradient
          colors={["#4D219D", "#7B48D8"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.storeHero}
        >
          <View style={styles.storeHeroCopy}>
            <Text style={styles.storeHeroTitle}>Choose Your Friend</Text>
            <Text style={styles.storeHeroSub}>and start your journey!</Text>
          </View>

          <Image
            source={A.fox}
            style={styles.storeHeroFox}
            resizeMode="contain"
          />

          <View style={styles.heroStarOne} />
          <View style={styles.heroStarTwo} />
        </LinearGradient>

        <View style={styles.categoryRow}>
          {(["animals", "clothes", "accessories", "hats"] as Category[]).map((key) => (
            <Pressable
              key={key}
              style={[styles.categoryButton, category === key && styles.categoryButtonActive]}
              onPress={() => { tap(); setCategory(key); }}
            >
              {key === "animals" && <Users size={19} color={category === key ? C.purple : C.muted} />}
              {key === "clothes" && <Star size={19} color={category === key ? C.purple : C.muted} />}
              {key === "accessories" && <Sparkles size={19} color={category === key ? C.purple : C.muted} />}
              {key === "hats" && <Crown size={19} color={category === key ? C.coral : C.muted} />}
              <Text style={[styles.categoryText, category === key && styles.categoryTextActive]}>
                {categoryLabels[key]}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.storeSection}>
          {category === "animals" ? "All Animals" : categoryLabels[category]}
        </Text>

        {category === "animals" ? (
          <FlatList
            data={pets}
            numColumns={3}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: 32 }}
            columnWrapperStyle={{ gap: 10 }}
            renderItem={({ item }) => {
              const owned = ownedPets.includes(item.id);
              return (
                <Pressable style={styles.productCard} onPress={() => buyPet(item)}>
                  <View style={[styles.productImageBox, { backgroundColor: item.color }]}>
                    <Image source={item.image} style={styles.productPet} resizeMode="contain" />
                  </View>
                  <Text style={styles.productName}>{item.name}</Text>
                  <View style={styles.productPriceRow}>
                    <Coins size={13} color="#E2A20C" />
                    <Text style={styles.productPrice}>{owned ? "Owned" : item.price.toLocaleString()}</Text>
                  </View>
                </Pressable>
              );
            }}
          />
        ) : (
          <FlatList
            data={visibleShop}
            numColumns={3}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: 32 }}
            columnWrapperStyle={{ gap: 10 }}
            renderItem={({ item }) => {
              const owned = ownedItems.includes(item.id);
              const active = equipped[item.slot] === item.id;
              return (
                <Pressable style={[styles.productCard, active && styles.productCardActive]} onPress={() => buyItem(item)}>
                  <View style={styles.productImageBox}>
                    <Image source={item.image} style={styles.productItem} resizeMode="contain" />
                    {active && (
                      <View style={styles.selectedCheck}>
                        <Check size={12} color="#FFF" />
                      </View>
                    )}
                  </View>
                  <Text style={styles.productName} numberOfLines={1}>{item.name}</Text>
                  <View style={styles.productPriceRow}>
                    <Coins size={13} color="#E2A20C" />
                    <Text style={styles.productPrice}>
                      {owned ? (active ? "Equipped" : "Owned") : item.price.toLocaleString()}
                    </Text>
                  </View>
                </Pressable>
              );
            }}
          />
        )}
      </View>
    </SafeAreaView>
  );

  const renderSuccess = () => (
    <SafeAreaView style={styles.successPage}>
      <StatusBar style="light" />
      <LinearGradient colors={["#48CFA4", "#72DEC0"]} style={StyleSheet.absoluteFill} />
      <View style={styles.confettiOne} />
      <View style={styles.confettiTwo} />
      <View style={styles.successContent}>
        <Text style={styles.successTitle}>Purchase Complete! 🎉</Text>
        <Text style={styles.successSub}>The item was added to your wardrobe.</Text>

        <View style={styles.successPlatform}>
          {lastPurchase && (
            <Image source={lastPurchase.image} style={styles.successImage} resizeMode="contain" />
          )}
        </View>

        <View style={styles.successCard}>
          <View>
            <Text style={styles.successName}>{lastPurchase?.name}</Text>
            <Text style={styles.successInfo}>Ready to use now</Text>
          </View>
          <View style={styles.successCheckCircle}>
            <Check size={19} color="#FFF" />
          </View>
        </View>

        <Pressable style={styles.successMainButton} onPress={() => { tap(); setScreen("room"); }}>
          <Text style={styles.successMainText}>Go to My Room</Text>
        </Pressable>
        <Pressable onPress={() => { tap(); setScreen("store"); }}>
          <Text style={styles.continueText}>Continue Shopping</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );

  switch (screen) {
    case "island":
      return renderIsland();
    case "room":
      return renderRoom();
    case "store":
      return renderStore();
    case "success":
      return renderSuccess();
    default:
      return renderMyPets();
  }
}

const shadow = {
  shadowColor: "#231B4D",
  shadowOpacity: 0.11,
  shadowRadius: 16,
  shadowOffset: { width: 0, height: 8 },
  elevation: 6,
};

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  scrollContent: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 115 },

  header: {
    height: 62,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerSide: { width: 92, justifyContent: "center" },
  headerTitle: {
    flex: 1,
    textAlign: "center",
    fontFamily: FONT.black,
    fontSize: 23,
    color: C.ink,
  },
  iconButton: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    ...shadow,
  },
  coinPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    alignSelf: "flex-end",
    backgroundColor: "#FFF6D8",
    borderRadius: 18,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  coinText: { fontFamily: FONT.extra, fontSize: 13, color: "#A96F00" },

  welcome: {
    marginTop: 10,
    textAlign: "left",
    fontFamily: FONT.black,
    fontSize: 25,
    color: C.ink,
  },
  welcomeSub: {
    marginTop: 5,
    textAlign: "left",
    fontFamily: FONT.medium,
    fontSize: 14,
    lineHeight: 23,
    color: C.muted,
  },

  islandCard: {
    height: 360,
    marginTop: 20,
    borderRadius: 30,
    overflow: "hidden",
    ...shadow,
  },
  islandImage: { flex: 1 },
  islandRadius: { borderRadius: 30 },
  islandOverlay: {
    flex: 1,
    justifyContent: "space-between",
    padding: 22,
  },
  islandBadge: {
    alignSelf: "flex-end",
    flexDirection: "row",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.22)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
  },
  islandBadgeText: { fontFamily: FONT.bold, color: "#FFF", fontSize: 12 },
  islandTitle: { textAlign: "left", color: "#FFF", fontFamily: FONT.black, fontSize: 32 },
  islandSubtitle: {
    textAlign: "left",
    color: "rgba(255,255,255,0.9)",
    fontFamily: FONT.medium,
    fontSize: 14,
    marginTop: 5,
  },
  enterIsland: {
    marginTop: 16,
    backgroundColor: "#FFF",
    borderRadius: 18,
    minHeight: 52,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  enterIslandText: { fontFamily: FONT.extra, color: C.greenDark, fontSize: 16 },

  sectionHead: {
    marginTop: 25,
    marginBottom: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  sectionTitle: { fontFamily: FONT.black, fontSize: 20, color: C.ink },
  sectionLink: { fontFamily: FONT.bold, fontSize: 13, color: C.purple },
  currentPetCard: {
    backgroundColor: "#FFF",
    borderRadius: 25,
    padding: 14,
    flexDirection: "row",
    gap: 14,
    alignItems: "center",
    ...shadow,
  },
  currentPetImageBox: {
    width: 106,
    height: 106,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  currentPetImage: { width: 96, height: 103 },
  currentPetName: { textAlign: "left", fontFamily: FONT.black, fontSize: 19, color: C.ink },
  levelText: { textAlign: "left", marginTop: 2, fontFamily: FONT.medium, color: C.muted, fontSize: 12 },
  progressTrack: {
    height: 8,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#EAE7F4",
    marginTop: 10,
  },
  progressFill: { height: "100%", borderRadius: 10, backgroundColor: C.yellow },
  xpText: { textAlign: "left", marginTop: 4, fontFamily: FONT.medium, fontSize: 10, color: C.muted },
  roomArrow: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: C.purple,
    justifyContent: "center",
    alignItems: "center",
  },

  islandPageBg: { flex: 1 },
  islandTop: {
    paddingHorizontal: 18,
    paddingTop: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  glassButton: {
    width: 44,
    height: 44,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.22)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.28)",
  },
  islandHeading: { alignItems: "center" },
  islandPageTitle: { color: "#FFF", fontFamily: FONT.black, fontSize: 24 },
  islandPageSub: { color: "rgba(255,255,255,0.85)", fontFamily: FONT.medium, fontSize: 12 },
  glassCoins: {
    minWidth: 75,
    paddingHorizontal: 9,
    height: 42,
    flexDirection: "row",
    gap: 5,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.22)",
  },
  glassCoinsText: { fontFamily: FONT.extra, color: "#FFF", fontSize: 12 },
  friendsContent: { padding: 18, paddingBottom: 45 },
  pearlTitleCard: {
    marginTop: 260,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderRadius: 22,
    padding: 16,
    flexDirection: "row",
    gap: 11,
    alignItems: "center",
    ...shadow,
  },
  pearlCardTitle: { textAlign: "left", fontFamily: FONT.black, fontSize: 17, color: C.ink },
  pearlCardSub: { textAlign: "left", fontFamily: FONT.medium, fontSize: 12, color: C.muted },
  friendGrid: {
    marginTop: 14,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  friendCard: {
    width: "48.2%",
    marginBottom: 14,
    padding: 11,
    borderRadius: 24,
    backgroundColor: "rgba(255,255,255,0.94)",
    ...shadow,
  },
  friendCardMine: { borderWidth: 2, borderColor: C.yellow },
  friendPlatform: {
    height: 145,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  friendPet: { width: 122, height: 138 },
  friendInfo: {
    marginTop: 9,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  friendName: { textAlign: "left", fontFamily: FONT.black, fontSize: 16, color: C.ink },
  friendLevel: { textAlign: "left", fontFamily: FONT.medium, fontSize: 11, color: C.muted },
  levelBubble: {
    width: 35,
    height: 35,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },
  levelBubbleText: { fontFamily: FONT.black, color: "#FFF", fontSize: 15 },
  mineTag: {
    marginTop: 9,
    height: 31,
    borderRadius: 12,
    backgroundColor: C.purple,
    flexDirection: "row",
    gap: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  mineTagText: { color: "#FFF", fontFamily: FONT.bold, fontSize: 12 },
  friendMiniProgress: {
    height: 6,
    backgroundColor: "#E8E8EF",
    borderRadius: 8,
    overflow: "hidden",
    marginTop: 11,
  },
  friendMiniFill: { height: "100%", borderRadius: 8, backgroundColor: C.green },

  roomBg: { flex: 1 },
  roomTop: {
    zIndex: 5,
    paddingHorizontal: 18,
    paddingTop: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  roomTitle: { textAlign: "center", color: "#FFF", fontFamily: FONT.black, fontSize: 21 },
  roomSub: { textAlign: "center", color: "rgba(255,255,255,0.86)", fontFamily: FONT.medium, fontSize: 11 },
  petStage: { flex: 1, alignItems: "center", justifyContent: "center" },
  stageGlow: {
    position: "absolute",
    bottom: 35,
    width: 245,
    height: 55,
    borderRadius: 100,
    backgroundColor: "rgba(255,235,170,0.65)",
  },
  roomPet: { width: 270, height: 360 },
  equippedLayer: { position: "absolute" },
  layerBody: { width: 210, height: 210, top: "42%" },
  layerFace: { width: 135, height: 78, top: "30%" },
  layerHead: { width: 165, height: 105, top: "20%" },
  layerNeck: { width: 140, height: 100, top: "41%" },
  layerHand: { width: 115, height: 105, top: "52%", right: "16%" },

  wardrobeSheet: {
    minHeight: 255,
    borderTopLeftRadius: 34,
    borderTopRightRadius: 34,
    backgroundColor: "#FFF",
    paddingHorizontal: 18,
    paddingTop: 8,
    paddingBottom: 18,
  },
  wardrobeHandle: {
    alignSelf: "center",
    width: 44,
    height: 5,
    borderRadius: 4,
    backgroundColor: "#DDD9E7",
    marginBottom: 10,
  },
  wardrobeTitleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  wardrobeTitle: { textAlign: "left", fontFamily: FONT.black, fontSize: 21, color: C.ink },
  wardrobeSub: { textAlign: "left", fontFamily: FONT.medium, fontSize: 11, color: C.muted },
  shopMiniButton: {
    height: 39,
    paddingHorizontal: 13,
    borderRadius: 14,
    flexDirection: "row",
    gap: 6,
    alignItems: "center",
    backgroundColor: C.purple,
  },
  shopMiniText: { color: "#FFF", fontFamily: FONT.bold, fontSize: 12 },
  wardrobeList: { paddingVertical: 14, gap: 10 },
  wardrobeCard: {
    width: 70,
    height: 70,
    borderRadius: 18,
    backgroundColor: "#F4F1FB",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "transparent",
  },
  wardrobeCardActive: { borderColor: C.purple, backgroundColor: C.purpleSoft },
  wardrobeAsset: { width: 58, height: 58 },
  selectedCheck: {
    position: "absolute",
    top: 5,
    right: 5,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: C.green,
    alignItems: "center",
    justifyContent: "center",
  },
  roomActions: { flexDirection: "row", gap: 11 },
  resetButton: {
    flex: 1,
    height: 49,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: "#E2DFEA",
    flexDirection: "row",
    gap: 7,
    alignItems: "center",
    justifyContent: "center",
  },
  resetText: { fontFamily: FONT.extra, color: C.ink, fontSize: 14 },
  saveButton: {
    flex: 1.25,
    height: 49,
    borderRadius: 17,
    backgroundColor: C.green,
    flexDirection: "row",
    gap: 7,
    alignItems: "center",
    justifyContent: "center",
  },
  saveText: { fontFamily: FONT.extra, color: "#FFF", fontSize: 14 },

  storeContainer: { flex: 1, width: "100%", paddingHorizontal: 14 },
  storeHero: {
    marginTop: 7,
    height: 158,
    borderRadius: 24,
    padding: 19,
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
  },
  storeHeroTitle: { textAlign: "left", color: "#FFF", fontFamily: FONT.black, fontSize: 22 },
  storeHeroSub: { textAlign: "left", color: "rgba(255,255,255,0.88)", fontFamily: FONT.bold, fontSize: 15 },
  storeHeroFox: { width: 150, height: 156, marginRight: -6 },
  categoryRow: {
    marginTop: 12,
    flexDirection: "row",
    gap: 7,
  },
  categoryButton: {
    flex: 1,
    minHeight: 58,
    borderRadius: 17,
    backgroundColor: "rgba(255,255,255,0.75)",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
    borderWidth: 1.5,
    borderColor: "transparent",
  },
  categoryButtonActive: { backgroundColor: "#FFF", borderColor: C.purpleSoft },
  categoryText: { fontFamily: FONT.bold, fontSize: 10, color: C.muted },
  categoryTextActive: { color: C.purple },
  storeSection: {
    textAlign: "left",
    marginTop: 16,
    marginBottom: 10,
    fontFamily: FONT.black,
    fontSize: 18,
    color: C.ink,
  },
  productCard: {
    flex: 1,
    maxWidth: "32%",
    minHeight: 150,
    marginBottom: 10,
    borderRadius: 16,
    padding: 8,
    backgroundColor: "rgba(255,255,255,0.82)",
    borderWidth: 2,
    borderColor: "transparent",
  },
  productCardActive: { borderColor: C.green },
  productImageBox: {
    height: 92,
    borderRadius: 15,
    backgroundColor: "#F2EFF9",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  productPet: { width: 88, height: 94 },
  productItem: { width: 82, height: 82 },
  productName: {
    textAlign: "center",
    marginTop: 6,
    fontFamily: FONT.extra,
    color: C.ink,
    fontSize: 11,
  },
  productPriceRow: {
    marginTop: 3,
    flexDirection: "row",
    justifyContent: "center",
    gap: 4,
    alignItems: "center",
  },
  productPrice: { fontFamily: FONT.bold, fontSize: 10, color: "#A16E00" },

  successPage: { flex: 1 },
  successContent: { flex: 1, paddingHorizontal: 24, paddingTop: 60, alignItems: "center" },
  successTitle: { color: "#FFF", fontFamily: FONT.black, fontSize: 29 },
  successSub: { marginTop: 4, color: "rgba(255,255,255,0.9)", fontFamily: FONT.medium, fontSize: 14 },
  successPlatform: {
    marginTop: 30,
    width: 260,
    height: 270,
    borderRadius: 130,
    backgroundColor: "rgba(255,255,255,0.18)",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.32)",
    alignItems: "center",
    justifyContent: "center",
  },
  successImage: { width: 220, height: 220 },
  successCard: {
    width: "100%",
    marginTop: 26,
    minHeight: 78,
    borderRadius: 22,
    backgroundColor: "#FFF",
    paddingHorizontal: 17,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  successName: { textAlign: "left", fontFamily: FONT.black, color: C.ink, fontSize: 17 },
  successInfo: { textAlign: "left", fontFamily: FONT.medium, color: C.muted, fontSize: 12 },
  successCheckCircle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: C.green,
    alignItems: "center",
    justifyContent: "center",
  },
  successMainButton: {
    width: "100%",
    height: 56,
    borderRadius: 20,
    backgroundColor: C.purple,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 18,
  },
  successMainText: { color: "#FFF", fontFamily: FONT.black, fontSize: 16 },
  continueText: { color: "#FFF", fontFamily: FONT.bold, fontSize: 14, marginTop: 16 },
  confettiOne: {
    position: "absolute",
    width: 13,
    height: 35,
    borderRadius: 8,
    backgroundColor: "#FFD45E",
    top: 90,
    left: 35,
    transform: [{ rotate: "25deg" }],
  },
  confettiTwo: {
    position: "absolute",
    width: 13,
    height: 35,
    borderRadius: 8,
    backgroundColor: "#FF8297",
    top: 135,
    right: 38,
    transform: [{ rotate: "-28deg" }],
  },

  myPetsHeader: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitleWrap: {
    flex: 1,
    paddingRight: 12,
  },
  myPetsTitle: {
    fontFamily: FONT.black,
    fontSize: 28,
    color: C.ink,
  },
  myPetsSub: {
    marginTop: 2,
    fontFamily: FONT.medium,
    fontSize: 13,
    color: C.muted,
  },
  myPetsContent: {
    paddingHorizontal: 20,
    paddingBottom: 120,
  },
  mainPetCard: {
    marginTop: 10,
    borderRadius: 28,
    overflow: "hidden",
    ...shadow,
  },
  mainPetGradient: {
    minHeight: 220,
    padding: 18,
    flexDirection: "row",
    alignItems: "center",
  },
  mainPetTextWrap: {
    flex: 1,
    zIndex: 2,
  },
  petTitleRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  mainPetName: {
    fontFamily: FONT.black,
    fontSize: 23,
    color: C.ink,
  },
  mainPetLevel: {
    marginTop: 2,
    fontFamily: FONT.medium,
    fontSize: 13,
    color: C.muted,
  },
  mainProgressTrack: {
    marginTop: 18,
    width: "100%",
    height: 9,
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: "rgba(255,255,255,0.78)",
  },
  mainProgressFill: {
    height: "100%",
    borderRadius: 8,
    backgroundColor: C.yellow,
  },
  mainXpText: {
    marginTop: 5,
    fontFamily: FONT.bold,
    fontSize: 11,
    color: C.muted,
  },
  roomButton: {
    marginTop: 18,
    alignSelf: "flex-start",
    minHeight: 44,
    paddingHorizontal: 16,
    borderRadius: 15,
    backgroundColor: C.purple,
    flexDirection: "row",
    gap: 7,
    alignItems: "center",
    justifyContent: "center",
  },
  roomButtonText: {
    color: "#FFFFFF",
    fontFamily: FONT.extra,
    fontSize: 13,
  },
  mainPetImage: {
    width: 170,
    height: 190,
    marginRight: -12,
  },
  storeLinkButton: {
    flexDirection: "row",
    gap: 5,
    alignItems: "center",
  },
  myPetsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  petMiniCard: {
    width: "48%",
    marginBottom: 14,
    padding: 12,
    borderRadius: 22,
    backgroundColor: "#FFFFFF",
    ...shadow,
  },
  petMiniImageBox: {
    height: 145,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  petMiniImage: {
    width: "90%",
    height: "90%",
  },
  petMiniName: {
    marginTop: 9,
    fontFamily: FONT.black,
    fontSize: 16,
    color: C.ink,
  },
  petMiniLevel: {
    marginTop: 1,
    fontFamily: FONT.medium,
    fontSize: 11,
    color: C.muted,
  },
  petMiniProgressTrack: {
    marginTop: 8,
    height: 7,
    borderRadius: 7,
    overflow: "hidden",
    backgroundColor: "#ECEAF4",
  },
  petMiniProgressFill: {
    height: "100%",
    borderRadius: 7,
    backgroundColor: C.green,
  },
  petMiniXp: {
    marginTop: 4,
    fontFamily: FONT.medium,
    fontSize: 9,
    color: C.muted,
  },
  addPetButton: {
    marginTop: 6,
    height: 54,
    borderRadius: 18,
    backgroundColor: C.purple,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  addPetButtonText: {
    color: "#FFFFFF",
    fontFamily: FONT.black,
    fontSize: 15,
  },

  storeHeroCopy: {
    flex: 1,
    zIndex: 2,
  },
  heroStarOne: {
    position: "absolute",
    width: 12,
    height: 12,
    borderRadius: 3,
    backgroundColor: "#FFD85A",
    top: 22,
    left: 24,
    transform: [{ rotate: "45deg" }],
  },
  heroStarTwo: {
    position: "absolute",
    width: 8,
    height: 8,
    borderRadius: 2,
    backgroundColor: "#FFF3B0",
    top: 52,
    left: 52,
    transform: [{ rotate: "45deg" }],
  },
});