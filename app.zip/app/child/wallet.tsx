import { BottomNav } from "@/components/child/bottom-nav";
import { useApp } from "@/components/providers/app-provider";
import { LinearGradient } from "expo-linear-gradient";
import { Image, ScrollView, Text, TouchableOpacity, View } from "react-native";
import Svg, { Circle, Path } from "react-native-svg";

export default function WalletScreen() {
  const { balance, savings } = useApp();

  const history = [
    {
      title: "Cleaned Room",
      time: "2h ago",
      amount: "+10",
      icon: "🧹",
      color: "#FDF3DD",
    },
    {
      title: "Saved to Bike",
      time: "Yesterday",
      amount: "+20",
      image: require("../../assts/images/bike.png"),
      color: "#DDEFFB",
    },
    {
      title: "Allowance",
      time: "Sun",
      amount: "+50",
      icon: "😊",
      color: "#FFE7E0",
    },
  ];

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#EEF5FD",
      }}
    >
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 120,
        }}
      >
        {/* Header */}

        <Text
          style={{
            fontSize: 30,
            fontWeight: "bold",
            textAlign: "center",
            marginTop: 35,
            color: "#1e293b",
          }}
        >
          My Treasure Chest
        </Text>

        {/* Orange Balance Card */}

        <LinearGradient
          colors={["#FFD97A", "#F5A623"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            borderRadius: 32,
            marginTop: 25,
            padding: 22,
            flexDirection: "row",
            alignItems: "center",
            overflow: "hidden",

            shadowColor: "#000",
            shadowOpacity: 0.12,
            shadowRadius: 12,
            elevation: 8,
          }}
        >
          {/* Faint sparkles */}
          <Svg
            height="100%"
            width="100%"
            style={{ position: "absolute", top: 0, left: 0 }}
          >
            <Circle cx="20" cy="20" r="2" fill="#fff" opacity={0.6} />
            <Circle cx="45" cy="55" r="1.5" fill="#fff" opacity={0.5} />
            <Circle cx="90%" cy="15" r="2" fill="#fff" opacity={0.6} />
            <Circle cx="85%" cy="70" r="1.5" fill="#fff" opacity={0.4} />
          </Svg>

          <Image
            source={require("../../assts/images/chest.png")}
            style={{
              width: 110,
              height: 110,
              resizeMode: "contain",
            }}
          />

          <View style={{ marginLeft: 16, flex: 1 }}>
            <Text
              style={{
                color: "#8B5E00",
                fontSize: 14,
              }}
            >
              Available Balance
            </Text>

            <Text
              style={{
                fontSize: 38,
                fontWeight: "bold",
                color: "#3D2400",
                marginTop: 2,
              }}
            >
              {balance}
              <Text style={{ fontSize: 18 }}> SAR</Text>
            </Text>
          </View>
        </LinearGradient>

        {/* Stats */}

        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            marginTop: 25,
          }}
        >
          <StatCard
            color="#DDF8EF"
            waveColor="#0a6a2f"
            icon="💰"
            title="Savings"
            value={savings}
          />

          <StatCard
            color="#ECE5FF"
            waveColor="#210562"
            icon="🔒"
            title="Locked"
            value="60"
          />

          <StatCard
            color="#FFE6EF"
            waveColor="#800735"
            icon="🎁"
            title="Rewards"
            value="1240"
          />
        </View>

        {/* Week & Month */}

        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            marginTop: 18,
          }}
        >
          <TrendCard
            title="This week"
            value="+65"
            bg="#E7F9EF"
            valueColor="#22C55E"
            chartColor="#22C55E"
            trend="up"
          />

          <TrendCard
            title="This month"
            value="+310"
            bg="#E7F1FF"
            valueColor="#2F6FED"
            chartColor="#2F6FED"
            trend="wave"
          />
        </View>

        {/* History */}

        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginTop: 30,
            marginBottom: 15,
          }}
        >
          <Text
            style={{
              fontSize: 22,
              fontWeight: "bold",
              color: "#1e293b",
            }}
          >
            Transaction History
          </Text>

          <TouchableOpacity activeOpacity={0.7}>
            <Text
              style={{
                color: "#6D5BD0",
                fontWeight: "600",
                fontSize: 14,
              }}
            >
              See all
            </Text>
          </TouchableOpacity>
        </View>

        {history.map((item, index) => (
          <View
            key={index}
            style={{
              backgroundColor: "white",
              borderRadius: 22,
              padding: 18,
              marginBottom: 15,

              flexDirection: "row",
              alignItems: "center",

              shadowColor: "#000",
              shadowOpacity: 0.05,
              shadowRadius: 5,
              elevation: 3,
            }}
          >
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 24,
                backgroundColor: item.color,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {item.image ? (
                <Image
                  source={item.image}
                  style={{
                    width: 28,
                    height: 28,
                    resizeMode: "contain",
                  }}
                />
              ) : (
                <Text style={{ fontSize: 24 }}>{item.icon}</Text>
              )}
            </View>

            <View
              style={{
                marginLeft: 14,
                flex: 1,
              }}
            >
              <Text
                style={{
                  fontWeight: "700",
                  fontSize: 15,
                }}
              >
                {item.title}
              </Text>

              <Text
                style={{
                  color: "#94a3b8",
                  marginTop: 3,
                }}
              >
                {item.time}
              </Text>
            </View>

            <Text
              style={{
                color: "#22c55e",
                fontWeight: "bold",
                fontSize: 18,
              }}
            >
              {item.amount}
            </Text>
          </View>
        ))}
      </ScrollView>

      <BottomNav />
    </View>
  );
}
function StatCard({
  color,
  waveColor,
  icon,
  title,
  value,
}: {
  color: string;
  waveColor: string;
  icon: string;
  title: string;
  value: string | number;
}) {
  return (
    <View
      style={{
        width: "31%",
        backgroundColor: color,
        borderRadius: 22,
        paddingVertical: 20,
        alignItems: "center",
        overflow: "hidden",
      }}
    >
      {/* Faint decorative wave at the bottom of the card */}
      <Svg
        height="26"
        width="100%"
        viewBox="0 0 100 26"
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          opacity: 0.18,
        }}
      >
        <Path
          d="M0,18 Q15,6 30,16 T60,14 T100,10 L100,26 L0,26 Z"
          fill={waveColor}
        />
      </Svg>

      <Text style={{ fontSize: 28 }}>{icon}</Text>

      <Text
        style={{
          fontSize: 28,
          fontWeight: "bold",
          color: "#1e293b",
          marginTop: 8,
        }}
      >
        {value}
      </Text>

      <Text
        style={{
          color: "#64748b",
          fontSize: 12,
          marginTop: 4,
          textAlign: "center",
        }}
      >
        {title}
      </Text>
    </View>
  );
}

function TrendCard({
  title,
  value,
  bg,
  valueColor,
  chartColor,
  cornerIcon,
  trend,
}: {
  title: string;
  value: string;
  bg: string;
  valueColor: string;
  chartColor: string;
  cornerIcon?: React.ReactNode;
  trend: "up" | "wave";
}) {
  return (
    <View
      style={{
        width: "48%",
        backgroundColor: bg,
        borderRadius: 22,
        padding: 18,
        overflow: "hidden",
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text
          style={{
            color: "#475569",
            fontWeight: "700",
            fontSize: 13,
          }}
        >
          {title}
        </Text>

        {cornerIcon}
      </View>

      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 4,
          marginTop: 8,
        }}
      >
        <Text
          style={{
            fontWeight: "bold",
            fontSize: 26,
            color: valueColor,
          }}
        >
          {value}
        </Text>
        <Text style={{ fontSize: 16 }}>🪙</Text>
      </View>

      <Svg
        height="34"
        width="100%"
        viewBox="0 0 120 34"
        style={{ marginTop: 10 }}
      >
        {trend === "up" ? (
          <>
            <Path
              d="M0,28 Q25,30 45,20 T80,14 T120,4"
              stroke={chartColor}
              strokeWidth={3}
              fill="none"
            />
            <Circle cx="120" cy="4" r="4" fill={chartColor} />
          </>
        ) : (
          <Path
            d="M0,18 Q20,4 45,18 T80,14 T120,22"
            stroke={chartColor}
            strokeWidth={3}
            fill="none"
          />
        )}
      </Svg>
    </View>
  );
}
