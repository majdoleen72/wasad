import { BottomNav } from "@/components/child/bottom-nav";
import { useApp } from "@/components/providers/app-provider";
import { useState } from "react";
import {
  Image,
  Modal,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

export default function GoalsScreen() {
  const { savings, saveToGoal } = useApp();

  const goal = 500;
  const progress = Math.min((savings / goal) * 100, 100);
  const [showSecondGoal, setShowSecondGoal] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [goalName, setGoalName] = useState("");
  const [goalPrice, setGoalPrice] = useState("");

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#EEF5FD",
      }}
    >
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 120,
        }}
      >
        <Pressable
          onPress={() => setShowModal(true)}
          style={{
            borderWidth: 2,
            borderStyle: "dashed",
            borderColor: "#60A5FA",
            borderRadius: 20,
            paddingVertical: 16,
            alignItems: "center",
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              color: "#38BDF8",
              fontWeight: "700",
              fontSize: 17,
            }}
          >
            ＋ New Goal
          </Text>
        </Pressable>
        {/* Title */}

        <Text
          style={{
            fontSize: 30,
            fontWeight: "bold",
            textAlign: "center",
            marginTop: 35,
            color: "#1e293b",
          }}
        >
          Saving Goals
        </Text>

        <Text
          style={{
            textAlign: "center",
            color: "#64748b",
            marginTop: 6,
            marginBottom: 25,
          }}
        >
          Dream it, save for it, get it!
        </Text>

        {/* New Goal */}
        {showSecondGoal && (
          <View
            style={{
              backgroundColor: "white",
              borderRadius: 28,
              padding: 20,
              marginTop: 20,
              shadowColor: "#000",
              shadowOpacity: 0.08,
              shadowRadius: 10,
              elevation: 5,
            }}
          >
            <Text
              style={{
                fontSize: 22,
                fontWeight: "bold",
              }}
            >
              {goalName}
            </Text>

            <Text
              style={{
                marginTop: 8,
                color: "#64748b",
              }}
            >
              0 / {goalPrice} SAR
            </Text>

            <View
              style={{
                marginTop: 15,
                height: 10,
                backgroundColor: "#E5E7EB",
                borderRadius: 20,
              }}
            />

            <Pressable
              style={{
                marginTop: 20,
                backgroundColor: "#35B4F3",
                paddingVertical: 16,
                borderRadius: 25,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontWeight: "bold",
                }}
              >
                Add to Goal
              </Text>
            </Pressable>
          </View>
        )}

        {/* Goal Card */}

        <View
          style={{
            backgroundColor: "white",
            borderRadius: 28,
            padding: 20,
            shadowColor: "#000",
            shadowOpacity: 0.08,
            shadowRadius: 10,
            elevation: 5,
          }}
        >
          <View
            style={{
              flexDirection: "row",
            }}
          >
            <View
              style={{
                width: 75,
                height: 75,
                borderRadius: 40,
                backgroundColor: "#EEF7FF",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Image
                source={require("../../assts/images/bike.png")}
                style={{
                  width: 55,
                  height: 55,
                  resizeMode: "contain",
                }}
              />
            </View>

            <View
              style={{
                marginLeft: 18,
                flex: 1,
              }}
            >
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: "bold",
                  color: "#1e293b",
                }}
              >
                Mountain Bike
              </Text>

              <Text
                style={{
                  marginTop: 5,
                  color: "#64748b",
                }}
              >
                {savings} / {goal} SAR
              </Text>

              <View
                style={{
                  flexDirection: "row",
                  marginTop: 10,
                }}
              >
                <View
                  style={{
                    backgroundColor: "#DDF8EF",
                    paddingHorizontal: 10,
                    paddingVertical: 4,
                    borderRadius: 15,
                  }}
                >
                  <Text
                    style={{
                      color: "#22C55E",
                      fontWeight: "bold",
                      fontSize: 12,
                    }}
                  >
                    {Math.round(progress)}%
                  </Text>
                </View>

                <View
                  style={{
                    marginLeft: 10,
                    backgroundColor: "#EEF2F7",
                    paddingHorizontal: 10,
                    paddingVertical: 4,
                    borderRadius: 15,
                  }}
                >
                  <Text
                    style={{
                      color: "#64748b",
                      fontSize: 12,
                    }}
                  >
                    ⏱ 8 weeks
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* Progress */}

          <View
            style={{
              marginTop: 25,
              height: 10,
              backgroundColor: "#E5E7EB",
              borderRadius: 20,
              overflow: "hidden",
            }}
          >
            <View
              style={{
                width: `${progress}%`,
                height: "100%",
                backgroundColor: "#38BDF8",
              }}
            />
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              marginTop: 8,
            }}
          >
            <Text>25%</Text>
            <Text>50%</Text>
            <Text>75%</Text>
            <Text>100%</Text>
          </View>

          {/* Tip */}

          <View
            style={{
              marginTop: 20,
              backgroundColor: "#EFE8FF",
              borderRadius: 15,
              padding: 15,
            }}
          >
            <Text
              style={{
                color: "#7C3AED",
                fontWeight: "600",
              }}
            >
              ✨ Save 20 SAR every week and reach your goal in 8 weeks.
            </Text>
          </View>

          {/* Button */}

          <Pressable
            onPress={() => saveToGoal(20)}
            style={{
              marginTop: 20,
              backgroundColor: "#35B4F3",
              paddingVertical: 16,
              borderRadius: 25,
              alignItems: "center",
            }}
          >
            <Text
              style={{
                color: "white",
                fontWeight: "bold",
                fontSize: 17,
              }}
            >
              🪙 Add to Goal +20
            </Text>
          </Pressable>
        </View>
        <Modal visible={showModal} transparent animationType="slide">
          <View
            style={{
              flex: 1,
              backgroundColor: "rgba(0,0,0,0.4)",
              justifyContent: "center",
              padding: 25,
            }}
          >
            <View
              style={{
                backgroundColor: "white",
                borderRadius: 25,
                padding: 20,
              }}
            >
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: "bold",
                  marginBottom: 20,
                }}
              >
                New Goal
              </Text>

              <TextInput
                placeholder="Goal name"
                value={goalName}
                onChangeText={setGoalName}
                style={{
                  borderWidth: 1,
                  borderColor: "#ddd",
                  borderRadius: 15,
                  padding: 12,
                  marginBottom: 15,
                }}
              />

              <TextInput
                placeholder="Goal price"
                value={goalPrice}
                onChangeText={setGoalPrice}
                keyboardType="numeric"
                style={{
                  borderWidth: 1,
                  borderColor: "#ddd",
                  borderRadius: 15,
                  padding: 12,
                }}
              />

              <Pressable
                onPress={() => {
                  if (goalName.trim() === "" || goalPrice.trim() === "") return;

                  setShowSecondGoal(true);
                  setShowModal(false);
                }}
                style={{
                  marginTop: 20,
                  backgroundColor: "#35B4F3",
                  padding: 15,
                  borderRadius: 20,
                  alignItems: "center",
                }}
              >
                <Text
                  style={{
                    color: "white",
                    fontWeight: "bold",
                  }}
                >
                  Create Goal
                </Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </ScrollView>

      <BottomNav />
    </View>
  );
}
