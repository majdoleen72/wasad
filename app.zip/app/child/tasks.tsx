import { BottomNav } from "@/components/child/bottom-nav";
import { useApp } from "@/components/providers/app-provider";
import QuestCard from "@/components/quests/quest-card";
import { QuestPhase, quests } from "@/components/quests/quest-data";
import { Flame, MessageCircle } from "lucide-react-native";
import { useState } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";

/* ================================================================== */
/* Theme — same tokens as the stories/wallet screens so every screen  */
/* feels like part of the same app.                                   */
/* ================================================================== */

const colors = {
  background: "#EEF5FD",
  text: "#1e293b",
  textMuted: "#64748b",
  cardWhite: "#ffffff",
};

const spacing = {
  xs: 4,
  sm: 8,
  md: 14,
  lg: 20,
  xl: 25,
};

const typography = {
  title: { fontSize: 30, fontWeight: "bold" as const },
  subtitle: { fontSize: 14 },
};

const user = {
  name: "Dana",
  level: 3,
  balance: 120,
  avatar: require("../../assts/images/kide-girl.png"),
};

export default function QuestsScreen() {
  const { earn } = useApp();

  const [tab, setTab] = useState<"active" | "completed">("active");

  const [phase, setPhase] = useState<Record<number, QuestPhase>>({});

  const [completed, setCompleted] = useState<number[]>([]);

  const acceptQuest = (id: number) => {
    setPhase((p) => ({
      ...p,
      [id]: "accepted",
    }));
  };

  const uploadProof = (id: number) => {
    setPhase((p) => ({
      ...p,
      [id]: "verifying",
    }));

    setTimeout(() => {
      setPhase((p) => ({
        ...p,
        [id]: "verified",
      }));
    }, 2000);
  };

  const claimReward = (id: number, reward: number) => {
    earn(reward, "Quest Completed 🎉");

    setCompleted((prev) => [...prev, id]);

    setPhase((p) => ({
      ...p,
      [id]: "idle",
    }));
  };

  const list =
    tab === "active"
      ? quests.filter((q) => !completed.includes(q.id))
      : quests.filter((q) => completed.includes(q.id));

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}
      >
        {/* Profile header — avatar, name, level, coins, streak, chat */}

        <View
          style={{
            marginTop: 25,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: "#FFFFFF",
                justifyContent: "center",
                alignItems: "center",
                overflow: "hidden",
                shadowColor: "#000",
                shadowOpacity: 0.1,
                shadowRadius: 8,
                shadowOffset: { width: 0, height: 3 },
                elevation: 4,
              }}
            >
              <Image
                source={user.avatar}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                }}
              />
            </View>

            <View style={{ marginLeft: 10 }}>
              <Text
                style={{
                  fontSize: 15,
                  fontWeight: "900",
                  color: "#0F172A",
                }}
              >
                {user.name}
              </Text>
              <Text
                style={{
                  color: "#64748B",
                  fontSize: 12,
                }}
              >
                Level {user.level}
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 5,
                backgroundColor: "#FFF3D6",
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 20,
              }}
            >
              <Text style={{ fontSize: 14 }}>🪙</Text>
              <Text
                style={{
                  fontWeight: "900",
                  color: "#B4780A",
                  fontSize: 13,
                }}
              >
                {user.balance}
              </Text>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 5,
                backgroundColor: "#FFE1EC",
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 20,
              }}
            >
              <Flame size={16} color="#F0538E" />
              <Text
                style={{
                  fontWeight: "900",
                  color: "#F0538E",
                  fontSize: 13,
                }}
              >
                {user.level}
              </Text>
            </View>

            <Pressable
              style={{
                width: 38,
                height: 38,
                borderRadius: 19,
                backgroundColor: "#EDEBFF",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <MessageCircle size={18} color="#5B5CEB" />
            </Pressable>
          </View>
        </View>

        {/* Header — identical style to the stories/wallet screen's title */}

        <Text
          style={{
            ...typography.title,
            marginTop: 30,
            color: colors.text,
          }}
        >
          Daily Quests
        </Text>

        <Text
          style={{
            ...typography.subtitle,
            color: colors.textMuted,
            marginTop: 6,
            marginBottom: spacing.xl,
          }}
        >
          Complete tasks to earn coins.
        </Text>

        {/* Tabs */}

        <View
          style={{
            flexDirection: "row",
            backgroundColor: "#dbeafe",
            borderRadius: 20,
            padding: 4,
            marginBottom: spacing.xl,
          }}
        >
          <Pressable
            onPress={() => setTab("active")}
            style={{
              flex: 1,
              backgroundColor:
                tab === "active" ? colors.cardWhite : "transparent",
              padding: 12,
              borderRadius: 15,
            }}
          >
            <Text
              style={{
                textAlign: "center",
                fontWeight: "bold",
                color: colors.text,
              }}
            >
              Active
            </Text>
          </Pressable>

          <Pressable
            onPress={() => setTab("completed")}
            style={{
              flex: 1,
              backgroundColor:
                tab === "completed" ? colors.cardWhite : "transparent",
              padding: 12,
              borderRadius: 15,
            }}
          >
            <Text
              style={{
                textAlign: "center",
                fontWeight: "bold",
                color: colors.text,
              }}
            >
              Completed
            </Text>
          </Pressable>
        </View>

        {/* Quest list */}

        {list.map((quest) => (
          <QuestCard
            key={quest.id}
            quest={quest}
            phase={
              completed.includes(quest.id)
                ? "completed"
                : (phase[quest.id] ?? "idle")
            }
            onAccept={() => acceptQuest(quest.id)}
            onUpload={() => uploadProof(quest.id)}
            onClaim={() => claimReward(quest.id, quest.reward)}
          />
        ))}
      </ScrollView>

      <BottomNav />
    </View>
  );
}
