import { BottomNav } from "@/components/child/bottom-nav";
import { useApp } from "@/components/providers/app-provider";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import {
  ChevronRight,
  Flame,
  Home,
  MessageCircle,
  ShoppingBag,
  Star,
  Users,
} from "lucide-react-native";
import React, { useState } from "react";
import {
  Image,
  ImageBackground,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

const EVOLUTION_STAGES = [
  "Baby",
  "Explorer",
  "Saver",
  "Planner",
  "Investor",
  "Financial Hero",
];

const ISLAND_FRIENDS = [
  {
    id: "me",
    name: "You",
    level: 5,
    image: require("../../assts/images/pet-shop/fox.png"),
    color: "#FFD36B",
    position: { top: "38%", left: "8%" },
    mine: true,
  },
  {
    id: "sarah",
    name: "Sarah",
    level: 8,
    image: require("../../assts/images/pet-shop/penguin.png"),
    color: "#79D3E1",
    position: { top: "29%", right: "8%" },
  },
  {
    id: "faisal",
    name: "Faisal",
    level: 6,
    image: require("../../assts/images/pet-shop/pig.png"),
    color: "#F9A0B4",
    position: { top: "59%", left: "10%" },
  },
  {
    id: "mohammed",
    name: "Mohammed",
    level: 4,
    image: require("../../assts/images/pet-shop/crocodile.png"),
    color: "#A5D878",
    position: { top: "53%", right: "8%" },
  },
];

export default function PetScreen() {
  const router = useRouter();

  const {
    equippedHat,
    balance,
    level,
  } = useApp() as any;

  const [petHappiness, setPetHappiness] = useState(80);
  const [petHunger, setPetHunger] = useState(65);
  const [petEnergy, setPetEnergy] = useState(90);

  const unlockedStages = Math.min(
    EVOLUTION_STAGES.length,
    Math.max(1, level),
  );

  const currentStageName = EVOLUTION_STAGES[unlockedStages - 1];

  function increase(
    setter: React.Dispatch<React.SetStateAction<number>>,
    amount: number,
  ) {
    setter((value) => Math.min(100, value + amount));
  }

  return (
    <View style={styles.screen}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        <View style={styles.header}>
          <View style={styles.profile}>
            <View style={styles.avatarWrap}>
              <Image
                source={require("../../assts/images/kide-girl.png")}
                style={styles.avatar}
              />
            </View>

            <View style={styles.profileCopy}>
              <Text style={styles.profileName}>Dana</Text>
              <Text style={styles.profileLevel}>Level {level}</Text>
            </View>
          </View>

          <View style={styles.headerActions}>
            <View style={styles.coinPill}>
              <Text style={styles.coinEmoji}>🪙</Text>
              <Text style={styles.coinText}>{balance}</Text>
            </View>

            <View style={styles.streakPill}>
              <Flame size={16} color="#F0538E" />
              <Text style={styles.streakText}>{level}</Text>
            </View>

            <Pressable style={styles.messageButton}>
              <MessageCircle size={18} color="#5B5CEB" />
            </Pressable>
          </View>
        </View>

        

        {/* Pearl Island replaces the old Evolution and Wardrobe sections */}
        <View style={styles.islandHeadingRow}>
          <View>
            <Text style={styles.islandSectionTitle}>Pearl Island</Text>
            <Text style={styles.islandSectionSub}>
              Your friends, pets, and levels in one place
            </Text>
          </View>

          <View style={styles.friendsCount}>
            <Users size={16} color="#5B5CEB" />
            <Text style={styles.friendsCountText}>
              {ISLAND_FRIENDS.length}
            </Text>
          </View>
        </View>

        <ImageBackground
          source={require("../../assts/images/pet-shop/lolo.jpeg")}
          resizeMode="cover"
          imageStyle={styles.islandImage}
          style={styles.islandWorld}
        >
          <LinearGradient
            colors={[
              "rgba(10,91,111,0.04)",
              "rgba(15,74,91,0.14)",
              "rgba(10,47,67,0.48)",
            ]}
            locations={[0, 0.58, 1]}
            style={StyleSheet.absoluteFill}
          />

          <View style={styles.islandTopBar}>
            <View style={styles.islandGlassTitle}>
              <Star size={15} color="#FFD45F" fill="#FFD45F" />

              <View>
                <Text style={styles.islandGlassTitleText}>
                  Lolo Island
                </Text>
                <Text style={styles.islandGlassTitleSub}>
                  Tap your buddy to enter the room
                </Text>
              </View>
            </View>

            <View style={styles.islandLevelPill}>
              <Text style={styles.islandLevelText}>Lv. {level}</Text>
            </View>
          </View>

          {ISLAND_FRIENDS.map((friend) => (
            <Pressable
              key={friend.id}
              onPress={() => {
                if (friend.mine) {
                  router.push("/child/store" as any);
                }
              }}
              style={[
                styles.friendNode,
                friend.position,
                friend.mine && styles.myFriendNode,
              ]}
            >
              <View
                style={[
                  styles.friendPetCircle,
                  { backgroundColor: friend.color },
                ]}
              >
                <Image
                  source={friend.image}
                  style={styles.friendPetImage}
                  resizeMode="contain"
                />
              </View>

              <View style={styles.friendLabel}>
                <View>
                  <Text style={styles.friendName}>{friend.name}</Text>
                  <Text style={styles.friendLevel}>
                    Level {friend.level}
                  </Text>
                </View>

                <View
                  style={[
                    styles.friendLevelBadge,
                    { backgroundColor: friend.color },
                  ]}
                >
                  <Text style={styles.friendLevelBadgeText}>
                    {friend.level}
                  </Text>
                </View>
              </View>

              {friend.mine && (
                <View style={styles.myRoomTag}>
                  <Home size={12} color="#FFFFFF" />
                  <Text style={styles.myRoomTagText}>My Room</Text>
                </View>
              )}
            </Pressable>
          ))}

          <Pressable
            onPress={() => router.push("/child/store" as any)}
            style={styles.enterIslandButton}
          >
            <View style={styles.enterIslandIcon}>
              <ShoppingBag size={18} color="#FFFFFF" />
            </View>

            <View style={styles.enterIslandCopy}>
              <Text style={styles.enterIslandTitle}>
                Enter Pearl Island
              </Text>
              <Text style={styles.enterIslandSub}>
                Visit your room and change your buddy's look
              </Text>
            </View>

            <ChevronRight size={20} color="#FFFFFF" />
          </Pressable>
        </ImageBackground>
      </ScrollView>

      <BottomNav />
    </View>
  );
}

function StatusBar({
  emoji,
  value,
  color,
}: {
  emoji: string;
  value: number;
  color: string;
}) {
  return (
    <View style={styles.statusRow}>
      <Text style={styles.statusEmoji}>{emoji}</Text>

      <View style={styles.statusTrack}>
        <View
          style={[
            styles.statusFill,
            {
              width: `${value}%`,
              backgroundColor: color,
            },
          ]}
        />
      </View>

      <Text style={styles.statusValue}>{value}</Text>
    </View>
  );
}

function ActionButton({
  emoji,
  title,
  color,
  onPress,
}: {
  emoji: string;
  title: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.actionButton,
        {
          backgroundColor: color,
        },
      ]}
    >
      <Text style={styles.actionEmoji}>{emoji}</Text>
      <Text style={styles.actionTitle}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#EEF7FF",
  },

  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 130,
  },

  header: {
    marginTop: 5,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  profile: {
    flexDirection: "row",
    alignItems: "center",
  },

  avatarWrap: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
    shadowColor: "#000000",
    shadowOpacity: 0.1,
    shadowRadius: 8,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    elevation: 4,
  },

  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
  },

  profileCopy: {
    marginLeft: 10,
  },

  profileName: {
    fontSize: 15,
    fontWeight: "900",
    color: "#0F172A",
  },

  profileLevel: {
    marginTop: 1,
    color: "#64748B",
    fontSize: 12,
  },

  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },

  coinPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#FFF3D6",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },

  coinEmoji: {
    fontSize: 14,
  },

  coinText: {
    fontWeight: "900",
    color: "#B4780A",
    fontSize: 13,
  },

  streakPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#FFE1EC",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },

  streakText: {
    fontWeight: "900",
    color: "#F0538E",
    fontSize: 13,
  },

  messageButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#EDEBFF",
    justifyContent: "center",
    alignItems: "center",
  },

  pageTitle: {
    fontSize: 24,
    fontWeight: "900",
    textAlign: "center",
    marginTop: 20,
    color: "#0F172A",
  },

  buddyCard: {
    marginTop: 20,
    borderRadius: 32,
    padding: 22,
    shadowColor: "#000000",
    shadowOpacity: 0.06,
    shadowRadius: 14,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    elevation: 6,
  },

  petArea: {
    alignItems: "center",
  },

  equippedHat: {
    fontSize: 32,
    position: "absolute",
    top: -5,
    zIndex: 5,
  },

  mainPet: {
    width: 150,
    height: 150,
    resizeMode: "contain",
  },

  stagePill: {
    marginTop: 8,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 18,
    paddingVertical: 6,
    borderRadius: 20,
  },

  stagePillText: {
    color: "#22C55E",
    fontWeight: "800",
    fontSize: 13,
  },

  statusArea: {
    marginTop: 22,
  },

  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 12,
  },

  statusEmoji: {
    fontSize: 16,
    width: 26,
  },

  statusTrack: {
    flex: 1,
    height: 10,
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
    overflow: "hidden",
    marginHorizontal: 10,
  },

  statusFill: {
    height: "100%",
    borderRadius: 20,
  },

  statusValue: {
    color: "#64748B",
    fontWeight: "800",
    fontSize: 13,
    width: 28,
    textAlign: "right",
  },

  actionsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 14,
  },

  actionButton: {
    width: "31%",
    borderRadius: 18,
    paddingVertical: 12,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000000",
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 3,
  },

  actionEmoji: {
    fontSize: 22,
  },

  actionTitle: {
    marginTop: 4,
    fontWeight: "700",
    fontSize: 12,
    color: "#334155",
  },

  islandHeadingRow: {
    marginTop: 30,
    marginBottom: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  islandSectionTitle: {
    fontSize: 22,
    fontWeight: "900",
    color: "#1E293B",
  },

  islandSectionSub: {
    marginTop: 2,
    color: "#64748B",
    fontSize: 12,
    fontWeight: "600",
  },

  friendsCount: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#EDEBFF",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 18,
  },

  friendsCountText: {
    color: "#5B5CEB",
    fontSize: 12,
    fontWeight: "800",
  },

  islandWorld: {
    width: "100%",
    aspectRatio: 0.69,
    borderRadius: 30,
    overflow: "hidden",
    backgroundColor: "#29B4B0",
    shadowColor: "#0F766E",
    shadowOpacity: 0.16,
    shadowRadius: 18,
    shadowOffset: {
      width: 0,
      height: 9,
    },
    elevation: 7,
  },

  islandImage: {
    borderRadius: 30,
  },

  islandTopBar: {
    paddingHorizontal: 14,
    paddingTop: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  islandGlassTitle: {
    maxWidth: "76%",
    minHeight: 50,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 18,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.88)",
  },

  islandGlassTitleText: {
    color: "#144956",
    fontWeight: "900",
    fontSize: 15,
  },

  islandGlassTitleSub: {
    color: "#54808A",
    fontWeight: "600",
    fontSize: 9,
    marginTop: 1,
  },

  islandLevelPill: {
    minWidth: 58,
    height: 40,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.9)",
    justifyContent: "center",
    alignItems: "center",
  },

  islandLevelText: {
    color: "#0F766E",
    fontSize: 12,
    fontWeight: "900",
  },

  friendNode: {
    position: "absolute",
    width: "39%",
    borderRadius: 18,
    padding: 7,
    backgroundColor: "rgba(255,255,255,0.9)",
    shadowColor: "#143B4A",
    shadowOpacity: 0.13,
    shadowRadius: 10,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    elevation: 4,
  },

  myFriendNode: {
    borderWidth: 2,
    borderColor: "#FFD45F",
  },

  friendPetCircle: {
    height: 88,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  friendPetImage: {
    width: "88%",
    height: "88%",
  },

  friendLabel: {
    marginTop: 6,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  friendName: {
    color: "#172033",
    fontWeight: "900",
    fontSize: 12,
  },

  friendLevel: {
    color: "#778195",
    fontWeight: "600",
    fontSize: 9,
    marginTop: 1,
  },

  friendLevelBadge: {
    width: 27,
    height: 27,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },

  friendLevelBadgeText: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "900",
  },

  myRoomTag: {
    marginTop: 6,
    minHeight: 25,
    borderRadius: 10,
    flexDirection: "row",
    gap: 4,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#5B5CEB",
  },

  myRoomTagText: {
    color: "#FFFFFF",
    fontWeight: "800",
    fontSize: 9,
  },

  enterIslandButton: {
    position: "absolute",
    left: 14,
    right: 14,
    bottom: 14,
    minHeight: 62,
    borderRadius: 20,
    paddingHorizontal: 13,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(34,47,78,0.9)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.22)",
  },

  enterIslandIcon: {
    width: 39,
    height: 39,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#5B5CEB",
  },

  enterIslandCopy: {
    flex: 1,
    marginHorizontal: 10,
  },

  enterIslandTitle: {
    color: "#FFFFFF",
    fontWeight: "900",
    fontSize: 13,
  },

  enterIslandSub: {
    color: "rgba(255,255,255,0.72)",
    fontWeight: "600",
    fontSize: 9,
    marginTop: 2,
  },
});