import { BottomNav } from "@/components/child/bottom-nav";
import { useApp } from "@/components/providers/app-provider";
import { useLocalSearchParams } from "expo-router";
import { Pressable, Text, View } from "react-native";

export default function StoryDetails() {
  const { id } = useLocalSearchParams();

  const { earn } = useApp();

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#f0f9ff",
      }}
    >
      <View
        style={{
          flex: 1,
          padding: 25,
        }}
      >
        <Text
          style={{
            fontSize: 30,
            fontWeight: "bold",
          }}
        >
          📖 Story {id}
        </Text>

        <Text
          style={{
            marginTop: 25,
            fontSize: 18,
            lineHeight: 30,
          }}
        >
          Buddy wants to buy a bicycle 🚲.
          {"\n\n"}
          He only has 40 coins.
          {"\n\n"}
          What is the smartest decision?
        </Text>

        <Pressable
          style={{
            marginTop: 35,
            backgroundColor: "#ef4444",
            padding: 15,
            borderRadius: 15,
          }}
        >
          <Text
            style={{
              color: "white",
              textAlign: "center",
            }}
          >
            Spend everything
          </Text>
        </Pressable>

        <Pressable
          onPress={() => earn(20, "Correct Answer!")}
          style={{
            marginTop: 15,
            backgroundColor: "#22c55e",
            padding: 15,
            borderRadius: 15,
          }}
        >
          <Text
            style={{
              color: "white",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            Save more money
          </Text>
        </Pressable>

        <Pressable
          style={{
            marginTop: 15,
            backgroundColor: "#f59e0b",
            padding: 15,
            borderRadius: 15,
          }}
        >
          <Text
            style={{
              color: "white",
              textAlign: "center",
            }}
          >
            Borrow money
          </Text>
        </Pressable>
      </View>

      <BottomNav />
    </View>
  );
}
