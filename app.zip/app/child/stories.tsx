import { BottomNav } from "@/components/child/bottom-nav";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Plus } from "lucide-react-native";
import { useMemo, useRef, useState } from "react";
import {
  Animated,
  Easing,
  FlatList,
  Image,
  ImageSourcePropType,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";

/* ================================================================== */
/* Theme — kept in sync with the wallet screen's palette              */
/* ================================================================== */

const colors = {
  background: "#EEF5FD",
  text: "#1e293b",
  textMuted: "#64748b",
  cardWhite: "#ffffff",
  ctaGradientStart: "#9F7BFF",
  ctaGradientEnd: "#7C3AED",
  chipBg: "#ffffff",
  chipActiveBg: "#1e293b",
  heroGradientStart: "#35B4F3",
  heroGradientEnd: "#2F6FED",
};

const radius = { sm: 14, md: 22, lg: 28, pill: 20 };
const spacing = { xs: 4, sm: 8, md: 14, lg: 20, xl: 25 };

/* ================================================================== */
/* Data                                                                */
/* ================================================================== */

interface Story {
  id: number;
  title: string;
  desc: string;
  image: ImageSourcePropType;
  minutes: string;
  color: string;
  category: "Saving" | "Shopping" | "Banking" | "Needs & Wants";
  progress?: number; // 0–1, only set for stories the child already started
}

const stories: Story[] = [
  {
    id: 1,
    title: "Saving Money",
    desc: "Learn why saving money is important and how it helps your future.",
    image: require("../../assts/images/planet.png"),
    minutes: "3 min",
    color: "#ECE5FF",
    category: "Saving",
    progress: 0.4,
  },
  {
    id: 2,
    title: "Smart Shopping",
    desc: "Learn how to make smart choices before buying anything.",
    image: require("../../assts/images/island.png"),
    minutes: "4 min",
    color: "#DDF8EF",
    category: "Shopping",
  },
  {
    id: 3,
    title: "My First Bank",
    desc: "Discover how banks keep your money safe.",
    image: require("../../assts/images/coin-tree.png"),
    minutes: "5 min",
    color: "#D8EEFF",
    category: "Banking",
  },
  {
    id: 4,
    title: "Needs vs Wants",
    desc: "Understand the difference between needs and wants.",
    image: require("../../assts/images/planet.png"),
    minutes: "3 min",
    color: "#FFE6EF",
    category: "Needs & Wants",
  },
];

const categories = [
  "All",
  "Saving",
  "Shopping",
  "Banking",
  "Needs & Wants",
] as const;

/* ================================================================== */
/* Screen                                                              */
/* ================================================================== */

export default function StoriesScreen() {
  const [activeCategory, setActiveCategory] =
    useState<(typeof categories)[number]>("All");

  const continueStory = useMemo(() => stories.find((s) => s.progress), []);

  const filtered = useMemo(
    () =>
      activeCategory === "All"
        ? stories
        : stories.filter((s) => s.category === activeCategory),
    [activeCategory],
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: "space-between" }}
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 140 }}
        ListHeaderComponent={
          <ListHeader
            continueStory={continueStory}
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
          />
        }
        renderItem={({ item }) => <StoryTile story={item} />}
      />

      <NewStoryFab />
      <BottomNav />
    </View>
  );
}

/* ------------------------------------------------------------------ */
/* Header: title row + hero "continue reading" card + category chips  */
/* ------------------------------------------------------------------ */

function ListHeader({
  continueStory,
  activeCategory,
  onSelectCategory,
}: {
  continueStory?: Story;
  activeCategory: string;
  onSelectCategory: (c: (typeof categories)[number]) => void;
}) {
  return (
    <View style={{ marginBottom: spacing.lg }}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 35,
        }}
      >
        <View>
          <Text
            style={{ fontSize: 26, fontWeight: "bold", color: colors.text }}
          >
            Library
          </Text>
          <Text style={{ color: colors.textMuted, marginTop: 4, fontSize: 13 }}>
            Learn money skills through fun stories.
          </Text>
        </View>

        <View
          style={{
            backgroundColor: colors.cardWhite,
            borderRadius: radius.pill,
            paddingHorizontal: 14,
            paddingVertical: 8,
            shadowColor: "#000",
            shadowOpacity: 0.06,
            shadowRadius: 6,
            elevation: 2,
          }}
        >
          <Text style={{ fontWeight: "700", fontSize: 13, color: colors.text }}>
            {stories.length} stories
          </Text>
        </View>
      </View>

      {continueStory && <ContinueCard story={continueStory} />}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{
          gap: 10,
          marginTop: spacing.xl,
          paddingRight: spacing.lg,
        }}
      >
        {categories.map((cat) => {
          const active = cat === activeCategory;
          return (
            <Pressable
              key={cat}
              onPress={() => onSelectCategory(cat)}
              style={{
                backgroundColor: active ? colors.chipActiveBg : colors.chipBg,
                paddingHorizontal: 16,
                paddingVertical: 9,
                borderRadius: radius.pill,
                shadowColor: "#000",
                shadowOpacity: active ? 0 : 0.05,
                shadowRadius: 4,
                elevation: active ? 0 : 1,
              }}
            >
              <Text
                style={{
                  color: active ? "#fff" : colors.textMuted,
                  fontWeight: "600",
                  fontSize: 13,
                }}
              >
                {cat}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <Text
        style={{
          fontSize: 18,
          fontWeight: "bold",
          color: colors.text,
          marginTop: spacing.xl,
        }}
      >
        {activeCategory === "All" ? "All Stories" : activeCategory}
      </Text>
    </View>
  );
}

/* ------------------------------------------------------------------ */
/* Hero "Continue Reading" card                                        */
/* ------------------------------------------------------------------ */

function ContinueCard({ story }: { story: Story }) {
  const scale = useRef(new Animated.Value(1)).current;

  const animateTo = (value: number) =>
    Animated.timing(scale, {
      toValue: value,
      duration: 120,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();

  return (
    <Animated.View style={{ transform: [{ scale }], marginTop: spacing.xl }}>
      <Pressable
        onPressIn={() => animateTo(0.98)}
        onPressOut={() => animateTo(1)}
        onPress={() => router.push(`/child/story/${story.id}` as any)}
      >
        <LinearGradient
          colors={[colors.heroGradientStart, colors.heroGradientEnd]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            borderRadius: radius.lg,
            padding: 20,
            flexDirection: "row",
            alignItems: "center",
            shadowColor: "#000",
            shadowOpacity: 0.15,
            shadowRadius: 12,
            elevation: 6,
          }}
        >
          <Image
            source={story.image}
            style={{ width: 64, height: 64, resizeMode: "contain" }}
          />

          <View style={{ marginLeft: spacing.md, flex: 1 }}>
            <Text style={{ color: "#DCEBFF", fontSize: 12, fontWeight: "600" }}>
              CONTINUE READING
            </Text>
            <Text
              style={{
                color: "#fff",
                fontSize: 18,
                fontWeight: "bold",
                marginTop: 2,
              }}
            >
              {story.title}
            </Text>

            <View
              style={{
                height: 6,
                backgroundColor: "rgba(255,255,255,0.3)",
                borderRadius: 3,
                marginTop: 10,
              }}
            >
              <View
                style={{
                  height: 6,
                  width: `${Math.round((story.progress ?? 0) * 100)}%`,
                  backgroundColor: "#fff",
                  borderRadius: 3,
                }}
              />
            </View>
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

/* ------------------------------------------------------------------ */
/* Grid tile — image fills the card, gradient overlay carries title   */
/* ------------------------------------------------------------------ */

function StoryTile({ story }: { story: Story }) {
  const scale = useRef(new Animated.Value(1)).current;

  const animateTo = (value: number) =>
    Animated.spring(scale, {
      toValue: value,
      useNativeDriver: true,
      speed: 40,
      bounciness: 4,
    }).start();

  return (
    <Animated.View
      style={{ transform: [{ scale }], width: "48%", marginBottom: spacing.md }}
    >
      <Pressable
        onPressIn={() => animateTo(0.97)}
        onPressOut={() => animateTo(1)}
        onPress={() => router.push(`/child/story/${story.id}` as any)}
        style={{
          borderRadius: radius.md,
          overflow: "hidden",
          backgroundColor: story.color,
          shadowColor: "#000",
          shadowOpacity: 0.08,
          shadowRadius: 8,
          elevation: 4,
        }}
      >
        <View
          style={{
            height: 130,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Image
            source={story.image}
            style={{ width: 88, height: 88, resizeMode: "contain" }}
          />
        </View>

        <LinearGradient
          colors={["rgba(0,0,0,0)", "rgba(0,0,0,0.55)"]}
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            height: 70,
            justifyContent: "flex-end",
            padding: 10,
          }}
        >
          <Text
            style={{ color: "#fff", fontWeight: "bold", fontSize: 14 }}
            numberOfLines={1}
          >
            {story.title}
          </Text>
          <Text style={{ color: "#E2E8F0", fontSize: 11, marginTop: 2 }}>
            ⏱ {story.minutes}
          </Text>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

/* ------------------------------------------------------------------ */
/* Floating action button for creating a new story                    */
/* ------------------------------------------------------------------ */

function NewStoryFab() {
  const scale = useRef(new Animated.Value(1)).current;

  const animateTo = (value: number) =>
    Animated.timing(scale, {
      toValue: value,
      duration: 120,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();

  return (
    <Animated.View
      style={{
        transform: [{ scale }],
        position: "absolute",
        right: spacing.lg,
        bottom: 100,
        shadowColor: "#000",
        shadowOpacity: 0.25,
        shadowRadius: 10,
        elevation: 8,
      }}
    >
      <Pressable
        onPressIn={() => animateTo(0.92)}
        onPressOut={() => animateTo(1)}
      >
        <LinearGradient
          colors={[colors.ctaGradientStart, colors.ctaGradientEnd]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            width: 58,
            height: 58,
            borderRadius: 29,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Plus size={26} color="#fff" />
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}
