import React, { useMemo } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  useFonts,
} from "@expo-google-fonts/tajawal";

type ChallengeType = "saving" | "tasks" | "spending";
type ChallengeStatus = "active" | "pending" | "completed";

type Activity = {
  id: string;
  person: string;
  emoji: string;
  text: string;
  time: string;
  points: string;
};

type ChallengeTask = {
  id: string;
  title: string;
  childDone: boolean;
  friendDone: boolean;
  points: number;
};

type ChallengeDetails = {
  id: string;
  title: string;
  subtitle: string;
  type: ChallengeType;
  status: ChallengeStatus;

  childName: string;
  childEmoji: string;
  childProgress: number;
  childValue: string;

  friendName: string;
  friendEmoji: string;
  friendProgress: number;
  friendValue: string;

  remainingDays: string;
  target: string;
  prize: string;
  endDate: string;
  level: string;

  itemName?: string;
  itemPrice?: string;

  colors: readonly [string, string, ...string[]];

  activities: Activity[];
  tasks?: ChallengeTask[];
};

const CHALLENGES: Record<string, ChallengeDetails> = {
  "saving-bike": {
    id: "saving-bike",
    title: "تحدي الدراجة الجديدة",
    subtitle: "من يستطيع الوصول إلى هدف الادخار أولًا؟",
    type: "saving",
    status: "active",

    childName: "سلمان",
    childEmoji: "👦🏻",
    childProgress: 75,
    childValue: "375 ريال",

    friendName: "خالد",
    friendEmoji: "🧒🏻",
    friendProgress: 62,
    friendValue: "310 ريال",

    remainingDays: "3 أيام",
    target: "ادخار 500 ريال",
    prize: "100 نقطة",
    endDate: "18 يوليو 2026",
    level: "متوسط",

    itemName: "دراجة جديدة",
    itemPrice: "500 ريال",

    colors: ["#FF2E63", "#FF4B58", "#FF7A4D"],

    activities: [
      {
        id: "1",
        person: "سلمان",
        emoji: "👦🏻",
        text: "أضاف 50 ريال إلى مدخراته",
        time: "اليوم 9:20 ص",
        points: "+50",
      },
      {
        id: "2",
        person: "خالد",
        emoji: "🧒🏻",
        text: "أضاف 30 ريال إلى مدخراته",
        time: "أمس 7:15 م",
        points: "+30",
      },
      {
        id: "3",
        person: "سلمان",
        emoji: "👦🏻",
        text: "أكمل مهمة ادخار جديدة",
        time: "16 يوليو 3:40 م",
        points: "+20",
      },
    ],
  },

  "room-tasks": {
    id: "room-tasks",
    title: "تحدي أبطال المهام",
    subtitle: "من ينجز أكبر عدد من المهام اليومية؟",
    type: "tasks",
    status: "active",

    childName: "لمار",
    childEmoji: "👧🏻",
    childProgress: 80,
    childValue: "8 مهام",

    friendName: "جود",
    friendEmoji: "👧🏼",
    friendProgress: 60,
    friendValue: "6 مهام",

    remainingDays: "يومان",
    target: "إكمال 10 مهام",
    prize: "نجمة ذهبية",
    endDate: "20 يوليو 2026",
    level: "سهل",

    colors: ["#7147F3", "#925CF8", "#B77CFF"],

    activities: [
      {
        id: "1",
        person: "لمار",
        emoji: "👧🏻",
        text: "أكملت مهمة ترتيب الغرفة",
        time: "اليوم 10:10 ص",
        points: "+10",
      },
      {
        id: "2",
        person: "جود",
        emoji: "👧🏼",
        text: "أكملت مهمة القراءة",
        time: "أمس 6:30 م",
        points: "+10",
      },
    ],

    tasks: [
      {
        id: "1",
        title: "ترتيب الغرفة",
        childDone: true,
        friendDone: true,
        points: 10,
      },
      {
        id: "2",
        title: "القراءة لمدة 20 دقيقة",
        childDone: true,
        friendDone: false,
        points: 15,
      },
      {
        id: "3",
        title: "إكمال الواجب",
        childDone: true,
        friendDone: true,
        points: 20,
      },
      {
        id: "4",
        title: "مساعدة الأسرة",
        childDone: false,
        friendDone: false,
        points: 15,
      },
    ],
  },

  "smart-spending": {
    id: "smart-spending",
    title: "تحدي المصروف الذكي",
    subtitle: "من يدير مصروفه بشكل أفضل؟",
    type: "spending",
    status: "pending",

    childName: "سارة",
    childEmoji: "👧🏽",
    childProgress: 0,
    childValue: "لم يبدأ",

    friendName: "نورة",
    friendEmoji: "👧🏻",
    friendProgress: 0,
    friendValue: "لم يبدأ",

    remainingDays: "بانتظار الموافقة",
    target: "تقليل المشتريات العشوائية",
    prize: "80 نقطة",
    endDate: "بعد الموافقة",
    level: "متوسط",

    colors: ["#0F9D78", "#23BB8B", "#53D5A8"],

    activities: [],
  },
};

export default function ChallengeDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
  });

  const challenge = useMemo(() => {
    if (typeof id === "string" && CHALLENGES[id]) {
      return CHALLENGES[id];
    }

    return CHALLENGES["saving-bike"];
  }, [id]);

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingScreen}>
        <Text style={styles.loadingText}>
          جاري تحميل التحدي...
        </Text>
      </View>
    );
  }

  const typeDetails = getTypeDetails(challenge.type);
  const statusDetails = getStatusDetails(challenge.status);

  return (
    <View style={styles.screen}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <LinearGradient
          colors={challenge.colors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <SafeAreaView edges={["top"]}>
            <View style={styles.largeDecorationLeft}>
              <Ionicons
                name={typeDetails.decoration}
                size={190}
                color="rgba(255,255,255,0.08)"
              />
            </View>

            <View style={styles.largeDecorationRight}>
              <Ionicons
                name={typeDetails.decoration}
                size={135}
                color="rgba(255,255,255,0.09)"
              />
            </View>

            <View style={styles.sparkDecoration}>
              <Ionicons
                name="sparkles"
                size={26}
                color="rgba(255,255,255,0.55)"
              />
            </View>

            <View style={styles.headerRow}>
              <Pressable style={styles.headerButton}>
                <Ionicons
                  name="ellipsis-horizontal"
                  size={25}
                  color="#FFFFFF"
                />
              </Pressable>

              <View style={styles.headerBadge}>
                <Ionicons
                  name={typeDetails.icon}
                  size={19}
                  color="#FFFFFF"
                />

                <Text style={styles.headerBadgeText}>
                  {typeDetails.label}
                </Text>
              </View>

              <Pressable
                onPress={() => router.back()}
                style={styles.headerButton}
              >
                <Ionicons
                  name="chevron-forward"
                  size={26}
                  color="#FFFFFF"
                />
              </Pressable>
            </View>

            <View style={styles.titleArea}>
              <Text style={styles.challengeTitle}>
                {challenge.title}
              </Text>

              <Text style={styles.challengeSubtitle}>
                {challenge.subtitle}
              </Text>
            </View>

            <View style={styles.competitorsRow}>
              <Competitor
                name={challenge.childName}
                emoji={challenge.childEmoji}
                progress={challenge.childProgress}
                value={challenge.childValue}
              />

              <View style={styles.centerArea}>
                <View style={styles.vsCircle}>
                  <Ionicons
                    name="flame"
                    size={30}
                    color="#FF8B2E"
                  />

                  <Text style={styles.vsText}>VS</Text>
                </View>

                <View style={styles.remainingBox}>
                  <Ionicons
                    name="time-outline"
                    size={18}
                    color="#FFFFFF"
                  />

                  <Text style={styles.remainingLabel}>
                    متبقي
                  </Text>

                  <Text style={styles.remainingValue}>
                    {challenge.remainingDays}
                  </Text>
                </View>
              </View>

              <Competitor
                name={challenge.friendName}
                emoji={challenge.friendEmoji}
                progress={challenge.friendProgress}
                value={challenge.friendValue}
              />
            </View>
          </SafeAreaView>
        </LinearGradient>

        <View style={styles.mainContent}>
          <View style={styles.detailsCard}>
            <View style={styles.cardHeader}>
              <View style={styles.cardHeaderIcon}>
                <Ionicons
                  name="document-text-outline"
                  size={22}
                  color={challenge.colors[0]}
                />
              </View>

              <View style={styles.cardHeaderTextArea}>
                <Text style={styles.cardTitle}>
                  تفاصيل التحدي
                </Text>

                <Text style={styles.cardSubtitle}>
                  المعلومات الأساسية للمنافسة
                </Text>
              </View>
            </View>

            <View style={styles.detailsGrid}>
              <DetailItem
                icon="flag-outline"
                label="الهدف"
                value={challenge.target}
                color={challenge.colors[0]}
              />

              <View style={styles.detailDivider} />

              <DetailItem
                icon="calendar-outline"
                label="تاريخ النهاية"
                value={challenge.endDate}
                color="#E72D73"
              />

              <View style={styles.detailDivider} />

              <DetailItem
                icon="trophy-outline"
                label="الجائزة"
                value={challenge.prize}
                color="#F2A316"
              />
            </View>

            <View style={styles.secondaryDetailsRow}>
              <View style={styles.secondaryDetail}>
                <Ionicons
                  name="speedometer-outline"
                  size={21}
                  color="#7163DD"
                />

                <Text style={styles.secondaryLabel}>
                  المستوى
                </Text>

                <Text style={styles.secondaryValue}>
                  {challenge.level}
                </Text>
              </View>

              <View style={styles.secondaryDetail}>
                <Ionicons
                  name="shield-checkmark-outline"
                  size={21}
                  color={statusDetails.color}
                />

                <Text style={styles.secondaryLabel}>
                  الحالة
                </Text>

                <Text
                  style={[
                    styles.secondaryValue,
                    {
                      color: statusDetails.color,
                    },
                  ]}
                >
                  {statusDetails.label}
                </Text>
              </View>
            </View>

            {challenge.type === "saving" && (
              <View style={styles.itemGoalBox}>
                <View style={styles.itemGoalIcon}>
                  <Ionicons
                    name="gift-outline"
                    size={27}
                    color={challenge.colors[0]}
                  />
                </View>

                <View style={styles.itemGoalTextArea}>
                  <Text style={styles.itemGoalLabel}>
                    الغرض المستهدف
                  </Text>

                  <Text style={styles.itemGoalTitle}>
                    {challenge.itemName}
                  </Text>

                  <Text style={styles.itemGoalPrice}>
                    القيمة: {challenge.itemPrice}
                  </Text>
                </View>
              </View>
            )}
          </View>

          {challenge.type === "tasks" && challenge.tasks && (
            <View style={styles.tasksCard}>
              <View style={styles.cardHeader}>
                <View style={styles.cardHeaderIcon}>
                  <Ionicons
                    name="checkbox-outline"
                    size={22}
                    color={challenge.colors[0]}
                  />
                </View>

                <View style={styles.cardHeaderTextArea}>
                  <Text style={styles.cardTitle}>
                    مهام التحدي
                  </Text>

                  <Text style={styles.cardSubtitle}>
                    متابعة إنجاز كل طفل
                  </Text>
                </View>
              </View>

              <View style={styles.tasksNamesRow}>
                <Text style={styles.taskPersonName}>
                  {challenge.childName}
                </Text>

                <Text style={styles.taskNameHeading}>
                  المهمة
                </Text>

                <Text style={styles.taskPersonName}>
                  {challenge.friendName}
                </Text>
              </View>

              {challenge.tasks.map((task) => (
                <View key={task.id} style={styles.taskRow}>
                  <StatusCircle done={task.childDone} />

                  <View style={styles.taskCenter}>
                    <Text style={styles.taskTitle}>
                      {task.title}
                    </Text>

                    <View style={styles.taskPointsBadge}>
                      <Ionicons
                        name="star"
                        size={12}
                        color="#F1A411"
                      />

                      <Text style={styles.taskPointsText}>
                        {task.points} نقطة
                      </Text>
                    </View>
                  </View>

                  <StatusCircle done={task.friendDone} />
                </View>
              ))}
            </View>
          )}

          <View style={styles.activitiesCard}>
            <View style={styles.cardHeader}>
              <View style={styles.cardHeaderIcon}>
                <Ionicons
                  name="pulse-outline"
                  size={22}
                  color={challenge.colors[0]}
                />
              </View>

              <View style={styles.cardHeaderTextArea}>
                <Text style={styles.cardTitle}>
                  آخر النشاطات
                </Text>

                <Text style={styles.cardSubtitle}>
                  آخر التحديثات في التحدي
                </Text>
              </View>
            </View>

            {challenge.activities.length > 0 ? (
              challenge.activities.map((activity, index) => (
                <View
                  key={activity.id}
                  style={[
                    styles.activityRow,
                    index !== challenge.activities.length - 1 &&
                      styles.activityBorder,
                  ]}
                >
                  <View style={styles.activityPoints}>
                    <Text style={styles.activityPointsText}>
                      {activity.points}
                    </Text>
                  </View>

                  <View style={styles.activityTextArea}>
                    <Text style={styles.activityText}>
                      <Text style={styles.activityPerson}>
                        {activity.person}
                      </Text>{" "}
                      {activity.text.replace(
                        `${activity.person} `,
                        ""
                      )}
                    </Text>

                    <Text style={styles.activityTime}>
                      {activity.time}
                    </Text>
                  </View>

                  <View style={styles.activityAvatar}>
                    <Text style={styles.activityEmoji}>
                      {activity.emoji}
                    </Text>
                  </View>
                </View>
              ))
            ) : (
              <View style={styles.emptyActivities}>
                <View style={styles.emptyActivitiesIcon}>
                  <Ionicons
                    name="hourglass-outline"
                    size={30}
                    color={challenge.colors[0]}
                  />
                </View>

                <Text style={styles.emptyActivitiesTitle}>
                  لم يبدأ التحدي بعد
                </Text>

                <Text style={styles.emptyActivitiesText}>
                  ستظهر النشاطات هنا بعد موافقة ولي الأمر
                </Text>
              </View>
            )}
          </View>

          <View style={styles.actionsRow}>
            <Pressable
              style={({ pressed }) => [
                styles.stopButton,
                pressed && styles.buttonPressed,
              ]}
            >
              <Ionicons
                name="alert-circle-outline"
                size={22}
                color="#EA3560"
              />

              <Text style={styles.stopButtonText}>
                إيقاف التحدي
              </Text>
            </Pressable>

            <Pressable
              style={({ pressed }) => [
                styles.reportButton,
                pressed && styles.buttonPressed,
              ]}
            >
              <LinearGradient
                colors={challenge.colors}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.reportGradient}
              >
                <Ionicons
                  name="stats-chart"
                  size={21}
                  color="#FFFFFF"
                />

                <Text style={styles.reportButtonText}>
                  عرض تقرير التحدي
                </Text>
              </LinearGradient>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function Competitor({
  name,
  emoji,
  progress,
  value,
}: {
  name: string;
  emoji: string;
  progress: number;
  value: string;
}) {
  return (
    <View style={styles.competitor}>
      <View style={styles.avatarOuter}>
        <View style={styles.avatarInner}>
          <Text style={styles.avatarEmoji}>{emoji}</Text>
        </View>
      </View>

      <Text style={styles.competitorName}>{name}</Text>

      <View style={styles.progressBadge}>
        <Text style={styles.progressBadgeText}>
          {progress}%
        </Text>
      </View>

      <View style={styles.progressTrack}>
        <LinearGradient
          colors={["#FFFFFF", "#FFD58A"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[
            styles.progressFill,
            {
              width: `${Math.min(progress, 100)}%`,
            },
          ]}
        />
      </View>

      <Text style={styles.competitorValue}>{value}</Text>
    </View>
  );
}

function DetailItem({
  icon,
  label,
  value,
  color,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <View style={styles.detailItem}>
      <View
        style={[
          styles.detailIcon,
          {
            backgroundColor: `${color}14`,
          },
        ]}
      >
        <Ionicons name={icon} size={22} color={color} />
      </View>

      <Text style={styles.detailLabel}>{label}</Text>

      <Text style={styles.detailValue}>{value}</Text>
    </View>
  );
}

function StatusCircle({ done }: { done: boolean }) {
  return (
    <View
      style={[
        styles.statusCircle,
        done && styles.statusCircleDone,
      ]}
    >
      <Ionicons
        name={done ? "checkmark" : "remove"}
        size={18}
        color={done ? "#FFFFFF" : "#A2A4B0"}
      />
    </View>
  );
}

function getTypeDetails(type: ChallengeType): {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  decoration: keyof typeof Ionicons.glyphMap;
} {
  switch (type) {
    case "saving":
      return {
        label: "هدف ادخاري",
        icon: "wallet-outline",
        decoration: "flame",
      };

    case "tasks":
      return {
        label: "تحدي مهام",
        icon: "checkbox-outline",
        decoration: "star",
      };

    case "spending":
      return {
        label: "مصروف ذكي",
        icon: "card-outline",
        decoration: "sparkles",
      };
  }
}

function getStatusDetails(status: ChallengeStatus) {
  switch (status) {
    case "active":
      return {
        label: "نشط الآن",
        color: "#1EA675",
      };

    case "pending":
      return {
        label: "بانتظار الموافقة",
        color: "#E58D19",
      };

    case "completed":
      return {
        label: "مكتمل",
        color: "#6D55D8",
      };
  }
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#F7F7FA",
  },

  loadingScreen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  loadingText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 16,
    color: "#777988",
  },

  scrollContent: {
    paddingBottom: 55,
  },

  hero: {
    minHeight: 650,
    paddingBottom: 70,
    overflow: "hidden",
  },

  largeDecorationLeft: {
    position: "absolute",
    left: -55,
    bottom: 35,
    transform: [{ rotate: "-13deg" }],
  },

  largeDecorationRight: {
    position: "absolute",
    right: -20,
    top: 115,
    transform: [{ rotate: "15deg" }],
  },

  sparkDecoration: {
    position: "absolute",
    top: 150,
    left: 35,
  },

  headerRow: {
    paddingHorizontal: 19,
    paddingTop: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  headerButton: {
    width: 47,
    height: 47,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.15)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.24)",
  },

  headerBadge: {
    minHeight: 40,
    paddingHorizontal: 17,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    backgroundColor: "rgba(116,0,36,0.22)",
  },

  headerBadgeText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: "#FFFFFF",
  },

  titleArea: {
    marginTop: 30,
    paddingHorizontal: 25,
    alignItems: "center",
  },

  challengeTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 33,
    lineHeight: 43,
    color: "#FFFFFF",
    textAlign: "center",
    writingDirection: "rtl",
  },

  challengeSubtitle: {
    marginTop: 5,
    fontFamily: "Tajawal_500Medium",
    fontSize: 16,
    lineHeight: 24,
    color: "rgba(255,255,255,0.90)",
    textAlign: "center",
    writingDirection: "rtl",
  },

  competitorsRow: {
    marginTop: 34,
    paddingHorizontal: 15,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },

  competitor: {
    width: "34%",
    alignItems: "center",
  },

  avatarOuter: {
    width: 105,
    height: 105,
    borderRadius: 53,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.22)",
    borderWidth: 3,
    borderColor: "#FFFFFF",
  },

  avatarInner: {
    width: 91,
    height: 91,
    borderRadius: 46,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0E9",
    overflow: "hidden",
  },

  avatarEmoji: {
    fontSize: 59,
  },

  competitorName: {
    marginTop: 10,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 22,
    color: "#FFFFFF",
  },

  progressBadge: {
    marginTop: 5,
    minWidth: 65,
    height: 34,
    paddingHorizontal: 11,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(127,0,38,0.22)",
  },

  progressBadgeText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 17,
    color: "#FFFFFF",
  },

  progressTrack: {
    width: "100%",
    height: 10,
    marginTop: 13,
    borderRadius: 6,
    backgroundColor: "rgba(255,255,255,0.40)",
    overflow: "hidden",
  },

  progressFill: {
    height: "100%",
    borderRadius: 6,
  },

  competitorValue: {
    marginTop: 8,
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "#FFFFFF",
  },

  centerArea: {
    width: "27%",
    alignItems: "center",
    paddingTop: 25,
  },

  vsCircle: {
    width: 86,
    height: 86,
    borderRadius: 43,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    shadowColor: "#A30A36",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.22,
    shadowRadius: 13,
    elevation: 8,
  },

  vsText: {
    marginTop: -6,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 25,
    color: "#FF3A5E",
  },

  remainingBox: {
    marginTop: 27,
    minWidth: 92,
    minHeight: 94,
    padding: 10,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(130,0,38,0.18)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.28)",
  },

  remainingLabel: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "rgba(255,255,255,0.80)",
  },

  remainingValue: {
    marginTop: 1,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 17,
    color: "#FFFFFF",
    textAlign: "center",
  },

  mainContent: {
    marginTop: -55,
    paddingHorizontal: 17,
  },

  detailsCard: {
    padding: 17,
    borderRadius: 29,
    backgroundColor: "#FFFFFF",
    shadowColor: "#30313F",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.11,
    shadowRadius: 18,
    elevation: 7,
  },

  cardHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },

  cardHeaderIcon: {
    width: 45,
    height: 45,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  cardHeaderTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  cardTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 20,
    color: "#2C2E3E",
  },

  cardSubtitle: {
    marginTop: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "#9698A6",
  },

  detailsGrid: {
    marginTop: 22,
    flexDirection: "row",
    alignItems: "flex-start",
  },

  detailItem: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 5,
  },

  detailIcon: {
    width: 45,
    height: 45,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },

  detailLabel: {
    marginTop: 7,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#9698A7",
  },

  detailValue: {
    marginTop: 3,
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    lineHeight: 18,
    color: "#383A49",
    textAlign: "center",
    writingDirection: "rtl",
  },

  detailDivider: {
    width: 1,
    height: 75,
    backgroundColor: "#ECECF1",
  },

  secondaryDetailsRow: {
    marginTop: 18,
    flexDirection: "row",
    gap: 10,
  },

  secondaryDetail: {
    flex: 1,
    minHeight: 77,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F8F8FB",
  },

  secondaryLabel: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#989AA8",
  },

  secondaryValue: {
    marginTop: 2,
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: "#434555",
  },

  itemGoalBox: {
    marginTop: 15,
    padding: 14,
    borderRadius: 20,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 12,
    backgroundColor: "#FFF3F5",
  },

  itemGoalIcon: {
    width: 54,
    height: 54,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  itemGoalTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  itemGoalLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#999BA9",
  },

  itemGoalTitle: {
    marginTop: 1,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#373948",
  },

  itemGoalPrice: {
    marginTop: 2,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "#737584",
  },

  tasksCard: {
    marginTop: 17,
    padding: 17,
    borderRadius: 27,
    backgroundColor: "#FFFFFF",
    shadowColor: "#30313F",
    shadowOffset: {
      width: 0,
      height: 9,
    },
    shadowOpacity: 0.08,
    shadowRadius: 15,
    elevation: 5,
  },

  tasksNamesRow: {
    marginTop: 20,
    paddingHorizontal: 5,
    flexDirection: "row",
    alignItems: "center",
  },

  taskPersonName: {
    width: 60,
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: "#747685",
    textAlign: "center",
  },

  taskNameHeading: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: "#474957",
    textAlign: "center",
  },

  taskRow: {
    minHeight: 72,
    marginTop: 9,
    paddingHorizontal: 9,
    borderRadius: 19,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#F8F8FB",
  },

  statusCircle: {
    width: 35,
    height: 35,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#E7E8ED",
  },

  statusCircleDone: {
    backgroundColor: "#22B381",
  },

  taskCenter: {
    flex: 1,
    alignItems: "center",
  },

  taskTitle: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: "#3F414F",
    textAlign: "center",
  },

  taskPointsBadge: {
    marginTop: 5,
    paddingHorizontal: 8,
    height: 23,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    backgroundColor: "#FFF5DA",
  },

  taskPointsText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10,
    color: "#C6840B",
  },

  activitiesCard: {
    marginTop: 17,
    padding: 17,
    borderRadius: 27,
    backgroundColor: "#FFFFFF",
    shadowColor: "#30313F",
    shadowOffset: {
      width: 0,
      height: 9,
    },
    shadowOpacity: 0.08,
    shadowRadius: 15,
    elevation: 5,
  },

  activityRow: {
    minHeight: 88,
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
  },

  activityBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#EFEFF3",
  },

  activityPoints: {
    minWidth: 55,
    height: 44,
    paddingHorizontal: 10,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  activityPointsText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#ED4062",
  },

  activityTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  activityText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "#565867",
    textAlign: "right",
    writingDirection: "rtl",
  },

  activityPerson: {
    fontFamily: "Tajawal_800ExtraBold",
    color: "#E93760",
  },

  activityTime: {
    marginTop: 4,
    fontFamily: "Tajawal_400Regular",
    fontSize: 11,
    color: "#9B9DAA",
  },

  activityAvatar: {
    width: 49,
    height: 49,
    borderRadius: 25,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF1EA",
  },

  activityEmoji: {
    fontSize: 29,
  },

  emptyActivities: {
    paddingVertical: 30,
    alignItems: "center",
  },

  emptyActivitiesIcon: {
    width: 68,
    height: 68,
    borderRadius: 23,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  emptyActivitiesTitle: {
    marginTop: 12,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#3D3F4E",
  },

  emptyActivitiesText: {
    marginTop: 4,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "#9799A6",
    textAlign: "center",
  },

  actionsRow: {
    marginTop: 18,
    flexDirection: "row",
    gap: 10,
  },

  stopButton: {
    flex: 0.9,
    minHeight: 59,
    borderRadius: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    backgroundColor: "#FFF0F3",
    borderWidth: 1,
    borderColor: "#FFD9E1",
  },

  stopButtonText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: "#E93560",
  },

  reportButton: {
    flex: 1.35,
    minHeight: 59,
    borderRadius: 20,
    overflow: "hidden",
  },

  reportGradient: {
    flex: 1,
    minHeight: 59,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  reportButtonText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: "#FFFFFF",
  },

  buttonPressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
});