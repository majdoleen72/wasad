import React, { useMemo, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  useFonts,
} from "@expo-google-fonts/tajawal";

type ChallengeType = "saving" | "tasks" | "spending";

type Child = {
  id: string;
  name: string;
  age: number;
  emoji: string;
};

type Family = {
  id: string;
  parentName: string;
  username: string;
  familyName: string;
  childrenCount: number;
  emoji: string;
};

const CHILDREN: Child[] = [
  {
    id: "child-1",
    name: "سلمان",
    age: 11,
    emoji: "👦🏻",
  },
  {
    id: "child-2",
    name: "لمار",
    age: 9,
    emoji: "👧🏻",
  },
  {
    id: "child-3",
    name: "ريان",
    age: 7,
    emoji: "🧒🏽",
  },
];

const FAMILIES: Family[] = [
  {
    id: "family-1",
    parentName: "أبو خالد",
    username: "@family_khaled",
    familyName: "عائلة خالد",
    childrenCount: 3,
    emoji: "👨‍👩‍👧‍👦",
  },
  {
    id: "family-2",
    parentName: "أم جود",
    username: "@joud_family",
    familyName: "عائلة جود",
    childrenCount: 2,
    emoji: "👩‍👧‍👦",
  },
  {
    id: "family-3",
    parentName: "أبو مازن",
    username: "WASD-4281",
    familyName: "عائلة مازن",
    childrenCount: 4,
    emoji: "👨‍👩‍👧‍👦",
  },
];

const CHALLENGE_TYPES = [
  {
    id: "saving" as ChallengeType,
    title: "هدف ادخاري",
    description: "التنافس على الادخار للوصول إلى غرض معين",
    icon: "wallet-outline" as const,
    colors: ["#FF416C", "#FF7657"] as const,
  },
  {
    id: "tasks" as ChallengeType,
    title: "تحدي مهام",
    description: "إنجاز مجموعة من المهام خلال مدة محددة",
    icon: "checkbox-outline" as const,
    colors: ["#7049F5", "#A477FF"] as const,
  },
  {
    id: "spending" as ChallengeType,
    title: "مصروف ذكي",
    description: "إدارة المصروف وتقليل المشتريات العشوائية",
    icon: "card-outline" as const,
    colors: ["#0EA77A", "#52D3A5"] as const,
  },
];

export default function CreateChallengeScreen() {
  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
  });

  const [selectedChildren, setSelectedChildren] = useState<string[]>([
    "child-1",
  ]);

  const [familySearch, setFamilySearch] = useState("");
  const [invitedFamilies, setInvitedFamilies] = useState<Family[]>([]);

  const [challengeType, setChallengeType] =
    useState<ChallengeType>("saving");

  const [challengeTitle, setChallengeTitle] = useState("");
  const [description, setDescription] = useState("");

  const [itemName, setItemName] = useState("");
  const [targetAmount, setTargetAmount] = useState("");

  const [duration, setDuration] = useState("7");
  const [prize, setPrize] = useState("");

  const [tasks, setTasks] = useState([
    "ترتيب الغرفة",
    "القراءة لمدة 20 دقيقة",
  ]);

  const [newTask, setNewTask] = useState("");

  const foundFamilies = useMemo(() => {
    const searchValue = familySearch.trim().toLowerCase();

    if (!searchValue) {
      return [];
    }

    return FAMILIES.filter((family) => {
      const isAlreadyInvited = invitedFamilies.some(
        (invitedFamily) => invitedFamily.id === family.id
      );

      if (isAlreadyInvited) {
        return false;
      }

      return (
        family.parentName.toLowerCase().includes(searchValue) ||
        family.username.toLowerCase().includes(searchValue) ||
        family.familyName.toLowerCase().includes(searchValue)
      );
    });
  }, [familySearch, invitedFamilies]);

  const toggleChild = (childId: string) => {
    setSelectedChildren((currentChildren) => {
      const isSelected = currentChildren.includes(childId);

      if (isSelected) {
        return currentChildren.filter((id) => id !== childId);
      }

      return [...currentChildren, childId];
    });
  };

  const inviteFamily = (family: Family) => {
    setInvitedFamilies((currentFamilies) => [
      ...currentFamilies,
      family,
    ]);

    setFamilySearch("");
  };

  const removeInvitedFamily = (familyId: string) => {
    setInvitedFamilies((currentFamilies) =>
      currentFamilies.filter((family) => family.id !== familyId)
    );
  };

  const addTask = () => {
    const cleanTask = newTask.trim();

    if (!cleanTask) {
      return;
    }

    setTasks((currentTasks) => [...currentTasks, cleanTask]);
    setNewTask("");
  };

  const removeTask = (taskIndex: number) => {
    setTasks((currentTasks) =>
      currentTasks.filter((_, index) => index !== taskIndex)
    );
  };

  const createChallenge = () => {
    if (selectedChildren.length === 0) {
      Alert.alert(
        "اختاري طفلًا",
        "يجب اختيار طفل واحد على الأقل من أطفالك."
      );
      return;
    }

    if (invitedFamilies.length === 0) {
      Alert.alert(
        "أضيفي عائلة",
        "أضيفي ولي أمر واحدًا على الأقل لإرسال دعوة التحدي."
      );
      return;
    }

    if (!challengeTitle.trim()) {
      Alert.alert(
        "اسم التحدي",
        "اكتبي اسمًا واضحًا للتحدي قبل إرساله."
      );
      return;
    }

    Alert.alert(
      "تم إنشاء التحدي 🔥",
      "تم إرسال الدعوة إلى أولياء الأمور، وسيبدأ التحدي بعد قبولهم واختيار أطفالهم.",
      [
        {
          text: "حسنًا",
          onPress: () => {
            router.replace("/parent/challenges" as any);
          },
        },
      ]
    );
  };

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingScreen}>
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <LinearGradient
        colors={["#FF2D62", "#FF5361", "#FF8052"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <SafeAreaView edges={["top"]}>
          <View style={styles.flameOne}>
            <Ionicons
              name="flame"
              size={175}
              color="rgba(255,255,255,0.08)"
            />
          </View>

          <View style={styles.flameTwo}>
            <Ionicons
              name="flame"
              size={110}
              color="rgba(255,255,255,0.10)"
            />
          </View>

          <View style={styles.sparkOne}>
            <Ionicons
              name="sparkles"
              size={24}
              color="rgba(255,255,255,0.50)"
            />
          </View>

          <View style={styles.headerTop}>
            <View style={styles.headerSpacer} />

            <View style={styles.headerTitleArea}>
              <Text style={styles.headerTitle}>إنشاء تحدي</Text>

              <Text style={styles.headerSubtitle}>
                اجمع أطفال العائلات في منافسة ممتعة وآمنة
              </Text>
            </View>

            <Pressable
              onPress={() => router.back()}
              style={({ pressed }) => [
                styles.backButton,
                pressed && styles.pressedButton,
              ]}
            >
              <Ionicons
                name="chevron-forward"
                size={25}
                color="#FFFFFF"
              />
            </Pressable>
          </View>

          <View style={styles.headerSummary}>
            <View style={styles.headerSummaryItem}>
              <View style={styles.headerSummaryIcon}>
                <Ionicons
                  name="happy-outline"
                  size={22}
                  color="#FF4063"
                />
              </View>

              <View>
                <Text style={styles.headerSummaryNumber}>
                  {selectedChildren.length}
                </Text>
                <Text style={styles.headerSummaryLabel}>
                  من أطفالك
                </Text>
              </View>
            </View>

            <View style={styles.headerSummaryDivider} />

            <View style={styles.headerSummaryItem}>
              <View style={styles.headerSummaryIcon}>
                <Ionicons
                  name="mail-outline"
                  size={22}
                  color="#FF4063"
                />
              </View>

              <View>
                <Text style={styles.headerSummaryNumber}>
                  {invitedFamilies.length}
                </Text>
                <Text style={styles.headerSummaryLabel}>
                  عائلات مدعوة
                </Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>

      <View style={styles.contentSheet}>
        <KeyboardAvoidingView
          style={styles.keyboardView}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scrollContent}
          >
            <SectionHeader
              number="1"
              title="المشاركون من عائلتك"
              description="اختاري طفلًا أو أكثر للمشاركة في التحدي"
              icon="happy-outline"
            />

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.childrenRow}
            >
              {CHILDREN.map((child) => {
                const selected = selectedChildren.includes(child.id);

                return (
                  <Pressable
                    key={child.id}
                    onPress={() => toggleChild(child.id)}
                    style={({ pressed }) => [
                      styles.childCard,
                      selected && styles.selectedChildCard,
                      pressed && styles.smallPressed,
                    ]}
                  >
                    <View
                      style={[
                        styles.childSelectionCircle,
                        selected &&
                          styles.selectedChildSelectionCircle,
                      ]}
                    >
                      {selected ? (
                        <Ionicons
                          name="checkmark"
                          size={15}
                          color="#FFFFFF"
                        />
                      ) : (
                        <Ionicons
                          name="add"
                          size={15}
                          color="#9A9BA8"
                        />
                      )}
                    </View>

                    <View
                      style={[
                        styles.childAvatar,
                        selected && styles.selectedChildAvatar,
                      ]}
                    >
                      <Text style={styles.childEmoji}>
                        {child.emoji}
                      </Text>
                    </View>

                    <Text
                      style={[
                        styles.childName,
                        selected && styles.selectedChildName,
                      ]}
                    >
                      {child.name}
                    </Text>

                    <Text style={styles.childAge}>
                      {child.age} سنوات
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>

            <View style={styles.selectionHint}>
              <Ionicons
                name="information-circle-outline"
                size={20}
                color="#7358DF"
              />

              <Text style={styles.selectionHintText}>
                يمكن لأكثر من طفل من عائلتك المشاركة في نفس التحدي
              </Text>
            </View>

            <SectionHeader
              number="2"
              title="دعوة أولياء الأمور"
              description="ابحثي باسم المستخدم أو رمز العائلة"
              icon="people-circle-outline"
            />

            <View style={styles.familySearchCard}>
              <View style={styles.searchInputContainer}>
                <View style={styles.searchIconBox}>
                  <Ionicons
                    name="search"
                    size={21}
                    color="#FF4868"
                  />
                </View>

                <TextInput
                  value={familySearch}
                  onChangeText={setFamilySearch}
                  placeholder="مثال: @family_khaled أو WASD-4281"
                  placeholderTextColor="#AAAAB5"
                  style={styles.searchInput}
                  textAlign="right"
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inviteExplanation}>
                <View style={styles.inviteExplanationIcon}>
                  <Ionicons
                    name="shield-checkmark-outline"
                    size={23}
                    color="#168B68"
                  />
                </View>

                <Text style={styles.inviteExplanationText}>
                  ولي الأمر المدعو سيختار أطفاله بنفسه عند قبول
                  الدعوة
                </Text>
              </View>
            </View>

            {familySearch.trim().length > 0 && (
              <View style={styles.searchResults}>
                <Text style={styles.resultsTitle}>
                  نتائج البحث
                </Text>

                {foundFamilies.length > 0 ? (
                  foundFamilies.map((family) => (
                    <FamilySearchResult
                      key={family.id}
                      family={family}
                      onInvite={() => inviteFamily(family)}
                    />
                  ))
                ) : (
                  <View style={styles.noResults}>
                    <View style={styles.noResultsIcon}>
                      <Ionicons
                        name="search-outline"
                        size={27}
                        color="#999BA9"
                      />
                    </View>

                    <Text style={styles.noResultsTitle}>
                      لم نجد هذه العائلة
                    </Text>

                    <Text style={styles.noResultsText}>
                      تأكدي من اسم المستخدم أو رمز الدعوة
                    </Text>
                  </View>
                )}
              </View>
            )}

            {invitedFamilies.length > 0 && (
              <View style={styles.invitedSection}>
                <View style={styles.invitedHeader}>
                  <View style={styles.invitedCount}>
                    <Text style={styles.invitedCountText}>
                      {invitedFamilies.length}
                    </Text>
                  </View>

                  <View style={styles.invitedHeaderText}>
                    <Text style={styles.invitedTitle}>
                      العائلات المدعوة
                    </Text>

                    <Text style={styles.invitedDescription}>
                      ستصلهم دعوة لاختيار أطفالهم
                    </Text>
                  </View>
                </View>

                {invitedFamilies.map((family) => (
                  <InvitedFamilyCard
                    key={family.id}
                    family={family}
                    onRemove={() =>
                      removeInvitedFamily(family.id)
                    }
                  />
                ))}
              </View>
            )}

            <SectionHeader
              number="3"
              title="نوع التحدي"
              description="اختاري شكل المنافسة المناسب"
              icon="sparkles-outline"
            />

            <View style={styles.typesContainer}>
              {CHALLENGE_TYPES.map((type) => {
                const selected = challengeType === type.id;

                return (
                  <Pressable
                    key={type.id}
                    onPress={() => setChallengeType(type.id)}
                    style={({ pressed }) => [
                      styles.typeCard,
                      selected && styles.selectedTypeCard,
                      pressed && styles.smallPressed,
                    ]}
                  >
                    <LinearGradient
                      colors={
                        selected
                          ? type.colors
                          : ["#FFF1F4", "#FFF7F8"]
                      }
                      style={styles.typeIcon}
                    >
                      <Ionicons
                        name={type.icon}
                        size={27}
                        color={selected ? "#FFFFFF" : "#FF4868"}
                      />
                    </LinearGradient>

                    <View style={styles.typeTextArea}>
                      <Text
                        style={[
                          styles.typeTitle,
                          selected && styles.selectedTypeTitle,
                        ]}
                      >
                        {type.title}
                      </Text>

                      <Text style={styles.typeDescription}>
                        {type.description}
                      </Text>
                    </View>

                    <View
                      style={[
                        styles.radioOuter,
                        selected && styles.selectedRadioOuter,
                      ]}
                    >
                      {selected && <View style={styles.radioInner} />}
                    </View>
                  </Pressable>
                );
              })}
            </View>

            <SectionHeader
              number="4"
              title="تفاصيل التحدي"
              description="أضيفي معلومات المنافسة والجائزة"
              icon="create-outline"
            />

            <InputField
              label="اسم التحدي"
              placeholder="مثال: تحدي أبطال الادخار"
              value={challengeTitle}
              onChangeText={setChallengeTitle}
              icon="trophy-outline"
            />

            <InputField
              label="وصف التحدي"
              placeholder="اكتبي وصفًا بسيطًا للمنافسة"
              value={description}
              onChangeText={setDescription}
              icon="document-text-outline"
              multiline
            />

            {challengeType === "saving" && (
              <>
                <InputField
                  label="الغرض المستهدف"
                  placeholder="مثال: دراجة أو لعبة تعليمية"
                  value={itemName}
                  onChangeText={setItemName}
                  icon="gift-outline"
                />

                <InputField
                  label="قيمة الهدف لكل طفل"
                  placeholder="مثال: 500"
                  value={targetAmount}
                  onChangeText={setTargetAmount}
                  icon="cash-outline"
                  keyboardType="numeric"
                  suffix="ريال"
                />
              </>
            )}

            {challengeType === "tasks" && (
              <View style={styles.tasksSection}>
                <Text style={styles.fieldLabel}>مهام التحدي</Text>

                <View style={styles.addTaskRow}>
                  <Pressable
                    onPress={addTask}
                    style={({ pressed }) => [
                      styles.addTaskButton,
                      pressed && styles.smallPressed,
                    ]}
                  >
                    <Ionicons
                      name="add"
                      size={25}
                      color="#FFFFFF"
                    />
                  </Pressable>

                  <View style={styles.taskInputContainer}>
                    <TextInput
                      value={newTask}
                      onChangeText={setNewTask}
                      onSubmitEditing={addTask}
                      placeholder="أضيفي مهمة جديدة"
                      placeholderTextColor="#AAAAB5"
                      style={styles.taskInput}
                      textAlign="right"
                    />
                  </View>
                </View>

                {tasks.map((task, index) => (
                  <View
                    key={`${task}-${index}`}
                    style={styles.taskItem}
                  >
                    <Pressable
                      onPress={() => removeTask(index)}
                      style={styles.deleteTaskButton}
                    >
                      <Ionicons
                        name="trash-outline"
                        size={19}
                        color="#FF4967"
                      />
                    </Pressable>

                    <Text style={styles.taskText}>{task}</Text>

                    <View style={styles.taskNumber}>
                      <Text style={styles.taskNumberText}>
                        {index + 1}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            )}

            {challengeType === "spending" && (
              <View style={styles.spendingInfo}>
                <View style={styles.spendingIcon}>
                  <Ionicons
                    name="bulb-outline"
                    size={25}
                    color="#168B68"
                  />
                </View>

                <View style={styles.spendingTextArea}>
                  <Text style={styles.spendingTitle}>
                    كيف يعمل التحدي؟
                  </Text>

                  <Text style={styles.spendingText}>
                    يتنافس الأطفال على إدارة مصروفهم وتقليل
                    المشتريات غير الضرورية خلال المدة المحددة.
                  </Text>
                </View>
              </View>
            )}

            <View style={styles.twoFieldsRow}>
              <View style={styles.halfField}>
                <InputField
                  label="الجائزة"
                  placeholder="100 نقطة"
                  value={prize}
                  onChangeText={setPrize}
                  icon="ribbon-outline"
                />
              </View>

              <View style={styles.halfField}>
                <InputField
                  label="المدة"
                  placeholder="7"
                  value={duration}
                  onChangeText={setDuration}
                  icon="calendar-outline"
                  keyboardType="numeric"
                  suffix="أيام"
                />
              </View>
            </View>

            <View style={styles.approvalCard}>
              <LinearGradient
                colors={["#FFF0F3", "#FFF8F9"]}
                style={styles.approvalGradient}
              >
                <View style={styles.approvalIcon}>
                  <Ionicons
                    name="mail-unread-outline"
                    size={29}
                    color="#FF4565"
                  />
                </View>

                <View style={styles.approvalTextArea}>
                  <Text style={styles.approvalTitle}>
                    يبدأ بعد موافقة أولياء الأمور
                  </Text>

                  <Text style={styles.approvalDescription}>
                    سيبقى التحدي بانتظار الموافقة، وكل ولي أمر
                    مدعو سيختار الأطفال الذين سيشاركون من عائلته.
                  </Text>
                </View>
              </LinearGradient>
            </View>

            <Pressable
              onPress={createChallenge}
              style={({ pressed }) => [
                styles.createButton,
                pressed && styles.pressedButton,
              ]}
            >
              <LinearGradient
                colors={["#FF2E63", "#FF7750"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.createGradient}
              >
                <Ionicons
                  name="paper-plane"
                  size={23}
                  color="#FFFFFF"
                />

                <Text style={styles.createButtonText}>
                  إنشاء التحدي وإرسال الدعوات
                </Text>
              </LinearGradient>
            </Pressable>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
}

function SectionHeader({
  number,
  title,
  description,
  icon,
}: {
  number: string;
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
}) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionNumber}>
        <Text style={styles.sectionNumberText}>{number}</Text>
      </View>

      <View style={styles.sectionTextArea}>
        <Text style={styles.sectionTitle}>{title}</Text>

        <Text style={styles.sectionDescription}>
          {description}
        </Text>
      </View>

      <View style={styles.sectionIcon}>
        <Ionicons name={icon} size={22} color="#FF4564" />
      </View>
    </View>
  );
}

function FamilySearchResult({
  family,
  onInvite,
}: {
  family: Family;
  onInvite: () => void;
}) {
  return (
    <View style={styles.familyResultCard}>
      <Pressable onPress={onInvite} style={styles.inviteButton}>
        <Ionicons
          name="person-add-outline"
          size={18}
          color="#FFFFFF"
        />

        <Text style={styles.inviteButtonText}>دعوة</Text>
      </Pressable>

      <View style={styles.familyResultText}>
        <Text style={styles.familyResultName}>
          {family.familyName}
        </Text>

        <Text style={styles.familyParentName}>
          {family.parentName} • {family.childrenCount} أطفال
        </Text>

        <Text style={styles.familyUsername}>
          {family.username}
        </Text>
      </View>

      <View style={styles.familyAvatar}>
        <Text style={styles.familyEmoji}>{family.emoji}</Text>
      </View>
    </View>
  );
}

function InvitedFamilyCard({
  family,
  onRemove,
}: {
  family: Family;
  onRemove: () => void;
}) {
  return (
    <View style={styles.invitedFamilyCard}>
      <Pressable
        onPress={onRemove}
        style={styles.removeFamilyButton}
      >
        <Ionicons name="close" size={19} color="#FF4967" />
      </Pressable>

      <View style={styles.invitedFamilyText}>
        <Text style={styles.invitedFamilyName}>
          {family.familyName}
        </Text>

        <Text style={styles.invitedFamilyStatus}>
          بانتظار إرسال الدعوة
        </Text>
      </View>

      <View style={styles.invitedFamilyAvatar}>
        <Text style={styles.invitedFamilyEmoji}>
          {family.emoji}
        </Text>

        <View style={styles.pendingDot} />
      </View>
    </View>
  );
}

function InputField({
  label,
  placeholder,
  value,
  onChangeText,
  icon,
  keyboardType = "default",
  suffix,
  multiline = false,
}: {
  label: string;
  placeholder: string;
  value: string;
  onChangeText: (text: string) => void;
  icon: keyof typeof Ionicons.glyphMap;
  keyboardType?: "default" | "numeric";
  suffix?: string;
  multiline?: boolean;
}) {
  return (
    <View style={styles.fieldContainer}>
      <Text style={styles.fieldLabel}>{label}</Text>

      <View
        style={[
          styles.inputContainer,
          multiline && styles.multilineInputContainer,
        ]}
      >
        <View style={styles.inputIcon}>
          <Ionicons name={icon} size={20} color="#FF526D" />
        </View>

        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#AAAAB5"
          keyboardType={keyboardType}
          multiline={multiline}
          textAlignVertical={multiline ? "top" : "center"}
          style={[
            styles.input,
            multiline && styles.multilineInput,
          ]}
          textAlign="right"
        />

        {suffix && (
          <Text style={styles.inputSuffix}>{suffix}</Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#F8F8FB",
  },

  loadingScreen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  loadingText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 16,
    color: "#777988",
  },

  header: {
    paddingBottom: 75,
    overflow: "hidden",
  },

  flameOne: {
    position: "absolute",
    left: -38,
    bottom: -48,
    transform: [{ rotate: "-10deg" }],
  },

  flameTwo: {
    position: "absolute",
    right: -15,
    top: 20,
    transform: [{ rotate: "15deg" }],
  },

  sparkOne: {
    position: "absolute",
    left: 42,
    top: 75,
  },

  headerTop: {
    paddingHorizontal: 19,
    paddingTop: 10,
    flexDirection: "row",
    alignItems: "flex-start",
  },

  headerSpacer: {
    width: 47,
  },

  headerTitleArea: {
    flex: 1,
    alignItems: "center",
  },

  headerTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 31,
    color: "#FFFFFF",
  },

  headerSubtitle: {
    marginTop: 4,
    paddingHorizontal: 4,
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    lineHeight: 21,
    color: "rgba(255,255,255,0.90)",
    textAlign: "center",
  },

  backButton: {
    width: 47,
    height: 47,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.16)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.23)",
  },

  headerSummary: {
    marginTop: 26,
    marginHorizontal: 28,
    minHeight: 78,
    paddingHorizontal: 17,
    borderRadius: 24,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(126,0,36,0.18)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.20)",
  },

  headerSummaryItem: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
  },

  headerSummaryIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  headerSummaryNumber: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 20,
    color: "#FFFFFF",
    textAlign: "right",
  },

  headerSummaryLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "rgba(255,255,255,0.86)",
    textAlign: "right",
  },

  headerSummaryDivider: {
    width: 1,
    height: 42,
    marginHorizontal: 8,
    backgroundColor: "rgba(255,255,255,0.25)",
  },

  contentSheet: {
    flex: 1,
    marginTop: -39,
    borderTopLeftRadius: 36,
    borderTopRightRadius: 36,
    backgroundColor: "#F8F8FB",
    overflow: "hidden",
  },

  keyboardView: {
    flex: 1,
  },

  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 25,
    paddingBottom: 90,
  },

  sectionHeader: {
    marginTop: 11,
    marginBottom: 15,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
  },

  sectionNumber: {
    width: 29,
    height: 29,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FF4564",
  },

  sectionNumberText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: "#FFFFFF",
  },

  sectionTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  sectionTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 20,
    color: "#252738",
    textAlign: "right",
  },

  sectionDescription: {
    marginTop: 2,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "#9294A2",
    textAlign: "right",
  },

  sectionIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFECEF",
  },

  childrenRow: {
    gap: 11,
    paddingBottom: 10,
  },

  childCard: {
    width: 111,
    minHeight: 145,
    paddingVertical: 14,
    borderRadius: 25,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1.5,
    borderColor: "#ECECF2",
  },

  selectedChildCard: {
    borderColor: "#FF4967",
    backgroundColor: "#FFF5F7",
    shadowColor: "#FF4967",
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.12,
    shadowRadius: 10,
    elevation: 4,
  },

  childSelectionCircle: {
    position: "absolute",
    top: 9,
    right: 9,
    width: 23,
    height: 23,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F0F0F4",
  },

  selectedChildSelectionCircle: {
    backgroundColor: "#FF4967",
  },

  childAvatar: {
    width: 67,
    height: 67,
    borderRadius: 34,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F5F5F8",
  },

  selectedChildAvatar: {
    backgroundColor: "#FFE6EC",
  },

  childEmoji: {
    fontSize: 40,
  },

  childName: {
    marginTop: 8,
    fontFamily: "Tajawal_700Bold",
    fontSize: 16,
    color: "#666877",
  },

  selectedChildName: {
    color: "#FF3E61",
  },

  childAge: {
    marginTop: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#9A9CA9",
  },

  selectionHint: {
    marginTop: 3,
    marginBottom: 9,
    minHeight: 48,
    paddingHorizontal: 13,
    borderRadius: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#F1EEFF",
  },

  selectionHintText: {
    flex: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    lineHeight: 18,
    color: "#665A91",
    textAlign: "right",
  },

  familySearchCard: {
    padding: 13,
    borderRadius: 23,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#ECECF2",
    shadowColor: "#30313F",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowOpacity: 0.05,
    shadowRadius: 13,
    elevation: 3,
  },

  searchInputContainer: {
    minHeight: 58,
    paddingHorizontal: 10,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F8F8FB",
    borderWidth: 1,
    borderColor: "#E9E9EF",
  },

  searchIconBox: {
    width: 39,
    height: 39,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFECEF",
  },

  searchInput: {
    flex: 1,
    paddingHorizontal: 11,
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    color: "#313342",
  },

  inviteExplanation: {
    marginTop: 10,
    minHeight: 55,
    paddingHorizontal: 10,
    borderRadius: 16,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 9,
    backgroundColor: "#EAFBF5",
  },

  inviteExplanationIcon: {
    width: 37,
    height: 37,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  inviteExplanationText: {
    flex: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    lineHeight: 18,
    color: "#39705F",
    textAlign: "right",
  },

  searchResults: {
    marginTop: 12,
  },

  resultsTitle: {
    marginBottom: 7,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: "#555766",
    textAlign: "right",
  },

  familyResultCard: {
    minHeight: 88,
    marginBottom: 9,
    padding: 11,
    borderRadius: 21,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EAEAEE",
  },

  inviteButton: {
    minHeight: 42,
    paddingHorizontal: 13,
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#FF4967",
  },

  inviteButtonText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: "#FFFFFF",
  },

  familyResultText: {
    flex: 1,
    alignItems: "flex-end",
  },

  familyResultName: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#343645",
  },

  familyParentName: {
    marginTop: 2,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#8F919F",
  },

  familyUsername: {
    marginTop: 2,
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: "#FF4967",
  },

  familyAvatar: {
    width: 57,
    height: 57,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  familyEmoji: {
    fontSize: 31,
  },

  noResults: {
    paddingVertical: 25,
    borderRadius: 21,
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#ECECF2",
  },

  noResultsIcon: {
    width: 58,
    height: 58,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F3F3F6",
  },

  noResultsTitle: {
    marginTop: 10,
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "#505260",
  },

  noResultsText: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "#9A9CA9",
  },

  invitedSection: {
    marginTop: 14,
    padding: 14,
    borderRadius: 23,
    backgroundColor: "#FFF0F3",
  },

  invitedHeader: {
    marginBottom: 9,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
  },

  invitedCount: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FF4967",
  },

  invitedCountText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#FFFFFF",
  },

  invitedHeaderText: {
    flex: 1,
    alignItems: "flex-end",
  },

  invitedTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#3C3E4D",
  },

  invitedDescription: {
    marginTop: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#898B99",
  },

  invitedFamilyCard: {
    minHeight: 70,
    marginTop: 7,
    paddingHorizontal: 10,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#FFFFFF",
  },

  removeFamilyButton: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  invitedFamilyText: {
    flex: 1,
    alignItems: "flex-end",
  },

  invitedFamilyName: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: "#444655",
  },

  invitedFamilyStatus: {
    marginTop: 2,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#DB8615",
  },

  invitedFamilyAvatar: {
    width: 48,
    height: 48,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF1EA",
  },

  invitedFamilyEmoji: {
    fontSize: 27,
  },

  pendingDot: {
    position: "absolute",
    right: -2,
    bottom: -2,
    width: 13,
    height: 13,
    borderRadius: 7,
    backgroundColor: "#F6A21A",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },

  typesContainer: {
    gap: 10,
  },

  typeCard: {
    minHeight: 88,
    padding: 13,
    borderRadius: 22,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 12,
    backgroundColor: "#FFFFFF",
    borderWidth: 1.5,
    borderColor: "#ECECF2",
  },

  selectedTypeCard: {
    borderColor: "#FF4967",
    backgroundColor: "#FFF8F9",
  },

  typeIcon: {
    width: 54,
    height: 54,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },

  typeTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  typeTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#303242",
  },

  selectedTypeTitle: {
    color: "#FF3D60",
  },

  typeDescription: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    lineHeight: 18,
    color: "#999BA8",
    textAlign: "right",
  },

  radioOuter: {
    width: 23,
    height: 23,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#DADBE2",
  },

  selectedRadioOuter: {
    borderColor: "#FF4967",
  },

  radioInner: {
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: "#FF4967",
  },

  fieldContainer: {
    marginBottom: 14,
  },

  fieldLabel: {
    marginBottom: 7,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: "#454757",
    textAlign: "right",
  },

  inputContainer: {
    minHeight: 58,
    paddingHorizontal: 11,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E8E8EF",
  },

  multilineInputContainer: {
    minHeight: 105,
    alignItems: "flex-start",
    paddingTop: 10,
  },

  inputIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  input: {
    flex: 1,
    paddingHorizontal: 10,
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    color: "#303242",
  },

  multilineInput: {
    minHeight: 82,
    paddingTop: 8,
  },

  inputSuffix: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: "#8D8F9E",
  },

  tasksSection: {
    marginBottom: 14,
  },

  addTaskRow: {
    flexDirection: "row",
    gap: 8,
  },

  addTaskButton: {
    width: 57,
    height: 57,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FF4967",
  },

  taskInputContainer: {
    flex: 1,
    height: 57,
    borderRadius: 18,
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E8E8EF",
  },

  taskInput: {
    paddingHorizontal: 15,
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    color: "#303242",
  },

  taskItem: {
    minHeight: 59,
    marginTop: 9,
    paddingHorizontal: 12,
    borderRadius: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#ECECF2",
  },

  deleteTaskButton: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  taskText: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: "#4D4F5F",
    textAlign: "right",
  },

  taskNumber: {
    width: 31,
    height: 31,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFECEF",
  },

  taskNumberText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: "#FF4564",
  },

  spendingInfo: {
    marginBottom: 15,
    padding: 15,
    borderRadius: 21,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 11,
    backgroundColor: "#EAFBF5",
  },

  spendingIcon: {
    width: 49,
    height: 49,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  spendingTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  spendingTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: "#326B59",
  },

  spendingText: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    lineHeight: 19,
    color: "#4B7769",
    textAlign: "right",
  },

  twoFieldsRow: {
    flexDirection: "row",
    gap: 10,
  },

  halfField: {
    flex: 1,
  },

  approvalCard: {
    marginTop: 5,
    borderRadius: 23,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#FFDCE3",
  },

  approvalGradient: {
    minHeight: 105,
    padding: 15,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 12,
  },

  approvalIcon: {
    width: 57,
    height: 57,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  approvalTextArea: {
    flex: 1,
    alignItems: "flex-end",
  },

  approvalTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#363847",
  },

  approvalDescription: {
    marginTop: 4,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    lineHeight: 19,
    color: "#7D7F8E",
    textAlign: "right",
  },

  createButton: {
    marginTop: 20,
    borderRadius: 21,
    overflow: "hidden",
    shadowColor: "#FF3D61",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.20,
    shadowRadius: 13,
    elevation: 6,
  },

  createGradient: {
    minHeight: 62,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
  },

  createButtonText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#FFFFFF",
  },

  pressedButton: {
    opacity: 0.86,
    transform: [{ scale: 0.98 }],
  },

  smallPressed: {
    opacity: 0.82,
    transform: [{ scale: 0.975 }],
  },
});