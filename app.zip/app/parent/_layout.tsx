import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from "react-native";

import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";


import type { ComponentProps } from "react";

type IoniconName = ComponentProps<typeof Ionicons>["name"];

const ACTIVE_COLOR = "#b3aad4";
const INACTIVE_COLOR = "#A9ADBA";

const tabConfig: Record<
  string,
  {
    label: string;
    activeIcon: IoniconName;
    inactiveIcon: IoniconName;
  }
> = {
  index: {
    label: "الرئيسية",
    activeIcon: "home",
    inactiveIcon: "home-outline",
  },

  children: {
    label: "أسرتي",
    activeIcon: "people",
    inactiveIcon: "people-outline",
  },

  tasks: {
    label: "المهام",
    activeIcon: "checkmark-done",
    inactiveIcon: "checkmark-done-outline",
  },

  challenges: {
    label: "التحديات",
    activeIcon: "trophy",
    inactiveIcon: "trophy-outline",
  },

  stories: {
    label: "القصص",
    activeIcon: "book",
    inactiveIcon: "book-outline",
  },

  financial: {
    label: "المالي",
    activeIcon: "wallet",
    inactiveIcon: "wallet-outline",
  },
};

function ParentTabBar({
  state,
  descriptors,
  navigation,
}: any) {
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.wrapper,
        {
          paddingBottom: Math.max(insets.bottom, 10),
        },
      ]}
    >
      <View style={styles.tabBar}>
        {state.routes.map((route: any, index: number) => {
          const tab = tabConfig[route.name];

          if (!tab) {
            return null;
          }

          const focused = state.index === index;

          const onPress = () => {
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });

            if (!focused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          const onLongPress = () => {
            navigation.emit({
              type: "tabLongPress",
              target: route.key,
            });
          };

          return (
            <TouchableOpacity
              key={route.key}
              onPress={onPress}
              onLongPress={onLongPress}
              activeOpacity={0.85}
              accessibilityRole="button"
              accessibilityState={
                focused ? { selected: true } : {}
              }
              accessibilityLabel={
                descriptors[route.key].options
                  .tabBarAccessibilityLabel
              }
              style={styles.tabItem}
            >
              {focused ? (
                <View style={styles.activeWrapper}>
                  <View style={styles.activeCircle}>
                    <Ionicons
                      name={tab.activeIcon}
                      size={27}
                      color="#FFFFFF"
                    />
                  </View>
                </View>
              ) : (
                <View style={styles.inactiveIconBox}>
                  <Ionicons
                    name={tab.inactiveIcon}
                    size={21}
                    color={INACTIVE_COLOR}
                  />
                </View>
              )}

              <Text
                numberOfLines={1}
                style={[
                  styles.label,
                  focused && styles.activeLabel,
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

export default function ParentLayout() {
  return (
    <Tabs
      tabBar={(props) => <ParentTabBar {...props} />}
      screenOptions={{
        headerShown: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "الرئيسية",
        }}
      />

      <Tabs.Screen
        name="children"
        options={{
          title: "أسرتي ",
        }}
      />

      <Tabs.Screen
        name="tasks"
        options={{
          title: "المهام",
        }}
      />

      <Tabs.Screen
        name="challenges"
        options={{
          title: "التحديات",
        }}
      />

      <Tabs.Screen
        name="stories"
        options={{
          title: "القصص",
        }}
      />

      <Tabs.Screen
        name="financial"
        options={{
          title: "المركز المالي",
        }}
      />

      <Tabs.Screen
        name="challenge-details"
        options={{
          href: null,
        }}
      />

      <Tabs.Screen
        name="create-challenge"
        options={{
          href: null,
        }}
      />
      <Tabs.Screen
  name="profile"
  options={{
    href: null,
  }}
/>
    </Tabs>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    left: 8,
    right: 8,
    bottom: 0,
    paddingTop: 38,
  },

  tabBar: {
    height: 80,
    backgroundColor: "#FFFFFF",
    borderRadius: 28,

    flexDirection: "row",
    alignItems: "flex-end",

    paddingHorizontal: 2,
    paddingBottom: 10,

    shadowColor: "#3E3568",
    shadowOffset: {
      width: 0,
      height: -5,
    },
    shadowOpacity: 0.14,
    shadowRadius: 15,

    elevation: 20,
    overflow: "visible",
  },

  tabItem: {
    flex: 1,
    height: 80,
    alignItems: "center",
    justifyContent: "flex-end",
  },

  inactiveIconBox: {
    width: 34,
    height: 34,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
  },

  activeWrapper: {
    position: "absolute",
    bottom: 31,

    width: 70,
    height: 70,
    borderRadius: 35,

    backgroundColor: "#F7F5FC",

    alignItems: "center",
    justifyContent: "center",

    shadowColor: ACTIVE_COLOR,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.23,
    shadowRadius: 11,

    elevation: 12,
  },

  activeCircle: {
    width: 57,
    height: 57,
    borderRadius: 29,

    backgroundColor: ACTIVE_COLOR,

    alignItems: "center",
    justifyContent: "center",
  },

  label: {
    color: INACTIVE_COLOR,
    fontSize: 8,
    fontWeight: "600",
    textAlign: "center",
  },

  activeLabel: {
    color: ACTIVE_COLOR,
    fontSize: 9,
    fontWeight: "900",
  },
});