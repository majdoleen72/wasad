import React, { useState } from "react";
import {
  Modal,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const COLORS = {
  background: "#F4FAF8",
  surface: "#FFFFFF",
  text: "#162D2A",
  muted: "#778B87",
  green: "#24B68D",
  greenDark: "#128066",
  greenSoft: "#DFF8EF",
  blue: "#377CF6",
  coral: "#FF806B",
  border: "#DFEBE8",
};

type Investment = {
  id: number;
  title: string;
  amount: number;
  currentValue: number;
  returnValue: number;
  progress: number;
  remaining: string;
  risk: string;
  status: string;
};

const INITIAL_INVESTMENTS: Investment[] = [
  {
    id: 1,
    title: "استثمار ريم",
    amount: 250,
    currentValue: 268,
    returnValue: 18,
    progress: 68,
    remaining: "21 يومًا",
    risk: "منخفض",
    status: "نشط",
  },
  {
    id: 2,
    title: "صندوق المستقبل",
    amount: 150,
    currentValue: 156,
    returnValue: 6,
    progress: 42,
    remaining: "48 يومًا",
    risk: "متوسط",
    status: "نشط",
  },
];

export default function InvestmentsScreen() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [amount, setAmount] = useState("");
  const [investments, setInvestments] =
    useState<Investment[]>(INITIAL_INVESTMENTS);

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  if (!fontsLoaded) {
    return <View style={styles.loading} />;
  }

  const createInvestment = () => {
    const parsedAmount = Number(amount);

    if (!parsedAmount || parsedAmount <= 0) {
      return;
    }

    const newInvestment: Investment = {
      id: Date.now(),
      title: "استثمار جديد",
      amount: parsedAmount,
      currentValue: parsedAmount,
      returnValue: 0,
      progress: 5,
      remaining: "90 يومًا",
      risk: "منخفض",
      status: "قيد البدء",
    };

    setInvestments((current) => [newInvestment, ...current]);
    setAmount("");
    setShowCreateModal(false);
  };

  const totalInvested = investments.reduce(
    (total, item) => total + item.amount,
    0
  );

  const totalValue = investments.reduce(
    (total, item) => total + item.currentValue,
    0
  );

  const totalReturn = investments.reduce(
    (total, item) => total + item.returnValue,
    0
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            activeOpacity={0.8}
            onPress={() => router.replace("/parent/financial")}
          >
            <Ionicons name="arrow-forward" size={22} color={COLORS.text} />
          </TouchableOpacity>

          <View style={styles.headerText}>
            <Text style={styles.pageTitle}>استثمارات الطفل</Text>
            <Text style={styles.pageSubtitle}>
              استثمري جزءًا من محفظته ليعود إليه مع العائد
            </Text>
          </View>
        </View>

        <LinearGradient
          colors={["#117C62", "#20A980", "#4DD5A7"]}
          start={{ x: 0, y: 1 }}
          end={{ x: 1, y: 0 }}
          style={styles.heroCard}
        >
          <InvestmentChartBackground />

          <View style={styles.heroTop}>
            <View style={styles.heroIcon}>
              <Ionicons
                name="trending-up-outline"
                size={25}
                color="#FFFFFF"
              />
            </View>

            <View style={styles.liveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>المحفظة تنمو</Text>
            </View>
          </View>

          <Text style={styles.heroLabel}>القيمة الحالية للاستثمارات</Text>

          <View style={styles.heroAmountRow}>
            <Text style={styles.heroAmount}>
              {totalValue.toLocaleString("ar-SA")}
            </Text>
            <Text style={styles.heroCurrency}>ر.س</Text>
          </View>

          <View style={styles.heroReturn}>
            <Ionicons name="arrow-up" size={15} color="#CEFFE9" />
            <Text style={styles.heroReturnText}>
              +{totalReturn} ر.س عائد حالي
            </Text>
          </View>

          <View style={styles.heroBottom}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>رأس المال</Text>
              <Text style={styles.heroStatValue}>{totalInvested} ر.س</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>الاستثمارات</Text>
              <Text style={styles.heroStatValue}>
                {investments.length} نشطة
              </Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>مستوى المخاطرة</Text>
              <Text style={styles.heroStatValue}>منخفض</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.protectionNotice}>
          <View style={styles.noticeIcon}>
            <Ionicons
              name="shield-checkmark"
              size={22}
              color={COLORS.greenDark}
            />
          </View>

          <View style={styles.noticeContent}>
            <Text style={styles.noticeTitle}>أموال الطفل محفوظة</Text>
            <Text style={styles.noticeText}>
              المبلغ يُسحب من محفظة الطفل للاستثمار، ويعود رأس المال والعائد إلى
              حسابه عند انتهاء الاستثمار.
            </Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>الاستثمارات الحالية</Text>
            <Text style={styles.sectionSubtitle}>
              تابعي الأداء والمدة والعائد
            </Text>
          </View>

          <TouchableOpacity
            activeOpacity={0.85}
            style={styles.createSmallButton}
            onPress={() => setShowCreateModal(true)}
          >
            <Ionicons name="add" size={19} color="#FFFFFF" />
            <Text style={styles.createSmallText}>استثمار جديد</Text>
          </TouchableOpacity>
        </View>

        {investments.map((investment) => (
          <View key={investment.id} style={styles.investmentCard}>
            <View style={styles.cardTop}>
              <View style={styles.cardTitleRow}>
                <View style={styles.cardIcon}>
                  <Ionicons
                    name="analytics-outline"
                    size={22}
                    color={COLORS.greenDark}
                  />
                </View>

                <View>
                  <Text style={styles.cardTitle}>{investment.title}</Text>
                  <Text style={styles.cardSubtitle}>
                    متبقي {investment.remaining}
                  </Text>
                </View>
              </View>

              <View style={styles.statusBadge}>
                <View style={styles.statusDot} />
                <Text style={styles.statusText}>{investment.status}</Text>
              </View>
            </View>

            <View style={styles.investmentNumbers}>
              <View style={styles.numberItem}>
                <Text style={styles.numberLabel}>رأس المال</Text>
                <Text style={styles.numberValue}>{investment.amount} ر.س</Text>
              </View>

              <View style={styles.numberItem}>
                <Text style={styles.numberLabel}>العائد الحالي</Text>
                <Text style={styles.returnValue}>
                  +{investment.returnValue} ر.س
                </Text>
              </View>

              <View style={styles.numberItem}>
                <Text style={styles.numberLabel}>القيمة الحالية</Text>
                <Text style={styles.numberValue}>
                  {investment.currentValue} ر.س
                </Text>
              </View>
            </View>

            <View style={styles.progressHeader}>
              <Text style={styles.progressLabel}>مدة الاستثمار</Text>
              <Text style={styles.progressPercent}>
                {investment.progress}%
              </Text>
            </View>

            <View style={styles.progressTrack}>
              <LinearGradient
                colors={["#24B68D", "#71DAB8"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[
                  styles.progressFill,
                  { width: `${investment.progress}%` },
                ]}
              />
            </View>

            <View style={styles.cardFooter}>
              <View style={styles.riskTag}>
                <Ionicons
                  name="shield-outline"
                  size={14}
                  color={COLORS.greenDark}
                />
                <Text style={styles.riskText}>
                  مخاطرة {investment.risk}
                </Text>
              </View>

              <TouchableOpacity activeOpacity={0.8} style={styles.detailsButton}>
                <Text style={styles.detailsText}>عرض التفاصيل</Text>
                <Ionicons
                  name="chevron-back"
                  size={17}
                  color={COLORS.greenDark}
                />
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <View style={styles.bottomSpace} />
      </ScrollView>

      <TouchableOpacity
        style={styles.floatingButton}
        activeOpacity={0.88}
        onPress={() => setShowCreateModal(true)}
      >
        <Ionicons name="add" size={25} color="#FFFFFF" />
        <Text style={styles.floatingButtonText}>إنشاء استثمار</Text>
      </TouchableOpacity>

      <Modal
        visible={showCreateModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />

            <View style={styles.modalHeader}>
              <TouchableOpacity
                onPress={() => setShowCreateModal(false)}
                style={styles.modalClose}
              >
                <Ionicons name="close" size={21} color={COLORS.text} />
              </TouchableOpacity>

              <View>
                <Text style={styles.modalTitle}>استثمار جديد</Text>
                <Text style={styles.modalSubtitle}>
                  اختاري مبلغًا من محفظة الطفل
                </Text>
              </View>
            </View>

            <Text style={styles.inputLabel}>المبلغ المراد استثماره</Text>

            <View style={styles.amountInputContainer}>
              <TextInput
                value={amount}
                onChangeText={setAmount}
                keyboardType="numeric"
                placeholder="مثال: 200"
                placeholderTextColor="#A0AEAB"
                style={styles.amountInput}
                textAlign="right"
              />
              <Text style={styles.inputCurrency}>ر.س</Text>
            </View>

            <View style={styles.availableBox}>
              <Ionicons
                name="wallet-outline"
                size={20}
                color={COLORS.greenDark}
              />
              <Text style={styles.availableText}>
                المتاح في محفظة ريم: 620 ر.س
              </Text>
            </View>

            <TouchableOpacity
              activeOpacity={0.88}
              style={styles.confirmButton}
              onPress={createInvestment}
            >
              <LinearGradient
                colors={["#128066", "#24B68D"]}
                style={styles.confirmGradient}
              >
                <Text style={styles.confirmText}>تأكيد الاستثمار</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function InvestmentChartBackground() {
  return (
    <View pointerEvents="none" style={styles.chartBackground}>
      <View style={[styles.chartLine, styles.lineOne]} />
      <View style={[styles.chartLine, styles.lineTwo]} />
      <View style={[styles.chartLine, styles.lineThree]} />
      <View style={[styles.chartLine, styles.lineFour]} />

      <View style={[styles.chartDot, styles.dotOne]} />
      <View style={[styles.chartDot, styles.dotTwo]} />
      <View style={[styles.chartDot, styles.dotThree]} />
      <View style={[styles.chartDot, styles.dotFour]} />

      <Ionicons
        name="arrow-up-circle"
        size={34}
        color="rgba(255,255,255,0.22)"
        style={styles.chartArrow}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loading: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  backButton: {
    width: 46,
    height: 46,
    borderRadius: 15,
    backgroundColor: COLORS.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerText: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 13,
  },
  pageTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 27,
    color: COLORS.text,
  },
  pageSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 3,
  },
  heroCard: {
    minHeight: 310,
    borderRadius: 29,
    padding: 21,
    overflow: "hidden",
    marginBottom: 16,
  },
  chartBackground: {
    ...StyleSheet.absoluteFill,
    opacity: 1,
  },
  chartLine: {
    position: "absolute",
    height: 4,
    borderRadius: 5,
    backgroundColor: "rgba(255,255,255,0.18)",
  },
  lineOne: {
    width: 88,
    left: -8,
    bottom: 61,
    transform: [{ rotate: "-16deg" }],
  },
  lineTwo: {
    width: 91,
    left: 67,
    bottom: 83,
    transform: [{ rotate: "25deg" }],
  },
  lineThree: {
    width: 92,
    left: 143,
    bottom: 113,
    transform: [{ rotate: "-36deg" }],
  },
  lineFour: {
    width: 115,
    right: -8,
    bottom: 155,
    transform: [{ rotate: "31deg" }],
  },
  chartDot: {
    position: "absolute",
    width: 13,
    height: 13,
    borderRadius: 7,
    backgroundColor: "rgba(255,255,255,0.35)",
    borderWidth: 3,
    borderColor: "rgba(255,255,255,0.15)",
  },
  dotOne: {
    left: 55,
    bottom: 71,
  },
  dotTwo: {
    left: 137,
    bottom: 105,
  },
  dotThree: {
    left: 216,
    bottom: 136,
  },
  dotFour: {
    right: 23,
    bottom: 187,
  },
  chartArrow: {
    position: "absolute",
    right: 18,
    bottom: 174,
  },
  heroTop: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  heroIcon: {
    width: 49,
    height: 49,
    borderRadius: 17,
    backgroundColor: "rgba(255,255,255,0.17)",
    alignItems: "center",
    justifyContent: "center",
  },
  liveBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.15)",
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 12,
  },
  liveDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: "#C8FFE5",
  },
  liveText: {
    fontFamily: "Tajawal_700Bold",
    color: "#FFFFFF",
    fontSize: 11,
  },
  heroLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "rgba(255,255,255,0.75)",
    textAlign: "right",
    marginTop: 24,
  },
  heroAmountRow: {
    flexDirection: "row-reverse",
    alignItems: "flex-end",
    gap: 7,
  },
  heroAmount: {
    fontFamily: "Tajawal_900Black",
    fontSize: 40,
    color: "#FFFFFF",
  },
  heroCurrency: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "rgba(255,255,255,0.82)",
    marginBottom: 8,
  },
  heroReturn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 4,
    alignSelf: "flex-end",
  },
  heroReturnText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: "#CEFFE9",
  },
  heroBottom: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.13)",
    borderRadius: 18,
    paddingVertical: 13,
    marginTop: 34,
  },
  heroStat: {
    flex: 1,
    alignItems: "center",
  },
  heroStatLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10,
    color: "rgba(255,255,255,0.68)",
  },
  heroStatValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
    color: "#FFFFFF",
    marginTop: 2,
  },
  heroDivider: {
    width: 1,
    height: 37,
    backgroundColor: "rgba(255,255,255,0.18)",
  },
  protectionNotice: {
    flexDirection: "row-reverse",
    alignItems: "center",
    padding: 14,
    backgroundColor: COLORS.surface,
    borderRadius: 19,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 24,
  },
  noticeIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    backgroundColor: COLORS.greenSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  noticeContent: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 11,
  },
  noticeTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.text,
  },
  noticeText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    lineHeight: 17,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  sectionHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 13,
  },
  sectionTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 19,
    color: COLORS.text,
    textAlign: "right",
  },
  sectionSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    marginTop: 2,
    textAlign: "right",
  },
  createSmallButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.green,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 13,
  },
  createSmallText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: "#FFFFFF",
  },
  investmentCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 23,
    padding: 16,
    marginBottom: 13,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  cardTop: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardTitleRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  cardIcon: {
    width: 47,
    height: 47,
    borderRadius: 16,
    backgroundColor: COLORS.greenSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  cardTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: COLORS.text,
    textAlign: "right",
  },
  cardSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.greenSoft,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: COLORS.green,
  },
  statusText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10,
    color: COLORS.greenDark,
  },
  investmentNumbers: {
    flexDirection: "row-reverse",
    gap: 7,
    marginTop: 16,
  },
  numberItem: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 11,
    backgroundColor: "#F6FAF9",
    borderRadius: 13,
  },
  numberLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 9.5,
    color: COLORS.muted,
  },
  numberValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
    color: COLORS.text,
    marginTop: 3,
  },
  returnValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
    color: COLORS.greenDark,
    marginTop: 3,
  },
  progressHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginTop: 15,
  },
  progressLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
  },
  progressPercent: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 11,
    color: COLORS.greenDark,
  },
  progressTrack: {
    height: 8,
    backgroundColor: "#E1EEEA",
    borderRadius: 5,
    overflow: "hidden",
    marginTop: 7,
  },
  progressFill: {
    height: "100%",
    borderRadius: 5,
  },
  cardFooter: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 13,
  },
  riskTag: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
  },
  riskText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.greenDark,
  },
  detailsButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 2,
  },
  detailsText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: COLORS.greenDark,
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    alignSelf: "center",
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 7,
    backgroundColor: COLORS.greenDark,
    paddingHorizontal: 22,
    height: 54,
    borderRadius: 18,
    elevation: 7,
  },
  floatingButtonText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: "#FFFFFF",
  },
  bottomSpace: {
    height: 110,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(10,31,27,0.42)",
  },
  modalCard: {
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingTop: 11,
    paddingBottom: 30,
  },
  modalHandle: {
    width: 52,
    height: 5,
    borderRadius: 3,
    backgroundColor: "#DCE5E2",
    alignSelf: "center",
    marginBottom: 17,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 24,
  },
  modalClose: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "#F2F7F5",
    alignItems: "center",
    justifyContent: "center",
  },
  modalTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 22,
    color: COLORS.text,
    textAlign: "right",
  },
  modalSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  inputLabel: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: COLORS.text,
    textAlign: "right",
    marginBottom: 8,
  },
  amountInputContainer: {
    height: 56,
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: "#F5F9F8",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 14,
  },
  amountInput: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: COLORS.text,
  },
  inputCurrency: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: COLORS.greenDark,
  },
  availableBox: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    backgroundColor: COLORS.greenSoft,
    borderRadius: 14,
    padding: 12,
    marginTop: 12,
  },
  availableText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.greenDark,
  },
  confirmButton: {
    borderRadius: 17,
    overflow: "hidden",
    marginTop: 23,
  },
  confirmGradient: {
    height: 55,
    alignItems: "center",
    justifyContent: "center",
  },
  confirmText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#FFFFFF",
  },
});