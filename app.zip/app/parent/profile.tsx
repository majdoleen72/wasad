import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Image,
  ScrollView,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { useRouter, type Href } from "expo-router";

const LOGIN_ROUTE = "/" as Href;

export default function ParentProfileScreen() {
  const router = useRouter();

  const handleLogout = () => {
    router.replace(LOGIN_ROUTE);
  };

  return (
    <View style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F8F7FC"
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {/* الهيدر */}

        <View style={styles.header}>
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Ionicons
              name="chevron-forward"
              size={22}
              color="#303354"
            />
          </TouchableOpacity>

          <Text style={styles.headerTitle}>
            بيانات ولي الأمر
          </Text>

          <View style={styles.headerSpacer} />
        </View>

        {/* بطاقة الحساب */}

        <View style={styles.profileCard}>
          <View style={styles.profileImageWrapper}>
            <Image
              source={{
                uri: "https://i.pravatar.cc/300?img=47",
              }}
              style={styles.profileImage}
            />

            <TouchableOpacity
              activeOpacity={0.8}
              style={styles.cameraButton}
            >
              <Ionicons
                name="camera-outline"
                size={17}
                color="#FFFFFF"
              />
            </TouchableOpacity>
          </View>

          <Text style={styles.profileName}>
            مجدولين فهد
          </Text>

          <Text style={styles.profileRole}>
            ولي أمر
          </Text>

          <TouchableOpacity
            activeOpacity={0.85}
            style={styles.editButton}
          >
            <Ionicons
              name="create-outline"
              size={17}
              color="#7357DF"
            />

            <Text style={styles.editButtonText}>
              تعديل البيانات
            </Text>
          </TouchableOpacity>
        </View>

        {/* البيانات الشخصية */}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            المعلومات الشخصية
          </Text>
        </View>

        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <View style={styles.infoText}>
              <Text style={styles.infoLabel}>
                الاسم الكامل
              </Text>

              <Text style={styles.infoValue}>
                مجدولين فهد
              </Text>
            </View>

            <View
              style={[
                styles.infoIcon,
                styles.purpleIcon,
              ]}
            >
              <Ionicons
                name="person-outline"
                size={21}
                color="#7357DF"
              />
            </View>
          </View>

          <View style={styles.divider} />

          <View style={styles.infoRow}>
            <View style={styles.infoText}>
              <Text style={styles.infoLabel}>
                البريد الإلكتروني
              </Text>

              <Text style={styles.infoValue}>
                majdo@example.com
              </Text>
            </View>

            <View
              style={[
                styles.infoIcon,
                styles.blueIcon,
              ]}
            >
              <Ionicons
                name="mail-outline"
                size={21}
                color="#4389CE"
              />
            </View>
          </View>

          <View style={styles.divider} />

          <View style={styles.infoRow}>
            <View style={styles.infoText}>
              <Text style={styles.infoLabel}>
                رقم الجوال
              </Text>

              <Text style={styles.infoValue}>
                05XXXXXXXX
              </Text>
            </View>

            <View
              style={[
                styles.infoIcon,
                styles.greenIcon,
              ]}
            >
              <Ionicons
                name="call-outline"
                size={21}
                color="#42A47D"
              />
            </View>
          </View>
        </View>

        {/* الإعدادات */}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            الإعدادات
          </Text>
        </View>

        <View style={styles.settingsCard}>
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.settingRow}
          >
            <Ionicons
              name="chevron-back"
              size={19}
              color="#A1A2B0"
            />

            <View style={styles.settingText}>
              <Text style={styles.settingTitle}>
                تغيير كلمة المرور
              </Text>

              <Text style={styles.settingSubtitle}>
                تحديث كلمة المرور الخاصة بحسابك
              </Text>
            </View>

            <View
              style={[
                styles.settingIcon,
                styles.orangeIcon,
              ]}
            >
              <Ionicons
                name="lock-closed-outline"
                size={21}
                color="#E6974D"
              />
            </View>
          </TouchableOpacity>

          <View style={styles.divider} />

          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.settingRow}
          >
            <Ionicons
              name="chevron-back"
              size={19}
              color="#A1A2B0"
            />

            <View style={styles.settingText}>
              <Text style={styles.settingTitle}>
                الإشعارات
              </Text>

              <Text style={styles.settingSubtitle}>
                إدارة تنبيهات المهام والتحديات
              </Text>
            </View>

            <View
              style={[
                styles.settingIcon,
                styles.pinkIcon,
              ]}
            >
              <Ionicons
                name="notifications-outline"
                size={21}
                color="#D76C9D"
              />
            </View>
          </TouchableOpacity>

          <View style={styles.divider} />

          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.settingRow}
          >
            <Ionicons
              name="chevron-back"
              size={19}
              color="#A1A2B0"
            />

            <View style={styles.settingText}>
              <Text style={styles.settingTitle}>
                الخصوصية والأمان
              </Text>

              <Text style={styles.settingSubtitle}>
                التحكم في بيانات الحساب والأطفال
              </Text>
            </View>

            <View
              style={[
                styles.settingIcon,
                styles.greenIcon,
              ]}
            >
              <Ionicons
                name="shield-checkmark-outline"
                size={21}
                color="#42A47D"
              />
            </View>
          </TouchableOpacity>
        </View>

        {/* تسجيل الخروج */}

        <TouchableOpacity
          activeOpacity={0.85}
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Ionicons
            name="log-out-outline"
            size={22}
            color="#D95C5C"
          />

          <Text style={styles.logoutText}>
            تسجيل الخروج
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const CARD_SHADOW = {
  shadowColor: "#514773",
  shadowOffset: {
    width: 0,
    height: 7,
  },
  shadowOpacity: 0.1,
  shadowRadius: 16,
  elevation: 6,
};

const SOFT_SHADOW = {
  shadowColor: "#514773",
  shadowOffset: {
    width: 0,
    height: 4,
  },
  shadowOpacity: 0.07,
  shadowRadius: 11,
  elevation: 3,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F7FC",
  },

  content: {
    paddingHorizontal: 18,
    paddingTop: 55,
    paddingBottom: 70,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 25,
  },

  backButton: {
    width: 43,
    height: 43,
    borderRadius: 15,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    ...SOFT_SHADOW,
  },

  headerTitle: {
    color: "#292D54",
    fontSize: 18,
    fontWeight: "900",
  },

  headerSpacer: {
    width: 43,
  },

  profileCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 30,
    alignItems: "center",
    paddingVertical: 28,
    paddingHorizontal: 20,
    marginBottom: 28,
    ...CARD_SHADOW,
  },

  profileImageWrapper: {
    position: "relative",
    marginBottom: 15,
  },

  profileImage: {
    width: 96,
    height: 96,
    borderRadius: 32,
  },

  cameraButton: {
    position: "absolute",
    left: -5,
    bottom: -5,
    width: 34,
    height: 34,
    borderRadius: 13,
    backgroundColor: "#7357DF",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "#FFFFFF",
  },

  profileName: {
    color: "#2F3254",
    fontSize: 21,
    fontWeight: "900",
  },

  profileRole: {
    color: "#9A9BAC",
    fontSize: 11,
    marginTop: 5,
  },

  editButton: {
    marginTop: 18,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    backgroundColor: "#F1ECFF",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 16,
  },

  editButtonText: {
    color: "#7357DF",
    fontSize: 11,
    fontWeight: "800",
  },

  sectionHeader: {
    alignItems: "flex-end",
    marginBottom: 12,
  },

  sectionTitle: {
    color: "#2F3254",
    fontSize: 16,
    fontWeight: "900",
  },

  infoCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 27,
    paddingHorizontal: 18,
    marginBottom: 28,
    ...CARD_SHADOW,
  },

  infoRow: {
    minHeight: 82,
    flexDirection: "row",
    alignItems: "center",
  },

  infoText: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 13,
  },

  infoLabel: {
    color: "#9A9BAC",
    fontSize: 9,
  },

  infoValue: {
    color: "#3E4160",
    fontSize: 12,
    fontWeight: "800",
    marginTop: 5,
  },

  infoIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },

  purpleIcon: {
    backgroundColor: "#F1ECFF",
  },

  blueIcon: {
    backgroundColor: "#EAF4FF",
  },

  greenIcon: {
    backgroundColor: "#E8F8F1",
  },

  orangeIcon: {
    backgroundColor: "#FFF0E2",
  },

  pinkIcon: {
    backgroundColor: "#FFEAF3",
  },

  divider: {
    height: 1,
    backgroundColor: "#F0EEF5",
  },

  settingsCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 27,
    paddingHorizontal: 18,
    marginBottom: 25,
    ...CARD_SHADOW,
  },

  settingRow: {
    minHeight: 85,
    flexDirection: "row",
    alignItems: "center",
  },

  settingText: {
    flex: 1,
    alignItems: "flex-end",
    marginHorizontal: 13,
  },

  settingTitle: {
    color: "#41445F",
    fontSize: 12,
    fontWeight: "900",
  },

  settingSubtitle: {
    color: "#9A9BAC",
    fontSize: 9,
    textAlign: "right",
    marginTop: 5,
  },

  settingIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },

  logoutButton: {
    height: 60,
    borderRadius: 21,
    backgroundColor: "#FFF0F0",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
    borderWidth: 1,
    borderColor: "#FFDADA",
    ...SOFT_SHADOW,
    shadowColor: "#D95C5C",
  },

  logoutText: {
    color: "#D95C5C",
    fontSize: 13,
    fontWeight: "900",
  },
});