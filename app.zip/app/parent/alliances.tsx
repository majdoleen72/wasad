import React, { useState } from "react";
import {
  Modal,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const COLORS = {
  background: "#F8F6FF",
  surface: "#FFFFFF",
  text: "#29243D",
  muted: "#837D98",
  purple: "#8068E8",
  purpleDark: "#644CCB",
  purpleSoft: "#EDE9FF",
  blue: "#5D9CF5",
  coral: "#F48A78",
  border: "#E8E3F4",
};

type Alliance = {
  id: number;
  title: string;
  description: string;
  saved: number;
  target: number;
  members: string[];
  approval: string;
};

const INITIAL_ALLIANCES: Alliance[] = [
  {
    id: 1,
    title: "رحلة العائلة",
    description: "هدف مشترك بين ريم وسلمان وليان",
    saved: 540,
    target: 1000,
    members: ["ر", "س", "ل"],
    approval: "موافق عليه",
  },
  {
    id: 2,
    title: "هدية للجدّة",
    description: "يجمع الأطفال قيمة الهدية معًا",
    saved: 180,
    target: 300,
    members: ["ر", "س"],
    approval: "بانتظار موافقة",
  },
];

export default function AlliancesScreen() {
  const [alliances, setAlliances] =
    useState<Alliance[]>(INITIAL_ALLIANCES);

  const [showModal, setShowModal] = useState(false);
  const [allianceName, setAllianceName] = useState("");
  const [target, setTarget] = useState("");

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  if (!fontsLoaded) {
    return <View style={styles.loading} />;
  }

  const createAlliance = () => {
    const targetAmount = Number(target);

    if (!allianceName.trim() || !targetAmount) {
      return;
    }

    setAlliances((current) => [
      {
        id: Date.now(),
        title: allianceName.trim(),
        description: "تحالف جديد بين الأطفال",
        saved: 0,
        target: targetAmount,
        members: ["ر", "س"],
        approval: "بانتظار موافقة",
      },
      ...current,
    ]);

    setAllianceName("");
    setTarget("");
    setShowModal(false);
  };

  const totalSaved = alliances.reduce(
    (sum, alliance) => sum + alliance.saved,
    0
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.replace("/parent/financial")}>
            <Ionicons name="arrow-forward" size={22} color={COLORS.text} />
          </TouchableOpacity>

          <View style={styles.headerText}>
            <Text style={styles.pageTitle}>التحالفات</Text>
            <Text style={styles.pageSubtitle}>
              أهداف مشتركة يتعاون الأطفال لتحقيقها
            </Text>
          </View>
        </View>

        <LinearGradient
          colors={["#5945BD", "#7962DF", "#A18FF4"]}
          start={{ x: 0, y: 1 }}
          end={{ x: 1, y: 0 }}
          style={styles.heroCard}
        >
          <AllianceNetworkBackground />

          <View style={styles.heroTop}>
            <View style={styles.heroIcon}>
              <Ionicons name="people" size={26} color="#FFFFFF" />
            </View>

            <View style={styles.teamBadge}>
              <Ionicons name="sparkles" size={14} color="#FFFFFF" />
              <Text style={styles.teamBadgeText}>معًا نصل أسرع</Text>
            </View>
          </View>

          <Text style={styles.heroLabel}>إجمالي مدخرات التحالفات</Text>

          <View style={styles.heroAmountRow}>
            <Text style={styles.heroAmount}>{totalSaved}</Text>
            <Text style={styles.heroCurrency}>ر.س</Text>
          </View>

          <View style={styles.heroStats}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{alliances.length}</Text>
              <Text style={styles.heroStatLabel}>تحالفات نشطة</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>3</Text>
              <Text style={styles.heroStatLabel}>أطفال مشاركون</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>1</Text>
              <Text style={styles.heroStatLabel}>بانتظار الموافقة</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.approvalNotice}>
          <View style={styles.noticeIcon}>
            <Ionicons
              name="checkmark-done-outline"
              size={22}
              color={COLORS.purpleDark}
            />
          </View>

          <View style={styles.noticeContent}>
            <Text style={styles.noticeTitle}>موافقة أولياء الأمور</Text>
            <Text style={styles.noticeText}>
              لا تبدأ مساهمة الطفل إلا بعد موافقة ولي أمره على قيمة المشاركة
              والهدف المشترك.
            </Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>التحالفات الحالية</Text>
            <Text style={styles.sectionSubtitle}>
              تابعي المساهمات والموافقات
            </Text>
          </View>

          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowModal(true)}
          >
            <Ionicons name="add" size={19} color="#FFFFFF" />
            <Text style={styles.addButtonText}>تحالف جديد</Text>
          </TouchableOpacity>
        </View>

        {alliances.map((alliance) => {
          const percentage = Math.min(
            Math.round((alliance.saved / alliance.target) * 100),
            100
          );

          const pending = alliance.approval.includes("بانتظار");

          return (
            <View style={styles.allianceCard} key={alliance.id}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleContainer}>
                  <View style={styles.allianceTextContainer}>
                    <Text style={styles.allianceTitle}>
                      {alliance.title}
                    </Text>

                    <Text
                      style={styles.allianceDescription}
                      numberOfLines={2}
                    >
                      {alliance.description}
                    </Text>
                  </View>

                  <View style={styles.membersStack}>
                    {alliance.members.map((member, index) => (
                      <View
                        key={`${alliance.id}-${member}-${index}`}
                        style={[
                          styles.memberAvatar,
                          index > 0 && styles.memberOverlap,
                          {
                            backgroundColor:
                              index === 0
                                ? "#FFB3A7"
                                : index === 1
                                ? "#91CCFA"
                                : "#AEE4C9",
                            zIndex: alliance.members.length - index,
                          },
                        ]}
                      >
                        <Text style={styles.memberText}>{member}</Text>
                      </View>
                    ))}
                  </View>
                </View>

                <View
                  style={[
                    styles.approvalBadge,
                    pending && styles.pendingBadge,
                  ]}
                >
                  <Ionicons
                    name={pending ? "time-outline" : "checkmark-circle"}
                    size={13}
                    color={pending ? "#C67B24" : COLORS.purpleDark}
                  />

                  <Text
                    style={[
                      styles.approvalText,
                      pending && styles.pendingText,
                    ]}
                  >
                    {alliance.approval}
                  </Text>
                </View>
              </View>

              <View style={styles.amountRow}>
                <View>
                  <Text style={styles.amountLabel}>تم جمع</Text>
                  <Text style={styles.savedAmount}>{alliance.saved} ر.س</Text>
                </View>

                <View style={styles.targetBlock}>
                  <Text style={styles.amountLabel}>الهدف</Text>
                  <Text style={styles.targetAmount}>{alliance.target} ر.س</Text>
                </View>
              </View>

              <View style={styles.progressHeader}>
                <Text style={styles.progressText}>تقدم التحالف</Text>
                <Text style={styles.progressPercentage}>{percentage}%</Text>
              </View>

              <View style={styles.progressTrack}>
                <LinearGradient
                  colors={["#644CCB", "#A18FF4"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[styles.progressFill, { width: `${percentage}%` }]}
                />
              </View>

              <View style={styles.contributions}>
                <ContributionItem
                  name="ريم"
                  amount="220 ر.س"
                  color="#FFB3A7"
                />

                <ContributionItem
                  name="سلمان"
                  amount="180 ر.س"
                  color="#91CCFA"
                />

                {alliance.members.length > 2 && (
                  <ContributionItem
                    name="ليان"
                    amount="140 ر.س"
                    color="#AEE4C9"
                  />
                )}
              </View>

              <TouchableOpacity style={styles.viewButton}>
                <Text style={styles.viewButtonText}>عرض تفاصيل التحالف</Text>
                <Ionicons
                  name="chevron-back"
                  size={18}
                  color={COLORS.purpleDark}
                />
              </TouchableOpacity>
            </View>
          );
        })}

        <View style={styles.bottomSpace} />
      </ScrollView>

      <Modal
        visible={showModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />

            <View style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.modalClose}
                onPress={() => setShowModal(false)}
              >
                <Ionicons name="close" size={21} color={COLORS.text} />
              </TouchableOpacity>

              <View>
                <Text style={styles.modalTitle}>إنشاء تحالف</Text>
                <Text style={styles.modalSubtitle}>
                  أنشئي هدفًا مشتركًا بين الأطفال
                </Text>
              </View>
            </View>

            <Text style={styles.inputLabel}>اسم التحالف</Text>

            <TextInput
              value={allianceName}
              onChangeText={setAllianceName}
              placeholder="مثال: رحلة العائلة"
              placeholderTextColor="#A39DAF"
              style={styles.input}
              textAlign="right"
            />

            <Text style={styles.inputLabel}>المبلغ المستهدف</Text>

            <View style={styles.amountInputContainer}>
              <TextInput
                value={target}
                onChangeText={setTarget}
                placeholder="1000"
                placeholderTextColor="#A39DAF"
                keyboardType="numeric"
                style={styles.amountInput}
                textAlign="right"
              />

              <Text style={styles.currency}>ر.س</Text>
            </View>

            <Text style={styles.inputLabel}>الأطفال المشاركون</Text>

            <View style={styles.childrenPicker}>
              <View style={styles.selectedChild}>
                <View
                  style={[
                    styles.pickerAvatar,
                    { backgroundColor: "#FFB3A7" },
                  ]}
                >
                  <Text style={styles.pickerAvatarText}>ر</Text>
                </View>
                <Text style={styles.selectedChildText}>ريم</Text>
                <Ionicons
                  name="checkmark-circle"
                  size={18}
                  color={COLORS.purpleDark}
                />
              </View>

              <View style={styles.selectedChild}>
                <View
                  style={[
                    styles.pickerAvatar,
                    { backgroundColor: "#91CCFA" },
                  ]}
                >
                  <Text style={styles.pickerAvatarText}>س</Text>
                </View>
                <Text style={styles.selectedChildText}>سلمان</Text>
                <Ionicons
                  name="checkmark-circle"
                  size={18}
                  color={COLORS.purpleDark}
                />
              </View>
            </View>

            <TouchableOpacity
              style={styles.confirmButton}
              onPress={createAlliance}
            >
              <LinearGradient
                colors={["#5945BD", "#8068E8"]}
                style={styles.confirmGradient}
              >
                <Text style={styles.confirmText}>
                  إرسال طلبات الموافقة
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function ContributionItem({
  name,
  amount,
  color,
}: {
  name: string;
  amount: string;
  color: string;
}) {
  return (
    <View style={styles.contributionItem}>
      <View style={[styles.contributionDot, { backgroundColor: color }]} />

      <Text style={styles.contributionName}>{name}</Text>
      <Text style={styles.contributionAmount}>{amount}</Text>
    </View>
  );
}

function AllianceNetworkBackground() {
  return (
    <View pointerEvents="none" style={styles.networkBackground}>
      <View style={[styles.networkLine, styles.networkLineOne]} />
      <View style={[styles.networkLine, styles.networkLineTwo]} />
      <View style={[styles.networkLine, styles.networkLineThree]} />

      <View style={[styles.networkNode, styles.nodeOne]}>
        <Ionicons name="person" size={17} color="rgba(255,255,255,0.4)" />
      </View>

      <View style={[styles.networkNode, styles.nodeTwo]}>
        <Ionicons name="person" size={17} color="rgba(255,255,255,0.4)" />
      </View>

      <View style={[styles.networkNode, styles.nodeThree]}>
        <Ionicons name="person" size={17} color="rgba(255,255,255,0.4)" />
      </View>

      <View style={[styles.networkNode, styles.nodeCenter]}>
        <Ionicons name="heart" size={20} color="rgba(255,255,255,0.46)" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loading: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  backButton: {
    width: 46,
    height: 46,
    borderRadius: 15,
    backgroundColor: COLORS.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerText: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 13,
  },
  pageTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 27,
    color: COLORS.text,
  },
  pageSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: COLORS.muted,
    marginTop: 3,
  },
  heroCard: {
    minHeight: 295,
    borderRadius: 29,
    padding: 21,
    overflow: "hidden",
    marginBottom: 15,
  },
  networkBackground: {
    ...StyleSheet.absoluteFill,
  },
  networkLine: {
    position: "absolute",
    height: 4,
    borderRadius: 3,
    backgroundColor: "rgba(255,255,255,0.14)",
  },
  networkLineOne: {
    width: 117,
    right: 40,
    bottom: 80,
    transform: [{ rotate: "25deg" }],
  },
  networkLineTwo: {
    width: 127,
    left: 34,
    bottom: 92,
    transform: [{ rotate: "-30deg" }],
  },
  networkLineThree: {
    width: 112,
    left: 105,
    bottom: 150,
    transform: [{ rotate: "3deg" }],
  },
  networkNode: {
    position: "absolute",
    width: 44,
    height: 44,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.11)",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.13)",
    alignItems: "center",
    justifyContent: "center",
  },
  nodeOne: {
    left: 25,
    bottom: 52,
  },
  nodeTwo: {
    right: 24,
    bottom: 58,
  },
  nodeThree: {
    right: 72,
    bottom: 176,
  },
  nodeCenter: {
    left: 145,
    bottom: 105,
    width: 51,
    height: 51,
    borderRadius: 18,
  },
  heroTop: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },
  heroIcon: {
    width: 49,
    height: 49,
    borderRadius: 17,
    backgroundColor: "rgba(255,255,255,0.17)",
    alignItems: "center",
    justifyContent: "center",
  },
  teamBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: "rgba(255,255,255,0.15)",
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 12,
  },
  teamBadgeText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10.5,
    color: "#FFFFFF",
  },
  heroLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "rgba(255,255,255,0.75)",
    textAlign: "right",
    marginTop: 24,
  },
  heroAmountRow: {
    flexDirection: "row-reverse",
    alignItems: "flex-end",
    gap: 7,
  },
  heroAmount: {
    fontFamily: "Tajawal_900Black",
    fontSize: 39,
    color: "#FFFFFF",
  },
  heroCurrency: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "rgba(255,255,255,0.83)",
    marginBottom: 8,
  },
  heroStats: {
    flexDirection: "row-reverse",
    backgroundColor: "rgba(255,255,255,0.13)",
    borderRadius: 18,
    paddingVertical: 13,
    marginTop: 33,
  },
  heroStat: {
    flex: 1,
    alignItems: "center",
  },
  heroStatValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: "#FFFFFF",
  },
  heroStatLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 9.2,
    color: "rgba(255,255,255,0.67)",
    marginTop: 2,
  },
  heroDivider: {
    width: 1,
    height: 37,
    backgroundColor: "rgba(255,255,255,0.18)",
  },
  approvalNotice: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: COLORS.surface,
    borderRadius: 19,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 24,
  },
  noticeIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    backgroundColor: COLORS.purpleSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  noticeContent: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 11,
  },
  noticeTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.text,
  },
  noticeText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    lineHeight: 17,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  sectionHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 13,
  },
  sectionTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 19,
    color: COLORS.text,
    textAlign: "right",
  },
  sectionSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    marginTop: 2,
    textAlign: "right",
  },
  addButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.purple,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 13,
  },
  addButtonText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: "#FFFFFF",
  },
  allianceCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 23,
    padding: 16,
    marginBottom: 13,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  cardHeader: {
    width: "100%",
  },
  cardTitleContainer: {
    width: "100%",
    flexDirection: "row-reverse",
    alignItems: "center",
  },
  allianceTextContainer: {
    flex: 1,
    minWidth: 0,
    alignItems: "flex-end",
  },
  membersStack: {
    width: 94,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "flex-start",
    flexShrink: 0,
    marginRight: 12,
  },
  memberAvatar: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "#FFFFFF",
  },
  memberOverlap: {
    marginRight: -14,
  },
  memberText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.text,
  },
  allianceTitle: {
    width: "100%",
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: COLORS.text,
    textAlign: "right",
  },
  allianceDescription: {
    width: "100%",
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  approvalBadge: {
    alignSelf: "flex-end",
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.purpleSoft,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 10,
    marginTop: 10,
  },
  pendingBadge: {
    backgroundColor: "#FFF0D9",
  },
  approvalText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 9.5,
    color: COLORS.purpleDark,
  },
  pendingText: {
    color: "#C67B24",
  },
  amountRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginTop: 17,
  },
  amountLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10,
    color: COLORS.muted,
    textAlign: "right",
  },
  savedAmount: {
    fontFamily: "Tajawal_900Black",
    fontSize: 18,
    color: COLORS.text,
    marginTop: 2,
  },
  targetBlock: {
    alignItems: "flex-start",
  },
  targetAmount: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: COLORS.purpleDark,
    marginTop: 2,
  },
  progressHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginTop: 14,
  },
  progressText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
  },
  progressPercentage: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 11,
    color: COLORS.purpleDark,
  },
  progressTrack: {
    height: 8,
    borderRadius: 5,
    backgroundColor: "#E7E2F7",
    overflow: "hidden",
    marginTop: 7,
  },
  progressFill: {
    height: "100%",
    borderRadius: 5,
  },
  contributions: {
    flexDirection: "row-reverse",
    gap: 7,
    marginTop: 14,
  },
  contributionItem: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
    backgroundColor: "#F8F6FC",
    borderRadius: 11,
    paddingVertical: 8,
  },
  contributionDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  contributionName: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 9.5,
    color: COLORS.muted,
  },
  contributionAmount: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 9.5,
    color: COLORS.text,
  },
  viewButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 3,
    marginTop: 15,
    backgroundColor: COLORS.purpleSoft,
    borderRadius: 13,
    paddingVertical: 10,
  },
  viewButtonText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: COLORS.purpleDark,
  },
  bottomSpace: {
    height: 80,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(31,25,58,0.42)",
  },
  modalCard: {
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingTop: 11,
    paddingBottom: 30,
  },
  modalHandle: {
    width: 52,
    height: 5,
    borderRadius: 3,
    backgroundColor: "#DFD9ED",
    alignSelf: "center",
    marginBottom: 17,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 22,
  },
  modalClose: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "#F5F2FB",
    alignItems: "center",
    justifyContent: "center",
  },
  modalTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 22,
    color: COLORS.text,
    textAlign: "right",
  },
  modalSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  inputLabel: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: COLORS.text,
    textAlign: "right",
    marginBottom: 8,
    marginTop: 4,
  },
  input: {
    height: 55,
    borderRadius: 16,
    backgroundColor: "#F8F6FC",
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 14,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 15,
  },
  amountInputContainer: {
    height: 55,
    borderRadius: 16,
    backgroundColor: "#F8F6FC",
    borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 14,
    marginBottom: 15,
  },
  amountInput: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
  },
  currency: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.purpleDark,
  },
  childrenPicker: {
    flexDirection: "row-reverse",
    gap: 9,
  },
  selectedChild: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 7,
    backgroundColor: COLORS.purpleSoft,
    padding: 9,
    borderRadius: 14,
  },
  pickerAvatar: {
    width: 31,
    height: 31,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  pickerAvatarText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
    color: COLORS.text,
  },
  selectedChildText: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: COLORS.text,
    textAlign: "right",
  },
  confirmButton: {
    borderRadius: 17,
    overflow: "hidden",
    marginTop: 23,
  },
  confirmGradient: {
    height: 55,
    alignItems: "center",
    justifyContent: "center",
  },
  confirmText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#FFFFFF",
  },
});