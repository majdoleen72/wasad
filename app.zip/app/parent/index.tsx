import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { useRouter, type Href } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import Animated, { FadeInDown } from "react-native-reanimated";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const TASKS_ROUTE = "/parent/tasks" as Href;
const CHALLENGES_ROUTE = "/parent/challenges" as Href;
const STORIES_ROUTE = "/parent/stories" as Href;
const FINANCIAL_ROUTE = "/parent/financial" as Href;
const PROFILE_ROUTE = "/parent/profile" as Href;

const weeklySpending = [
  { day: "س", value: 32 },
  { day: "ح", value: 54 },
  { day: "ن", value: 38 },
  { day: "ث", value: 73 },
  { day: "ر", value: 46 },
  { day: "خ", value: 89 },
  { day: "ج", value: 61 },
];

const transactions = [
  {
    id: 1,
    title: "متجر الألعاب",
    category: "ترفيه",
    amount: "- 25 ر.س",
    icon: "game-controller-outline" as const,
    background: "#F1EBFF",
    color: "#7659D8",
  },
  {
    id: 2,
    title: "مكافأة إكمال مهمة",
    category: "مكافآت",
    amount: "+ 15 ر.س",
    icon: "sparkles-outline" as const,
    background: "#E5F8EF",
    color: "#42A47D",
  },
  {
    id: 3,
    title: "مقصف المدرسة",
    category: "طعام",
    amount: "- 12 ر.س",
    icon: "restaurant-outline" as const,
    background: "#FFF0E2",
    color: "#E6974D",
  },
];

export default function ParentDashboard() {
  const router = useRouter();

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  if (!fontsLoaded) {
    return null;
  }

  const goTo = async (route: Href) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push(route);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F7FC" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* الهيدر */}

        <View style={styles.header}>
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.notificationButton}
            onPress={() =>
              Haptics.selectionAsync()
            }
          >
            <Ionicons
              name="notifications-outline"
              size={22}
              color="#292D54"
            />

            <View style={styles.notificationDot} />
          </TouchableOpacity>

          <View style={styles.headerText}>
          
            <Text style={styles.parentName}>أهلًا، مجدولين</Text>
          </View>

          <TouchableOpacity
  activeOpacity={0.85}
  style={styles.parentAvatar}
  onPress={() => goTo(PROFILE_ROUTE)}
>
  <Image
    source="https://i.pravatar.cc/150?img=47"
    style={styles.parentAvatarImage}
    contentFit="cover"
    transition={250}
  />
</TouchableOpacity>
        </View>

        {/* البطاقة الرئيسية */}


        <Animated.View entering={FadeInDown.duration(550)}>
          <LinearGradient
            colors={["#5F4BCB", "#8E74F2", "#A98BFA"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.heroCard}
          >
          <View style={styles.heroCircleOne} />
          <View style={styles.heroCircleTwo} />

          <View style={styles.heroHeader}>
            <View style={styles.heroWalletIcon}>
              <Ionicons name="wallet-outline" size={27} color="#FFFFFF" />
            </View>

            <View style={styles.heroTitleArea}>
              <Text style={styles.heroSmallText}>إجمالي أرصدة الأطفال</Text>

              <View style={styles.heroMoneyRow}>
                <Text style={styles.heroAmount}>1,320</Text>
                <Text style={styles.heroCurrency}>ر.س</Text>
              </View>
            </View>
          </View>

          <View style={styles.heroProgressArea}>
            <View style={styles.heroProgressLabels}>
              <Text style={styles.heroProgressPercent}>65%</Text>
              <Text style={styles.heroProgressText}>متوسط التقدم نحو الأهداف</Text>
            </View>

            <View style={styles.heroProgressBackground}>
              <View style={styles.heroProgressFill} />
            </View>
          </View>

          <View style={styles.heroStats}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>810</Text>
              <Text style={styles.heroStatLabel}>تم ادخارها</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>470</Text>
              <Text style={styles.heroStatLabel}>مصروف الشهر</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>7</Text>
              <Text style={styles.heroStatLabel}>أهداف نشطة</Text>
            </View>
          </View>
          </LinearGradient>
        </Animated.View>

        {/* بطاقات المؤشرات */}

        <Animated.View
          entering={FadeInDown.delay(80).duration(520)}
          style={styles.summaryGrid}
        >
          <TouchableOpacity
            activeOpacity={0.86}
            style={[styles.summaryCard, styles.savingCard]}
            onPress={() => goTo(FINANCIAL_ROUTE)}
          >
            <View style={[styles.summaryIcon, styles.savingIcon]}>
              <Ionicons name="trending-up-outline" size={23} color="#3FA77E" />
            </View>

            <Text style={styles.summaryValue}>65%</Text>
            <Text style={styles.summaryTitle}>متوسط الادخار</Text>

            <View style={styles.miniProgressBackground}>
              <View
                style={[
                  styles.miniProgressFill,
                  {
                    width: "65%",
                    backgroundColor: "#57BF96",
                  },
                ]}
              />
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.86}
            style={[styles.summaryCard, styles.spendingCard]}
            onPress={() => goTo(FINANCIAL_ROUTE)}
          >
            <View style={[styles.summaryIcon, styles.spendingIcon]}>
              <Ionicons name="card-outline" size={23} color="#E6974D" />
            </View>

            <Text style={styles.summaryValue}>470</Text>
            <Text style={styles.summaryTitle}>مصروف الشهر</Text>

            <Text style={styles.summaryNote}>أقل بـ 12% من السابق</Text>
          </TouchableOpacity>
        </Animated.View>

        {/* رسم مصروف العائلة الأسبوعي */}

        <View style={styles.sectionHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => goTo(FINANCIAL_ROUTE)}
          >
            <Text style={styles.showAll}>التفاصيل</Text>
          </TouchableOpacity>

          <View style={styles.sectionTitleArea}>
        
            <Text style={styles.sectionTitle}>مصروف العائلة الأسبوعي</Text>
          </View>
        </View>

        <Animated.View
          entering={FadeInDown.delay(140).duration(520)}
          style={styles.chartCard}
        >
          <View style={styles.chartTop}>
            <View style={styles.chartBadge}>
              <Ionicons name="trending-down" size={15} color="#3DA77D" />
              <Text style={styles.chartBadgeText}>تحسن 8%</Text>
            </View>

            <View>
              <Text style={styles.chartAmount}>612 ر.س</Text>
              <Text style={styles.chartAmountLabel}>إجمالي المصروف</Text>
            </View>
          </View>

          <View style={styles.chart}>
            {weeklySpending.map((item, index) => {
              const isHighest = item.value === 89;

              return (
                <View key={index} style={styles.chartColumn}>
                  <View style={styles.barArea}>
                    {isHighest && (
                      <View style={styles.barTooltip}>
                        <Text style={styles.barTooltipText}>{item.value}</Text>
                      </View>
                    )}

                    <View
                      style={[
                        styles.bar,
                        {
                          height: item.value,
                        },
                        isHighest && styles.activeBar,
                      ]}
                    />
                  </View>

                  <Text
                    style={[
                      styles.chartDay,
                      isHighest && styles.activeChartDay,
                    ]}
                  >
                    {item.day}
                  </Text>
                </View>
              );
            })}
          </View>
        </Animated.View>

        {/* توزيع المصروف */}

        <View style={styles.sectionHeader}>
          <TouchableOpacity>
            <Text style={styles.showAll}>عرض الكل</Text>
          </TouchableOpacity>

          <View style={styles.sectionTitleArea}>
          
            <Text style={styles.sectionTitle}>توزيع مصاريف الأطفال</Text>
          </View>
        </View>

        <Animated.View
          entering={FadeInDown.delay(200).duration(520)}
          style={styles.categoriesCard}
        >
          <View style={styles.donutContainer}>
            <View style={styles.donutOuter}>
              <View style={styles.donutMiddle}>
                <View style={styles.donutInner}>
                  <Text style={styles.donutNumber}>470</Text>
                  <Text style={styles.donutText}>ر.س</Text>
                </View>
              </View>
            </View>
          </View>

          <View style={styles.categoryList}>
            <View style={styles.categoryItem}>
              <View style={styles.categoryTextArea}>
                <Text style={styles.categoryPercent}>35%</Text>
                <Text style={styles.categoryName}>ألعاب</Text>
              </View>

              <View style={[styles.categoryIcon, { backgroundColor: "#EEE8FF" }]}>
                <Text style={styles.categoryEmoji}>🎮</Text>
              </View>
            </View>

            <View style={styles.categoryItem}>
              <View style={styles.categoryTextArea}>
                <Text style={styles.categoryPercent}>25%</Text>
                <Text style={styles.categoryName}>طعام</Text>
              </View>

              <View style={[styles.categoryIcon, { backgroundColor: "#FFF0DF" }]}>
                <Text style={styles.categoryEmoji}>🍔</Text>
              </View>
            </View>

            <View style={styles.categoryItem}>
              <View style={styles.categoryTextArea}>
                <Text style={styles.categoryPercent}>22%</Text>
                <Text style={styles.categoryName}>تسوق</Text>
              </View>

              <View style={[styles.categoryIcon, { backgroundColor: "#E7F6FF" }]}>
                <Text style={styles.categoryEmoji}>🛍️</Text>
              </View>
            </View>

            <View style={styles.categoryItem}>
              <View style={styles.categoryTextArea}>
                <Text style={styles.categoryPercent}>18%</Text>
                <Text style={styles.categoryName}>تعليم</Text>
              </View>

              <View style={[styles.categoryIcon, { backgroundColor: "#E9F8EF" }]}>
                <Text style={styles.categoryEmoji}>📚</Text>
              </View>
            </View>
          </View>
        </Animated.View>

        {/* توصية وسد الذكية */}

        <Animated.View
          entering={FadeInDown.delay(260).duration(520)}
          style={styles.aiCard}
        >
          <View style={styles.aiDecoration} />

          <View style={styles.aiIcon}>
            <Ionicons name="sparkles" size={24} color="#7357DF" />
          </View>

          <View style={styles.aiContent}>
            <View style={styles.aiTitleRow}>
              <View style={styles.aiBadge}>
                <Text style={styles.aiBadgeText}>AI</Text>
              </View>

              <Text style={styles.aiTitle}>توصية وَسَد الذكية</Text>
            </View>

            <Text style={styles.aiDescription}>
              زاد الإنفاق على الألعاب هذا الأسبوع لدى طفلين. تقترح وَسَد تحويل 10 ريالات من مصروف كل طفل إلى أهداف الادخار.
            </Text>

            <TouchableOpacity
              activeOpacity={0.8}
              style={styles.aiButton}
              onPress={() =>
                Haptics.notificationAsync(
                  Haptics.NotificationFeedbackType.Success
                )
              }
            >
              <Ionicons name="arrow-back" size={15} color="#7357DF" />
              <Text style={styles.aiButtonText}>عرض الخطة المقترحة</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>

        {/* التحدي الجاري */}

        <View style={styles.sectionHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => goTo(CHALLENGES_ROUTE)}
          >
            <Text style={styles.showAll}>عرض الكل</Text>
          </TouchableOpacity>

          <View style={styles.sectionTitleArea}>
          
            <Text style={styles.sectionTitle}>تحديات الأطفال</Text>
          </View>
        </View>

        <Animated.View entering={FadeInDown.delay(320).duration(520)}>
          <TouchableOpacity
            activeOpacity={0.9}
            style={styles.challengeCard}
            onPress={() => goTo(CHALLENGES_ROUTE)}
          >
          <View style={styles.challengeImageArea}>
            <Image
              source="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900"
              style={styles.challengeImage}
              contentFit="cover"
              transition={350}
            />

            <View style={styles.challengeLiveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.challengeLiveText}>جاري الآن</Text>
            </View>
          </View>

          <View style={styles.challengeContent}>
            <View style={styles.challengeTop}>
              <View style={styles.daysBadge}>
                <Ionicons name="time-outline" size={14} color="#8B8CA0" />
                <Text style={styles.daysText}>12 يومًا</Text>
              </View>

              <View style={styles.challengeTitleArea}>
                <Text style={styles.challengeTitle}>تحدي الشوز الجديد</Text>
                <Text style={styles.challengeSubtitle}>
                  مجد وسارة ضد أصدقائهم
                </Text>
              </View>
            </View>

            <View style={styles.challengeProgressHeader}>
              <Text style={styles.challengePercentage}>70%</Text>
              <Text style={styles.challengeMoney}>350 من 500 ر.س</Text>
            </View>

            <View style={styles.challengeProgressBackground}>
              <View style={styles.challengeProgressFill} />
            </View>
          </View>
          </TouchableOpacity>
        </Animated.View>

        {/* آخر العمليات */}

        <View style={styles.sectionHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => goTo(FINANCIAL_ROUTE)}
          >
            <Text style={styles.showAll}>كل العمليات</Text>
          </TouchableOpacity>

          <View style={styles.sectionTitleArea}>
         
            <Text style={styles.sectionTitle}>العمليات الأخيرة</Text>
          </View>
        </View>

        <Animated.View
          entering={FadeInDown.delay(380).duration(520)}
          style={styles.transactionsCard}
        >
          {transactions.map((transaction, index) => (
            <View
              key={transaction.id}
              style={[
                styles.transactionRow,
                index !== transactions.length - 1 &&
                  styles.transactionBorder,
              ]}
            >
              <Text
                style={[
                  styles.transactionAmount,
                  transaction.amount.includes("+") &&
                    styles.positiveAmount,
                ]}
              >
                {transaction.amount}
              </Text>

              <View style={styles.transactionInfo}>
                <Text style={styles.transactionTitle}>
                  {transaction.title}
                </Text>

                <Text style={styles.transactionCategory}>
                  {transaction.category}
                </Text>
              </View>

              <View
                style={[
                  styles.transactionIcon,
                  {
                    backgroundColor: transaction.background,
                  },
                ]}
              >
                <Ionicons
                  name={transaction.icon}
                  size={21}
                  color={transaction.color}
                />
              </View>
            </View>
          ))}
        </Animated.View>

        {/* اختصارات */}

        <View style={styles.sectionHeader}>
          <View />
          <Text style={styles.sectionTitle}>وصول سريع</Text>
        </View>

        <Animated.View
          entering={FadeInDown.delay(440).duration(520)}
          style={styles.quickActions}
        >
          <TouchableOpacity
            style={styles.quickAction}
            onPress={() => goTo(TASKS_ROUTE)}
          >
            <View style={[styles.quickActionIcon, { backgroundColor: "#EAF4FF" }]}>
              <Ionicons name="checkbox-outline" size={23} color="#4389CE" />
            </View>
            <Text style={styles.quickActionText}>المهام</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickAction}
            onPress={() => goTo(STORIES_ROUTE)}
          >
            <View style={[styles.quickActionIcon, { backgroundColor: "#F3ECFF" }]}>
              <Ionicons name="book-outline" size={23} color="#7659D8" />
            </View>
            <Text style={styles.quickActionText}>القصص</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickAction}
            onPress={() => goTo(CHALLENGES_ROUTE)}
          >
            <View style={[styles.quickActionIcon, { backgroundColor: "#E8F8F1" }]}>
              <Ionicons name="trophy-outline" size={23} color="#42A47D" />
            </View>
            <Text style={styles.quickActionText}>التحديات</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickAction}
            onPress={() => goTo(FINANCIAL_ROUTE)}
          >
            <View style={[styles.quickActionIcon, { backgroundColor: "#FFF0E2" }]}>
              <Ionicons name="wallet-outline" size={23} color="#E6974D" />
            </View>
            <Text style={styles.quickActionText}>المالي</Text>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const CARD_SHADOW = {
  shadowColor: "#514773",
  shadowOffset: {
    width: 0,
    height: 7,
  },
  shadowOpacity: 0.1,
  shadowRadius: 16,
  elevation: 6,
};

const SOFT_SHADOW = {
  shadowColor: "#514773",
  shadowOffset: {
    width: 0,
    height: 4,
  },
  shadowOpacity: 0.07,
  shadowRadius: 11,
  elevation: 3,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F7FC",
  },

  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 180,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 25,
  },

  notificationButton: {
    width: 46,
    height: 46,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    ...SOFT_SHADOW,
  },

  notificationDot: {
    position: "absolute",
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#FF6B7A",
    top: 10,
    right: 10,
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },

  headerText: {
    flex: 1,
    alignItems: "flex-end",
    marginHorizontal: 13,
  },

  welcomeText: {
    color: "#9A9BAC",
    fontSize: 17,
    fontFamily: "Tajawal_400Regular",
    marginBottom: 5,
  },

  parentName: {
    color: "#282C52",
    fontSize: 26,
    fontFamily: "Tajawal_900Black",
  },

  parentAvatar: {
    width: 50,
    height: 50,
    borderRadius: 18,
    padding: 3,
    backgroundColor: "#FFFFFF",
    ...SOFT_SHADOW,
  },

  parentAvatarImage: {
    width: "100%",
    height: "100%",
    borderRadius: 15,
  },

  heroCard: {
    minHeight: 260,
    borderRadius: 32,
    backgroundColor: "#6F5BD3",
    padding: 23,
    overflow: "hidden",
    marginBottom: 20,
    ...CARD_SHADOW,
    shadowColor: "#6F5BD3",
    shadowOpacity: 0.23,
  },

  heroCircleOne: {
    position: "absolute",
    width: 210,
    height: 210,
    borderRadius: 105,
    backgroundColor: "rgba(255,255,255,0.07)",
    top: -100,
    left: -50,
  },

  heroCircleTwo: {
    position: "absolute",
    width: 170,
    height: 170,
    borderRadius: 85,
    backgroundColor: "rgba(255,255,255,0.06)",
    bottom: -80,
    right: -30,
  },

  heroHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  heroWalletIcon: {
    width: 55,
    height: 55,
    borderRadius: 19,
    backgroundColor: "rgba(255,255,255,0.17)",
    alignItems: "center",
    justifyContent: "center",
  },

  heroTitleArea: {
    alignItems: "flex-end",
  },

  heroSmallText: {
    color: "rgba(255,255,255,0.75)",
    fontSize: 17,
    fontFamily: "Tajawal_400Regular",
  },

  heroMoneyRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    marginTop: 6,
    gap: 6,
  },

  heroAmount: {
    color: "#FFFFFF",
    fontSize: 44,
    fontFamily: "Tajawal_900Black",
  },

  heroCurrency: {
    color: "#FFFFFF",
    fontSize: 18,
    fontFamily: "Tajawal_400Regular",
    marginBottom: 7,
  },

  heroProgressArea: {
    marginTop: 25,
  },

  heroProgressLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 9,
  },

  heroProgressPercent: {
    color: "#FFFFFF",
    fontSize: 17,
    fontFamily: "Tajawal_900Black",
  },

  heroProgressText: {
    color: "rgba(255,255,255,0.76)",
    fontSize: 15,
    fontFamily: "Tajawal_400Regular",
  },

  heroProgressBackground: {
    height: 8,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.18)",
    overflow: "hidden",
  },

  heroProgressFill: {
    width: "65%",
    height: "100%",
    borderRadius: 10,
    backgroundColor: "#FFFFFF",
  },

  heroStats: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 28,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.16)",
  },

  heroStat: {
    flex: 1,
    alignItems: "center",
  },

  heroStatValue: {
    color: "#FFFFFF",
    fontSize: 24,
    fontFamily: "Tajawal_900Black",
  },

  heroStatLabel: {
    color: "rgba(255,255,255,0.67)",
    fontSize: 14,
    fontFamily: "Tajawal_400Regular",
    marginTop: 5,
  },

  heroDivider: {
    width: 1,
    height: 31,
    backgroundColor: "rgba(255,255,255,0.17)",
  },

  summaryGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 34,
  },

  summaryCard: {
    width: "48%",
    minHeight: 168,
    borderRadius: 26,
    padding: 17,
    ...CARD_SHADOW,
  },

  savingCard: {
    backgroundColor: "#EAF8F2",
  },

  spendingCard: {
    backgroundColor: "#FFF2E5",
  },

  summaryIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 15,
  },

  savingIcon: {
    backgroundColor: "#D1F0E3",
  },

  spendingIcon: {
    backgroundColor: "#FFE1C3",
  },

  summaryValue: {
    color: "#303354",
    fontSize: 30,
    fontFamily: "Tajawal_900Black",
    textAlign: "right",
  },

  summaryTitle: {
    color: "#66697E",
    fontSize: 16,
    fontFamily: "Tajawal_700Bold",
    textAlign: "right",
    marginTop: 4,
  },

  summaryNote: {
    color: "#B07C46",
    fontSize: 13,
    fontFamily: "Tajawal_400Regular",
    marginTop: 16,
    textAlign: "right",
  },

  miniProgressBackground: {
    height: 6,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.75)",
    overflow: "hidden",
    marginTop: 18,
  },

  miniProgressFill: {
    height: "100%",
    borderRadius: 10,
  },

  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginBottom: 15,
  },

  sectionTitleArea: {
    alignItems: "flex-end",
  },

  sectionTitle: {
    color: "#292D54",
    fontSize: 24,
    fontFamily: "Tajawal_900Black",
  },

  sectionSubtitle: {
    color: "#A2A3B0",
    fontSize: 14,
    fontFamily: "Tajawal_400Regular",
    marginBottom: 3,
  },

  showAll: {
    color: "#755AD6",
    fontSize: 16,
    fontFamily: "Tajawal_800ExtraBold",
  },

  chartCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 28,
    padding: 20,
    marginBottom: 34,
    ...CARD_SHADOW,
  },

  chartTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  chartBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#E9F8F1",
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 15,
  },

  chartBadgeText: {
    color: "#3DA77D",
    fontSize: 14,
    fontFamily: "Tajawal_800ExtraBold",
  },

  chartAmount: {
    color: "#303354",
    fontSize: 25,
    fontFamily: "Tajawal_900Black",
    textAlign: "right",
  },

  chartAmountLabel: {
    color: "#999AAA",
    fontSize: 13,
    fontFamily: "Tajawal_400Regular",
    textAlign: "right",
    marginTop: 3,
  },

  chart: {
    height: 150,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    marginTop: 26,
  },

  chartColumn: {
    alignItems: "center",
    flex: 1,
  },

  barArea: {
    height: 112,
    justifyContent: "flex-end",
    alignItems: "center",
  },

  bar: {
    width: 23,
    minHeight: 20,
    borderRadius: 12,
    backgroundColor: "#E4DFFF",
  },

  activeBar: {
    backgroundColor: "#7659D8",
  },

  barTooltip: {
    backgroundColor: "#7659D8",
    borderRadius: 9,
    paddingHorizontal: 7,
    paddingVertical: 4,
    marginBottom: 5,
  },

  barTooltipText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontFamily: "Tajawal_800ExtraBold",
  },

  chartDay: {
    color: "#A3A4B1",
    fontSize: 14,
    fontFamily: "Tajawal_400Regular",
    marginTop: 9,
  },

  activeChartDay: {
    color: "#7659D8",
    fontFamily: "Tajawal_900Black",
  },

  categoriesCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 28,
    padding: 20,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 30,
    ...CARD_SHADOW,
  },

  donutContainer: {
    width: "42%",
    alignItems: "center",
  },

  donutOuter: {
    width: 125,
    height: 125,
    borderRadius: 63,
    borderWidth: 16,
    borderColor: "#7659D8",
    alignItems: "center",
    justifyContent: "center",
  },

  donutMiddle: {
    width: 85,
    height: 85,
    borderRadius: 43,
    borderWidth: 9,
    borderColor: "#F0B46E",
    alignItems: "center",
    justifyContent: "center",
  },

  donutInner: {
    alignItems: "center",
    justifyContent: "center",
  },

  donutNumber: {
    color: "#303354",
    fontSize: 24,
    fontFamily: "Tajawal_900Black",
  },

  donutText: {
    color: "#9A9BAB",
    fontSize: 13,
    fontFamily: "Tajawal_400Regular",
  },

  categoryList: {
    flex: 1,
    gap: 12,
  },

  categoryItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },

  categoryTextArea: {
    alignItems: "flex-end",
    marginRight: 9,
  },

  categoryName: {
    color: "#4E506A",
    fontSize: 15,
    fontFamily: "Tajawal_800ExtraBold",
  },

  categoryPercent: {
    color: "#9A9BAB",
    fontSize: 13,
    fontFamily: "Tajawal_400Regular",
    marginBottom: 2,
  },

  categoryIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },

  categoryEmoji: {
    fontSize: 19,
    fontFamily: "Tajawal_400Regular",
  },

  aiCard: {
    backgroundColor: "#F1ECFF",
    borderRadius: 28,
    padding: 20,
    flexDirection: "row",
    overflow: "hidden",
    marginBottom: 34,
    ...CARD_SHADOW,
    shadowColor: "#7659D8",
    shadowOpacity: 0.14,
  },

  aiDecoration: {
    position: "absolute",
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: "rgba(117,90,214,0.07)",
    right: -40,
    bottom: -55,
  },

  aiIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    ...SOFT_SHADOW,
  },

  aiContent: {
    flex: 1,
    alignItems: "flex-end",
    marginLeft: 15,
  },

  aiTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
  },

  aiBadge: {
    backgroundColor: "#7659D8",
    borderRadius: 7,
    paddingHorizontal: 6,
    paddingVertical: 3,
  },

  aiBadgeText: {
    color: "#FFFFFF",
    fontSize: 9,
    fontFamily: "Tajawal_900Black",
  },

  aiTitle: {
    color: "#343657",
    fontSize: 19,
    fontFamily: "Tajawal_900Black",
  },

  aiDescription: {
    color: "#77798E",
    fontSize: 15,
    fontFamily: "Tajawal_400Regular",
    lineHeight: 21,
    textAlign: "right",
    marginTop: 8,
  },

  aiButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 13,
  },

  aiButtonText: {
    color: "#7357DF",
    fontSize: 14,
    fontFamily: "Tajawal_900Black",
  },

  challengeCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 29,
    overflow: "hidden",
    marginBottom: 34,
    ...CARD_SHADOW,
  },

  challengeImageArea: {
    height: 155,
    position: "relative",
  },

  challengeImage: {
    width: "100%",
    height: "100%",
  },

  challengeLiveBadge: {
    position: "absolute",
    left: 14,
    top: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.92)",
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 15,
  },

  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#45AD87",
  },

  challengeLiveText: {
    color: "#45A982",
    fontSize: 14,
    fontFamily: "Tajawal_800ExtraBold",
  },

  challengeContent: {
    padding: 18,
  },

  challengeTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  daysBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#F3F2F8",
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 14,
  },

  daysText: {
    color: "#8B8CA0",
    fontSize: 14,
    fontFamily: "Tajawal_400Regular",
  },

  challengeTitleArea: {
    alignItems: "flex-end",
  },

  challengeTitle: {
    color: "#2D3052",
    fontSize: 21,
    fontFamily: "Tajawal_900Black",
  },

  challengeSubtitle: {
    color: "#9A9BAB",
    fontSize: 14,
    fontFamily: "Tajawal_400Regular",
    marginTop: 4,
  },

  challengeProgressHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 18,
    marginBottom: 8,
  },

  challengePercentage: {
    color: "#7659D8",
    fontSize: 16,
    fontFamily: "Tajawal_900Black",
  },

  challengeMoney: {
    color: "#797B90",
    fontSize: 14,
    fontFamily: "Tajawal_400Regular",
  },

  challengeProgressBackground: {
    height: 8,
    borderRadius: 10,
    backgroundColor: "#EEEAF8",
    overflow: "hidden",
  },

  challengeProgressFill: {
    width: "70%",
    height: "100%",
    borderRadius: 10,
    backgroundColor: "#7659D8",
  },

  transactionsCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 28,
    paddingHorizontal: 17,
    marginBottom: 30,
    ...CARD_SHADOW,
  },

  transactionRow: {
    height: 81,
    flexDirection: "row",
    alignItems: "center",
  },

  transactionBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#F0EEF5",
  },

  transactionAmount: {
    color: "#E06767",
    fontSize: 15,
    fontFamily: "Tajawal_900Black",
  },

  positiveAmount: {
    color: "#3FA77E",
  },

  transactionInfo: {
    flex: 1,
    alignItems: "flex-end",
    marginHorizontal: 12,
  },

  transactionTitle: {
    color: "#41445F",
    fontSize: 16,
    fontFamily: "Tajawal_800ExtraBold",
  },

  transactionCategory: {
    color: "#A0A1AF",
    fontSize: 13,
    fontFamily: "Tajawal_400Regular",
    marginTop: 4,
  },

  transactionIcon: {
    width: 44,
    height: 44,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },

  quickActions: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  quickAction: {
    width: "23%",
    backgroundColor: "#FFFFFF",
    borderRadius: 21,
    alignItems: "center",
    paddingVertical: 14,
    ...SOFT_SHADOW,
  },

  quickActionIcon: {
    width: 45,
    height: 45,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },

  quickActionText: {
    color: "#686A80",
    fontSize: 14,
    fontFamily: "Tajawal_800ExtraBold",
  },
});