import React, { useMemo, useState } from "react";
import {
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { router , type Href} from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  useFonts,
} from "@expo-google-fonts/tajawal";

const { width } = Dimensions.get("window");

type ChallengeStatus = "active" | "pending" | "completed";
type ChallengeType = "saving" | "tasks" | "spending";

type Challenge = {
  id: string;
  title: string;
  subtitle: string;
  type: ChallengeType;
  status: ChallengeStatus;

  childName: string;
  friendName: string;
  childEmoji: string;
  friendEmoji: string;

  childProgress: number;
  friendProgress: number;

  remainingText: string;
  prize: string;

  itemName?: string;
  itemPrice?: number;
  savedAmount?: number;

  tasksCompleted?: number;
  tasksTotal?: number;

  colors: readonly [string, string, ...string[]];
  softColor: string;
};

type FilterKey = "all" | ChallengeStatus;

const FILTERS: Array<{
  key: FilterKey;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
}> = [
  {
    key: "all",
    label: "الكل",
    icon: "grid-outline",
  },
  {
    key: "active",
    label: "نشطة",
    icon: "flame-outline",
  },
  {
    key: "pending",
    label: "الطلبات",
    icon: "mail-unread-outline",
  },
  {
    key: "completed",
    label: "مكتملة",
    icon: "trophy-outline",
  },
];

const CHALLENGES: Challenge[] = [
  {
    id: "saving-bike",
    title: "تحدي الدراجة الجديدة",
    subtitle: "من يصل إلى هدف الادخار أولًا؟",
    type: "saving",
    status: "active",

    childName: "سلمان",
    friendName: "خالد",
    childEmoji: "👦🏻",
    friendEmoji: "🧒🏻",

    childProgress: 75,
    friendProgress: 62,

    remainingText: "متبقي 3 أيام",
    prize: "100 نقطة",

    itemName: "دراجة",
    itemPrice: 500,
    savedAmount: 375,

    colors: ["#FF2E63", "#FF5B52", "#FF884B"],
    softColor: "#FFF0F2",
  },
  {
    id: "room-tasks",
    title: "تحدي أبطال المهام",
    subtitle: "إنجاز المهام اليومية لمدة أسبوع",
    type: "tasks",
    status: "active",

    childName: "لمار",
    friendName: "جود",
    childEmoji: "👧🏻",
    friendEmoji: "👧🏼",

    childProgress: 80,
    friendProgress: 60,

    remainingText: "متبقي يومان",
    prize: "نجمة ذهبية",

    tasksCompleted: 8,
    tasksTotal: 10,

    colors: ["#6C4CF1", "#8D68F8", "#B284FF"],
    softColor: "#F3EEFF",
  },
  {
    id: "smart-spending",
    title: "تحدي المصروف الذكي",
    subtitle: "من يقلل المشتريات العشوائية؟",
    type: "spending",
    status: "pending",

    childName: "سارة",
    friendName: "نورة",
    childEmoji: "👧🏽",
    friendEmoji: "👧🏻",

    childProgress: 0,
    friendProgress: 0,

    remainingText: "بانتظار الموافقة",
    prize: "80 نقطة",

    colors: ["#10A77A", "#25BE8D", "#58D7A9"],
    softColor: "#EAFBF5",
  },
  {
    id: "weekly-saving",
    title: "تحدي الادخار الأسبوعي",
    subtitle: "اكتمل التحدي بنجاح",
    type: "saving",
    status: "completed",

    childName: "ريان",
    friendName: "مازن",
    childEmoji: "🧒🏽",
    friendEmoji: "👦🏼",

    childProgress: 100,
    friendProgress: 92,

    remainingText: "اكتمل",
    prize: "120 نقطة",

    itemName: "لعبة تعليمية",
    itemPrice: 200,
    savedAmount: 200,

    colors: ["#FFB020", "#FF8A25", "#FF6C3A"],
    softColor: "#FFF5E7",
  },
];

export default function ChallengesScreen() {
  const [selectedFilter, setSelectedFilter] =
    useState<FilterKey>("all");

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
  });

  const visibleChallenges = useMemo(() => {
    if (selectedFilter === "all") {
      return CHALLENGES;
    }

    return CHALLENGES.filter(
      (challenge) => challenge.status === selectedFilter
    );
  }, [selectedFilter]);

  const activeCount = CHALLENGES.filter(
    (challenge) => challenge.status === "active"
  ).length;

  const pendingCount = CHALLENGES.filter(
    (challenge) => challenge.status === "pending"
  ).length;

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingScreen}>
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  const openCreateChallenge = () => {
    router.push("/challenges/create");
  };

  const openChallengeDetails = (challengeId: string) => {
    router.push('/challenges/${challengeId}');
  };

  return (
    <View style={styles.screen}>
      <LinearGradient
        colors={["#FF245F", "#FF4E62", "#FF754F"]}
        start={{ x: 0.05, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.headerGradient}
      >
        <SafeAreaView edges={["top"]}>
          <View style={styles.headerDecorationOne}>
            <Ionicons
              name="flame"
              size={180}
              color="rgba(255,255,255,0.08)"
            />
          </View>

          <View style={styles.headerDecorationTwo}>
            <Ionicons
              name="flame"
              size={120}
              color="rgba(255,255,255,0.10)"
            />
          </View>

          <View style={styles.sparkOne}>
            <Ionicons
              name="sparkles"
              size={27}
              color="rgba(255,255,255,0.45)"
            />
          </View>

          <View style={styles.sparkTwo}>
            <Ionicons
              name="sparkles"
              size={20}
              color="rgba(255,255,255,0.35)"
            />
          </View>

          <View style={styles.headerTopRow}>
            <Pressable
              style={({ pressed }) => [
                styles.headerIconButton,
                pressed && styles.buttonPressed,
              ]}
            >
              <Ionicons
                name="notifications-outline"
                size={23}
                color="#FFFFFF"
              />

              {pendingCount > 0 && (
                <View style={styles.notificationBadge}>
                  <Text style={styles.notificationBadgeText}>
                    {pendingCount}
                  </Text>
                </View>
              )}
            </Pressable>

            <View style={styles.headerTitleArea}>
              <Text style={styles.headerTitle}>التحديات</Text>

              <Text style={styles.headerSubtitle}>
                مغامرات ممتعة تجمع طفلك بأصدقائه
              </Text>
            </View>

            <Pressable
              style={({ pressed }) => [
                styles.headerIconButton,
                pressed && styles.buttonPressed,
              ]}
              onPress={() => router.back()}
            >
              <Ionicons
                name="chevron-forward"
                size={25}
                color="#FFFFFF"
              />
            </Pressable>
          </View>

          <View style={styles.headerSummaryRow}>
            <View style={styles.summaryCard}>
              <View style={styles.summaryIcon}>
                <Ionicons
                  name="flame"
                  size={25}
                  color="#FF4A56"
                />
              </View>

              <View>
                <Text style={styles.summaryNumber}>
                  {activeCount}
                </Text>
                <Text style={styles.summaryLabel}>
                  تحديات نشطة
                </Text>
              </View>
            </View>

            <Pressable
              onPress={openCreateChallenge}
              style={({ pressed }) => [
                styles.createChallengeButton,
                pressed && styles.createButtonPressed,
              ]}
            >
              <Ionicons
                name="add-circle"
                size={25}
                color="#FF315F"
              />

              <Text style={styles.createChallengeText}>
                إنشاء تحدي
              </Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </LinearGradient>

      <View style={styles.contentSheet}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filtersContainer}
          >
            {FILTERS.map((filter) => {
              const isSelected = selectedFilter === filter.key;

              return (
                <Pressable
                  key={filter.key}
                  onPress={() => setSelectedFilter(filter.key)}
                  style={({ pressed }) => [
                    styles.filterButton,
                    isSelected && styles.selectedFilterButton,
                    pressed && styles.filterPressed,
                  ]}
                >
                  <Ionicons
                    name={filter.icon}
                    size={18}
                    color={
                      isSelected ? "#FFFFFF" : "#777A8D"
                    }
                  />

                  <Text
                    style={[
                      styles.filterText,
                      isSelected && styles.selectedFilterText,
                    ]}
                  >
                    {filter.label}
                  </Text>

                  {filter.key === "pending" && pendingCount > 0 && (
                    <View
                      style={[
                        styles.filterCount,
                        isSelected &&
                          styles.selectedFilterCount,
                      ]}
                    >
                      <Text
                        style={[
                          styles.filterCountText,
                          isSelected &&
                            styles.selectedFilterCountText,
                        ]}
                      >
                        {pendingCount}
                      </Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </ScrollView>

          <View style={styles.sectionHeader}>
            <Pressable style={styles.sortButton}>
              <Ionicons
                name="options-outline"
                size={19}
                color="#717487"
              />

              <Text style={styles.sortText}>ترتيب</Text>
            </Pressable>

            <View style={styles.sectionTitleArea}>
              <Text style={styles.sectionTitle}>
                {getSectionTitle(selectedFilter)}
              </Text>

              <Text style={styles.sectionCount}>
                {visibleChallenges.length} تحديات
              </Text>
            </View>
          </View>

          {visibleChallenges.length > 0 ? (
            visibleChallenges.map((challenge) => (
              <ChallengeCard
                key={challenge.id}
                challenge={challenge}
                onPress={() =>
                  openChallengeDetails(challenge.id)
                }
              />
            ))
          ) : (
            <EmptyChallenges onCreate={openCreateChallenge} />
          )}

          <Pressable
            onPress={openCreateChallenge}
            style={({ pressed }) => [
              styles.bottomCreateButton,
              pressed && styles.bottomButtonPressed,
            ]}
          >
            <LinearGradient
              colors={["#FF2E63", "#FF7650"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.bottomCreateGradient}
            >
              <Ionicons
                name="add-circle"
                size={26}
                color="#FFFFFF"
              />

              <Text style={styles.bottomCreateText}>
                إنشاء تحدي جديد
              </Text>
            </LinearGradient>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
}

function ChallengeCard({
  challenge,
  onPress,
}: {
  challenge: Challenge;
  onPress: () => void;
}) {
  const status = getStatusDetails(challenge.status);
  const type = getTypeDetails(challenge.type);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.challengeCard,
        pressed && styles.challengeCardPressed,
      ]}
    >
      <LinearGradient
        colors={challenge.colors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.challengeBanner}
      >
        <View style={styles.cardFlameOne}>
          <Ionicons
            name={type.backgroundIcon}
            size={115}
            color="rgba(255,255,255,0.10)"
          />
        </View>

        <View style={styles.cardFlameTwo}>
          <Ionicons
            name={type.backgroundIcon}
            size={75}
            color="rgba(255,255,255,0.09)"
          />
        </View>

        <View style={styles.cardTopRow}>
          <View
            style={[
              styles.statusBadge,
              {
                backgroundColor: status.backgroundColor,
              },
            ]}
          >
            <View
              style={[
                styles.statusDot,
                {
                  backgroundColor: status.color,
                },
              ]}
            />

            <Text
              style={[
                styles.statusText,
                {
                  color: status.color,
                },
              ]}
            >
              {status.label}
            </Text>
          </View>

          <View style={styles.challengeTypeBadge}>
            <Ionicons
              name={type.icon}
              size={17}
              color="#FFFFFF"
            />

            <Text style={styles.challengeTypeText}>
              {type.label}
            </Text>
          </View>
        </View>

        <View style={styles.challengeTitleArea}>
          <Text style={styles.challengeTitle}>
            {challenge.title}
          </Text>

          <Text style={styles.challengeSubtitle}>
            {challenge.subtitle}
          </Text>
        </View>

        <View style={styles.competitorsRow}>
          <Competitor
            emoji={challenge.childEmoji}
            name={challenge.childName}
            progress={challenge.childProgress}
          />

          <View style={styles.vsArea}>
            <View style={styles.vsCircle}>
              <Ionicons
                name="flash"
                size={15}
                color="#FFB12C"
              />

              <Text style={styles.vsText}>VS</Text>
            </View>
          </View>

          <Competitor
            emoji={challenge.friendEmoji}
            name={challenge.friendName}
            progress={challenge.friendProgress}
          />
        </View>
      </LinearGradient>

      <View style={styles.challengeBottom}>
        <View style={styles.challengeMetaRow}>
          <MetaItem
            icon="gift-outline"
            label="الجائزة"
            value={challenge.prize}
            color="#FF7B24"
          />

          <View style={styles.metaDivider} />

          <MetaItem
            icon="time-outline"
            label="المدة"
            value={challenge.remainingText}
            color="#FF4168"
          />

          <View style={styles.metaDivider} />

          <MetaItem
            icon={type.icon}
            label={type.detailLabel}
            value={getChallengeDetail(challenge)}
            color={challenge.colors[0]}
          />
        </View>

        <View
          style={[
            styles.progressSummary,
            {
              backgroundColor: challenge.softColor,
            },
          ]}
        >
          <Pressable style={styles.openChallengeButton}>
            <Text
              style={[
                styles.openChallengeText,
                {
                  color: challenge.colors[0],
                },
              ]}
            >
              عرض التحدي
            </Text>

            <Ionicons
              name="chevron-back"
              size={18}
              color={challenge.colors[0]}
            />
          </Pressable>

          <Text style={styles.progressSummaryText}>
            {getSummaryText(challenge)}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

function Competitor({
  emoji,
  name,
  progress,
}: {
  emoji: string;
  name: string;
  progress: number;
}) {
  return (
    <View style={styles.competitor}>
      <View style={styles.avatarOuter}>
        <View style={styles.avatarInner}>
          <Text style={styles.avatarEmoji}>{emoji}</Text>
        </View>
      </View>

      <Text style={styles.competitorName}>{name}</Text>

      <View style={styles.competitorProgressBadge}>
        <Text style={styles.competitorProgressText}>
          {progress}%
        </Text>
      </View>
    </View>
  );
}

function MetaItem({
  icon,
  label,
  value,
  color,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <View style={styles.metaItem}>
      <Ionicons name={icon} size={21} color={color} />

      <Text style={styles.metaLabel}>{label}</Text>

      <Text numberOfLines={1} style={styles.metaValue}>
        {value}
      </Text>
    </View>
  );
}

function EmptyChallenges({
  onCreate,
}: {
  onCreate: () => void;
}) {
  return (
    <View style={styles.emptyContainer}>
      <View style={styles.emptyIcon}>
        <Ionicons
          name="trophy-outline"
          size={43}
          color="#FF4C65"
        />
      </View>

      <Text style={styles.emptyTitle}>
        لا توجد تحديات هنا
      </Text>

      <Text style={styles.emptyDescription}>
        أنشئي تحديًا جديدًا لطفلك مع أحد أصدقائه
      </Text>

      <Pressable
        onPress={onCreate}
        style={styles.emptyCreateButton}
      >
        <Ionicons
          name="add-circle-outline"
          size={21}
          color="#FFFFFF"
        />

        <Text style={styles.emptyCreateText}>
          إنشاء تحدي
        </Text>
      </Pressable>
    </View>
  );
}

function getSectionTitle(filter: FilterKey) {
  switch (filter) {
    case "active":
      return "التحديات النشطة";

    case "pending":
      return "طلبات التحديات";

    case "completed":
      return "التحديات المكتملة";

    default:
      return "جميع التحديات";
  }
}

function getChallengeDetail(challenge: Challenge) {
  if (
    challenge.type === "tasks" &&
    challenge.tasksCompleted !== undefined &&
    challenge.tasksTotal !== undefined
  ) {
    return `${challenge.tasksCompleted} من ${challenge.tasksTotal}`;
  }

  if (
    challenge.type === "saving" &&
    challenge.itemName
  ) {
    return challenge.itemName;
  }

  return "مصروف ذكي";
}

function getSummaryText(challenge: Challenge) {
  if (
    challenge.type === "tasks" &&
    challenge.tasksCompleted !== undefined &&
    challenge.tasksTotal !== undefined
  ) {
    return `تم إنجاز ${challenge.tasksCompleted} مهام من أصل ${challenge.tasksTotal}`;
  }

  if (
    challenge.type === "saving" &&
    challenge.savedAmount !== undefined &&
    challenge.itemPrice !== undefined
  ) {
    return `تم ادخار ${challenge.savedAmount} من ${challenge.itemPrice} ريال`;
  }

  if (challenge.status === "pending") {
    return "سيبدأ التحدي بعد موافقة ولي أمر الصديق";
  }

  return "تابعي تقدم طفلك ونتائج المنافسة";
}

function getStatusDetails(status: ChallengeStatus) {
  switch (status) {
    case "active":
      return {
        label: "نشط الآن",
        color: "#DD2750",
        backgroundColor: "#FFFFFF",
      };

    case "pending":
      return {
        label: "بانتظار الموافقة",
        color: "#D67A00",
        backgroundColor: "#FFF5DC",
      };

    case "completed":
      return {
        label: "مكتمل",
        color: "#16885E",
        backgroundColor: "#E7FFF5",
      };
  }
}

function getTypeDetails(type: ChallengeType): {
  label: string;
  detailLabel: string;
  icon: keyof typeof Ionicons.glyphMap;
  backgroundIcon: keyof typeof Ionicons.glyphMap;
} {
  switch (type) {
    case "saving":
      return {
        label: "هدف ادخاري",
        detailLabel: "الغرض",
        icon: "wallet-outline",
        backgroundIcon: "flame",
      };

    case "tasks":
      return {
        label: "تحدي مهام",
        detailLabel: "المهام",
        icon: "checkbox-outline",
        backgroundIcon: "star",
      };

    case "spending":
      return {
        label: "مصروف ذكي",
        detailLabel: "النوع",
        icon: "card-outline",
        backgroundIcon: "sparkles",
      };
  }
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#F7F7FA",
  },

  loadingScreen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  loadingText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 16,
    color: "#6D6F7D",
  },

  headerGradient: {
    paddingBottom: 72,
    overflow: "hidden",
  },

  headerDecorationOne: {
    position: "absolute",
    left: -42,
    bottom: -35,
    transform: [{ rotate: "-12deg" }],
  },

  headerDecorationTwo: {
    position: "absolute",
    right: -15,
    top: 28,
    transform: [{ rotate: "15deg" }],
  },

  sparkOne: {
    position: "absolute",
    left: width * 0.22,
    top: 58,
  },

  sparkTwo: {
    position: "absolute",
    right: width * 0.28,
    bottom: 40,
  },

  headerTopRow: {
    paddingHorizontal: 20,
    paddingTop: 12,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },

  headerIconButton: {
    width: 46,
    height: 46,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.16)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.23)",
  },

  buttonPressed: {
    opacity: 0.75,
    transform: [{ scale: 0.96 }],
  },

  notificationBadge: {
    position: "absolute",
    top: -3,
    right: -3,
    minWidth: 19,
    height: 19,
    paddingHorizontal: 4,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  notificationBadgeText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 11,
    color: "#FF315F",
  },

  headerTitleArea: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 10,
  },

  headerTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 31,
    color: "#FFFFFF",
    textAlign: "center",
    writingDirection: "rtl",
  },

  headerSubtitle: {
    marginTop: 4,
    fontFamily: "Tajawal_500Medium",
    fontSize: 15,
    lineHeight: 22,
    color: "rgba(255,255,255,0.90)",
    textAlign: "center",
    writingDirection: "rtl",
  },

  headerSummaryRow: {
    marginTop: 30,
    paddingHorizontal: 20,
    flexDirection: "row",
    gap: 12,
  },

  summaryCard: {
    flex: 1,
    minHeight: 74,
    borderRadius: 22,
    paddingHorizontal: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    backgroundColor: "rgba(144,0,35,0.20)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.18)",
  },

  summaryIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },

  summaryNumber: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 22,
    color: "#FFFFFF",
    textAlign: "right",
  },

  summaryLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "rgba(255,255,255,0.87)",
    textAlign: "right",
    writingDirection: "rtl",
  },

  createChallengeButton: {
    flex: 1.22,
    minHeight: 74,
    borderRadius: 22,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: "#FFFFFF",
    shadowColor: "#9E1439",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.18,
    shadowRadius: 14,
    elevation: 7,
  },

  createButtonPressed: {
    transform: [{ scale: 0.97 }],
  },

  createChallengeText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#FF315F",
    writingDirection: "rtl",
  },

  contentSheet: {
    flex: 1,
    marginTop: -42,
    borderTopLeftRadius: 35,
    borderTopRightRadius: 35,
    backgroundColor: "#F7F7FA",
    overflow: "hidden",
  },

  scrollContent: {
    paddingTop: 23,
    paddingBottom: 130,
  },

  filtersContainer: {
    paddingHorizontal: 18,
    gap: 9,
  },

  filterButton: {
    minHeight: 44,
    paddingHorizontal: 16,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#ECECF2",
  },

  selectedFilterButton: {
    backgroundColor: "#FF3D63",
    borderColor: "#FF3D63",
    shadowColor: "#FF3D63",
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.22,
    shadowRadius: 9,
    elevation: 4,
  },

  filterPressed: {
    opacity: 0.78,
  },

  filterText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: "#777A8D",
  },

  selectedFilterText: {
    color: "#FFFFFF",
  },

  filterCount: {
    minWidth: 21,
    height: 21,
    paddingHorizontal: 5,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFE5EB",
  },

  selectedFilterCount: {
    backgroundColor: "#FFFFFF",
  },

  filterCountText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 11,
    color: "#FF3D63",
  },

  selectedFilterCountText: {
    color: "#FF3D63",
  },

  sectionHeader: {
    marginTop: 25,
    marginBottom: 13,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  sortButton: {
    minHeight: 39,
    paddingHorizontal: 12,
    borderRadius: 13,
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EAEAF0",
  },

  sortText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "#717487",
  },

  sectionTitleArea: {
    alignItems: "flex-end",
  },

  sectionTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 22,
    color: "#202234",
    textAlign: "right",
    writingDirection: "rtl",
  },

  sectionCount: {
    marginTop: 2,
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "#9698A7",
    textAlign: "right",
  },

  challengeCard: {
    marginHorizontal: 18,
    marginBottom: 19,
    borderRadius: 29,
    backgroundColor: "#FFFFFF",
    shadowColor: "#313344",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.10,
    shadowRadius: 18,
    elevation: 7,
    overflow: "hidden",
  },

  challengeCardPressed: {
    opacity: 0.95,
    transform: [{ scale: 0.985 }],
  },

  challengeBanner: {
    minHeight: 280,
    padding: 18,
    overflow: "hidden",
  },

  cardFlameOne: {
    position: "absolute",
    left: -20,
    bottom: -16,
    transform: [{ rotate: "-12deg" }],
  },

  cardFlameTwo: {
    position: "absolute",
    right: -5,
    top: 35,
    transform: [{ rotate: "14deg" }],
  },

  cardTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  statusBadge: {
    minHeight: 32,
    paddingHorizontal: 11,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },

  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },

  statusText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
  },

  challengeTypeBadge: {
    minHeight: 32,
    paddingHorizontal: 11,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(105,0,31,0.20)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.17)",
  },

  challengeTypeText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: "#FFFFFF",
  },

  challengeTitleArea: {
    marginTop: 16,
    alignItems: "center",
  },

  challengeTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 25,
    color: "#FFFFFF",
    textAlign: "center",
    writingDirection: "rtl",
  },

  challengeSubtitle: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    color: "rgba(255,255,255,0.88)",
    textAlign: "center",
    writingDirection: "rtl",
  },

  competitorsRow: {
    marginTop: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
  },

  competitor: {
    width: "35%",
    alignItems: "center",
  },

  avatarOuter: {
    width: 74,
    height: 74,
    borderRadius: 37,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.23)",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },

  avatarInner: {
    width: 62,
    height: 62,
    borderRadius: 31,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF2EA",
    overflow: "hidden",
  },

  avatarEmoji: {
    fontSize: 39,
  },

  competitorName: {
    marginTop: 7,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 17,
    color: "#FFFFFF",
  },

  competitorProgressBadge: {
    marginTop: 4,
    minWidth: 59,
    height: 29,
    paddingHorizontal: 10,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(128,0,35,0.23)",
  },

  competitorProgressText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#FFFFFF",
  },

  vsArea: {
    width: "20%",
    alignItems: "center",
  },

  vsCircle: {
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    shadowColor: "#A0002D",
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.20,
    shadowRadius: 9,
    elevation: 6,
  },

  vsText: {
    marginTop: -3,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: "#FF405F",
  },

  challengeBottom: {
    padding: 16,
  },

  challengeMetaRow: {
    minHeight: 82,
    flexDirection: "row",
    alignItems: "center",
  },

  metaItem: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 4,
  },

  metaLabel: {
    marginTop: 3,
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "#999BA8",
  },

  metaValue: {
    marginTop: 2,
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: "#303243",
    textAlign: "center",
    writingDirection: "rtl",
  },

  metaDivider: {
    width: 1,
    height: 43,
    backgroundColor: "#ECECF1",
  },

  progressSummary: {
    marginTop: 8,
    minHeight: 54,
    paddingHorizontal: 13,
    borderRadius: 17,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },

  progressSummaryText: {
    flex: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    lineHeight: 18,
    color: "#646677",
    textAlign: "right",
    writingDirection: "rtl",
  },

  openChallengeButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
  },

  openChallengeText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
  },

  bottomCreateButton: {
    marginTop: 5,
    marginHorizontal: 18,
    borderRadius: 21,
    overflow: "hidden",
    shadowColor: "#FF3B5F",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowOpacity: 0.23,
    shadowRadius: 12,
    elevation: 6,
  },

  bottomButtonPressed: {
    opacity: 0.88,
    transform: [{ scale: 0.985 }],
  },

  bottomCreateGradient: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
  },

  bottomCreateText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 17,
    color: "#FFFFFF",
    writingDirection: "rtl",
  },

  emptyContainer: {
    marginHorizontal: 18,
    paddingVertical: 38,
    paddingHorizontal: 25,
    borderRadius: 28,
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    shadowColor: "#282A38",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 5,
  },

  emptyIcon: {
    width: 84,
    height: 84,
    borderRadius: 27,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF0F3",
  },

  emptyTitle: {
    marginTop: 17,
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 20,
    color: "#262838",
  },

  emptyDescription: {
    marginTop: 5,
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    lineHeight: 21,
    color: "#898B99",
    textAlign: "center",
    writingDirection: "rtl",
  },

  emptyCreateButton: {
    marginTop: 18,
    minHeight: 47,
    paddingHorizontal: 22,
    borderRadius: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    backgroundColor: "#FF4264",
  },

  emptyCreateText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "#FFFFFF",
  },
});