import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Image,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as ImagePicker from "expo-image-picker";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const PALETTE = {
  background: "#FFFFFF",
  surface: "#FFFFFF",
  ink: "#1D2D44",
  muted: "#7D8796",
  navy: "#2ea7c5",
  familyStart: "#ffcefb",
  familyEnd: "#F7E7EF",
  familyInk: "#284A57",
  familyMuted: "#6F8790",
  coral: "#FF8F70",
  coralSoft: "#FFE0D4",
  turquoise: "#2AB7A9",
  turquoiseSoft: "#DDF7F3",
  sky: "#6EC8F0",
  skySoft: "#E4F6FF",
  lemon: "#FFD76A",
  lemonSoft: "#FFF3C9",
  lilac: "#A79BEA",
  lilacSoft: "#EEEAFE",
  rose: "#F7B2C4",
  roseSoft: "#FFE8EF",
  border: "#F0E6DE",
  shadow: "#5C493D",
};

type Child = {
  id: number;
  name: string;
  age: number;
  username: string;
  image?: string;
  emoji: string;
  points: number;
  completedTasks: number;
  totalTasks: number;
  savings: number;
  savingGoal: number;
  weeklyActivity: number[];
  accent: string;
  softAccent: string;
};

const initialChildren: Child[] = [
  {
    id: 1,
    name: "سارة",
    age: 10,
    username: "sara_wasad",
    emoji: "👧🏻",
    points: 860,
    completedTasks: 6,
    totalTasks: 8,
    savings: 240,
    savingGoal: 400,
    weeklyActivity: [42, 70, 55, 86, 62, 90, 74],
    accent: PALETTE.coral,
    softAccent: PALETTE.coralSoft,
  },
  {
    id: 2,
    name: "عبدالله",
    age: 8,
    username: "abdullah_wasad",
    emoji: "👦🏻",
    points: 540,
    completedTasks: 4,
    totalTasks: 7,
    savings: 120,
    savingGoal: 300,
    weeklyActivity: [35, 50, 42, 65, 48, 72, 60],
    accent: PALETTE.turquoise,
    softAccent: PALETTE.turquoiseSoft,
  },
  {
    id: 3,
    name: "نورة",
    age: 7,
    username: "noura_wasad",
    emoji: "🧒🏻",
    points: 320,
    completedTasks: 3,
    totalTasks: 6,
    savings: 80,
    savingGoal: 250,
    weeklyActivity: [25, 48, 33, 58, 49, 65, 55],
    accent: PALETTE.sky,
    softAccent: PALETTE.skySoft,
  },
];

export default function ChildrenScreen() {
  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  const [children, setChildren] = useState<Child[]>(initialChildren);
  const [selectedChild, setSelectedChild] = useState(initialChildren[0]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  const [childName, setChildName] = useState("");
  const [childAge, setChildAge] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [newChildImage, setNewChildImage] = useState<string | undefined>();

  const enter = useRef(new Animated.Value(0)).current;
  const float = useRef(new Animated.Value(0)).current;
  const profileScale = useRef(new Animated.Value(1)).current;
  const addPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.timing(enter, {
      toValue: 1,
      duration: 650,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(float, {
          toValue: 1,
          duration: 3200,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(float, {
          toValue: 0,
          duration: 3200,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(addPulse, {
          toValue: 1.045,
          duration: 900,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(addPulse, {
          toValue: 1,
          duration: 900,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, [addPulse, enter, float]);

  const taskProgress = useMemo(() => {
    if (!selectedChild.totalTasks) return 0;
    return Math.round(
      (selectedChild.completedTasks / selectedChild.totalTasks) * 100,
    );
  }, [selectedChild]);

  const savingsProgress = useMemo(() => {
    if (!selectedChild.savingGoal) return 0;
    return Math.min(
      100,
      Math.round((selectedChild.savings / selectedChild.savingGoal) * 100),
    );
  }, [selectedChild]);

  const pickImage = async (mode: "new" | "selected") => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) return;

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });

    if (result.canceled) return;

    const uri = result.assets[0].uri;

    if (mode === "new") {
      setNewChildImage(uri);
      return;
    }

    const updated = { ...selectedChild, image: uri };
    setSelectedChild(updated);
    setChildren((current) =>
      current.map((child) => (child.id === updated.id ? updated : child)),
    );
  };

  const selectChild = (child: Child) => {
    Animated.sequence([
      Animated.timing(profileScale, {
        toValue: 0.97,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.spring(profileScale, {
        toValue: 1,
        friction: 5,
        tension: 90,
        useNativeDriver: true,
      }),
    ]).start();

    setSelectedChild(child);
  };

  const addChild = () => {
    if (
      !childName.trim() ||
      !childAge.trim() ||
      !username.trim() ||
      !password.trim()
    ) {
      return;
    }

    const accents = [
      [PALETTE.rose, PALETTE.roseSoft],
      [PALETTE.sky, PALETTE.skySoft],
      [PALETTE.lemon, PALETTE.lemonSoft],
      [PALETTE.lilac, PALETTE.lilacSoft],
    ];
    const [accent, softAccent] = accents[children.length % accents.length];

    const child: Child = {
      id: Date.now(),
      name: childName.trim(),
      age: Number(childAge) || 7,
      username: username.trim(),
      image: newChildImage,
      emoji: "🧒🏻",
      points: 0,
      completedTasks: 0,
      totalTasks: 0,
      savings: 0,
      savingGoal: 300,
      weeklyActivity: [10, 18, 22, 28, 25, 35, 30],
      accent,
      softAccent,
    };

    setChildren((current) => [...current, child]);
    setSelectedChild(child);
    setChildName("");
    setChildAge("");
    setUsername("");
    setPassword("");
    setNewChildImage(undefined);
    setShowAddModal(false);
  };

  if (!fontsLoaded) {
    return <View style={{ flex: 1, backgroundColor: PALETTE.background }} />;
  }

  const floatingY = float.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -10],
  });

  const entranceY = enter.interpolate({
    inputRange: [0, 1],
    outputRange: [24, 0],
  });

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor={PALETTE.background} />

      <View style={styles.backgroundShapes} pointerEvents="none">
        <Animated.View
          style={[styles.sunBlob, { transform: [{ translateY: floatingY }] }]}
        />
        <View style={styles.aquaBlob} />
        <View style={styles.coralDot} />
      </View>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        style={{
          opacity: enter,
          transform: [{ translateY: entranceY }],
        }}
      >
        <View style={styles.header}>
          <TouchableOpacity style={styles.notificationButton}>
            <Ionicons
              name="notifications-outline"
              size={25}
              color={PALETTE.ink}
            />
            <View style={styles.notificationDot} />
          </TouchableOpacity>

          <View style={styles.headerCopy}>
            <Text style={styles.pageTitle}>أطفالي</Text>
            <Text style={styles.pageSubtitle}>
              تابعي إنجازاتهم ونموهم المالي
            </Text>
          </View>
        </View>

        <Animated.View
          style={[
            styles.familyPanelShadow,
            { transform: [{ scale: profileScale }] },
          ]}
        >
          <LinearGradient
            colors={[PALETTE.familyStart, PALETTE.familyEnd]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.familyPanel}
          >
            <View style={styles.panelBubbleOne} />
            <View style={styles.panelBubbleTwo} />

            <View style={styles.familyPanelHeader}>
              <TouchableOpacity
                style={styles.panelMenu}
                onPress={() => setShowEditModal(true)}
              >
                <Ionicons
                  name="ellipsis-horizontal"
                  size={24}
                  color={PALETTE.familyInk}
                />
              </TouchableOpacity>

              <View>
                <Text style={styles.familyPanelTitle}>أفراد العائلة</Text>
                <Text style={styles.familyPanelSubtitle}>
                  اختاري طفلاً لعرض تفاصيله
                </Text>
              </View>
            </View>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.familyMembers}
            >
              <Animated.View
                style={[
                  styles.addMemberAnimated,
                  { transform: [{ scale: addPulse }] },
                ]}
              >
                <TouchableOpacity
                  activeOpacity={0.88}
                  style={styles.addMemberCard}
                  onPress={() => setShowAddModal(true)}
                >
                  <LinearGradient
                    colors={["#d0d0d0", "#888888"]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.addMemberPlus}
                  >
                    <Ionicons name="add" size={27} color="#FFFFFF" />
                  </LinearGradient>
                  <Text style={styles.addMemberTitle}>إضافة طفل</Text>
                  <Text style={styles.addMemberSubtitle}>حساب جديد</Text>
                </TouchableOpacity>
              </Animated.View>

              {children.map((child) => {
                const active = selectedChild.id === child.id;
                return (
                  <TouchableOpacity
                    key={child.id}
                    activeOpacity={0.86}
                    style={styles.memberItem}
                    onPress={() => selectChild(child)}
                  >
                    <View
                      style={[
                        styles.memberAvatarFrame,
                        active && {
                          borderColor: child.accent,
                          backgroundColor: child.softAccent,
                        },
                      ]}
                    >
                      <Avatar child={child} size={56} radius={17} />
                    </View>
                    <Text
                      numberOfLines={1}
                      style={[
                        styles.memberName,
                        active && styles.memberNameActive,
                      ]}
                    >
                      {child.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            <View style={styles.profileCard}>
              <View style={styles.profileTopRow}>
                <View style={styles.profileActions}>
                  <TouchableOpacity
                    style={styles.whiteIconButton}
                    onPress={() => pickImage("selected")}
                  >
                    <Ionicons
                      name="camera-outline"
                      size={22}
                      color={PALETTE.navy}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.whiteIconButton}
                    onPress={() => setShowEditModal(true)}
                  >
                    <Ionicons
                      name="create-outline"
                      size={22}
                      color={PALETTE.navy}
                    />
                  </TouchableOpacity>
                </View>

                <View style={styles.profileIdentity}>
                  <View style={styles.profileTextBox}>
                    <Text style={styles.profileName}>{selectedChild.name}</Text>
                    <Text style={styles.profileUsername}>
                      @{selectedChild.username}
                    </Text>
                    <View style={styles.levelPill}>
                      <Text style={styles.levelPillText}>مستكشف مالي</Text>
                      <Ionicons
                        name="sparkles"
                        size={14}
                        color={PALETTE.coral}
                      />
                    </View>
                  </View>
                  <View style={styles.largeAvatarWrap}>
                    <Avatar child={selectedChild} size={78} radius={24} />
                    <TouchableOpacity
                      style={styles.cameraBadge}
                      onPress={() => pickImage("selected")}
                    >
                      <Ionicons name="camera" size={16} color="#FFFFFF" />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>

              <View style={styles.statsRow}>
                <StatBox
                  icon="star"
                  value={`${selectedChild.points}`}
                  label="نقطة"
                  background={PALETTE.lemonSoft}
                  iconColor="#D19B00"
                />
                <StatBox
                  icon="checkmark-circle"
                  value={`${selectedChild.completedTasks}`}
                  label="مهمة"
                  background={PALETTE.turquoiseSoft}
                  iconColor={PALETTE.turquoise}
                />
                <StatBox
                  icon="wallet"
                  value={`${selectedChild.savings}`}
                  label="ريال"
                  background={PALETTE.skySoft}
                  iconColor="#299BCF"
                />
              </View>
            </View>
          </LinearGradient>
        </Animated.View>

        <View style={styles.sectionHeader}>
          <TouchableOpacity>
            <Text style={styles.sectionLink}>عرض الكل</Text>
          </TouchableOpacity>
          <View>
            <Text style={styles.sectionTitle}>نشاط الطفل</Text>
            <Text style={styles.sectionSubtitle}>
              آخر الإنجازات والحركات على الحساب
            </Text>
          </View>
        </View>

        <View style={styles.activityTimelineCard}>
          <ActivityTimelineItem
            icon="checkmark-done-outline"
            title="أنجز مهمة ترتيب الغرفة"
            subtitle="تم إرسال المهمة للموافقة"
            time="منذ 35 دقيقة"
            background={PALETTE.turquoiseSoft}
            color={PALETTE.turquoise}
            last={false}
          />
          <ActivityTimelineItem
            icon="wallet-outline"
            title="أضاف 20 ريال إلى هدفه"
            subtitle="هدف شراء دراجة جديدة"
            time="أمس، 6:20 م"
            background={PALETTE.skySoft}
            color="#3197C5"
            last={false}
          />
          <ActivityTimelineItem
            icon="book-outline"
            title="أنهى قصة مالية قصيرة"
            subtitle="تعلم الفرق بين الحاجة والرغبة"
            time="منذ يومين"
            background={PALETTE.coralSoft}
            color={PALETTE.coral}
            last
          />
        </View>

        <View style={styles.sectionHeader}>
          <TouchableOpacity>
            <Text style={styles.sectionLink}>تفاصيل الادخار</Text>
          </TouchableOpacity>
          <View>
            <Text style={styles.sectionTitle}>ادخارات الطفل</Text>
            <Text style={styles.sectionSubtitle}>
              الهدف الحالي وحركة المبالغ
            </Text>
          </View>
        </View>

        <LinearGradient
          colors={["#DDF7F3", "#F2FFFB"]}
          style={styles.savingsOverviewCard}
        >
          <View style={styles.savingsDecorOne} />
          <View style={styles.savingsTopRow}>
            <View style={styles.savingsPercentBadge}>
              <Text style={styles.savingsPercentText}>{savingsProgress}%</Text>
            </View>
            <View style={styles.savingsHeadingWrap}>
              <Text style={styles.savingsGoalLabel}>الهدف الحالي</Text>
              <Text style={styles.savingsGoalTitle}>دراجة جديدة 🚲</Text>
            </View>
          </View>

          <View style={styles.savingsAmountRow}>
            <View style={styles.savingsAmountBox}>
              <Text style={styles.savingsAmountLabel}>المتبقي</Text>
              <Text style={styles.savingsAmountValue}>
                {Math.max(selectedChild.savingGoal - selectedChild.savings, 0)}{" "}
                ريال
              </Text>
            </View>
            <View style={styles.savingsAmountDivider} />
            <View style={styles.savingsAmountBox}>
              <Text style={styles.savingsAmountLabel}>تم ادخاره</Text>
              <Text style={styles.savingsAmountValue}>
                {selectedChild.savings} ريال
              </Text>
            </View>
          </View>

          <View style={styles.savingsTrack}>
            <View
              style={[styles.savingsFill, { width: `${savingsProgress}%` }]}
            />
          </View>

          <View style={styles.savingsTransactions}>
            <SavingsEntry
              label="مكافأة إكمال مهمة"
              amount="+30 ر.س"
              date="اليوم"
            />
            <SavingsEntry
              label="إضافة من المصروف"
              amount="+20 ر.س"
              date="أمس"
            />
            <SavingsEntry
              label="شراء ملصقات"
              amount="-8 ر.س"
              date="السبت"
              last
            />
          </View>
        </LinearGradient>

        <View style={styles.sectionHeader}>
          <TouchableOpacity>
            <Text style={styles.sectionLink}>التفاصيل</Text>
          </TouchableOpacity>
          <View>
            <Text style={styles.sectionTitle}>ملخص الأسبوع</Text>
            <Text style={styles.sectionSubtitle}>
              المهام ومستوى الالتزام اليومي
            </Text>
          </View>
        </View>

        <View style={styles.progressGrid}>
          <ProgressCard
            title="إنجاز المهام"
            subtitle={`${selectedChild.completedTasks} من ${selectedChild.totalTasks} مهام`}
            progress={taskProgress}
            icon="checkbox-outline"
            accent={PALETTE.coral}
            soft={PALETTE.coralSoft}
          />
          <ProgressCard
            title="هدف الادخار"
            subtitle={`${selectedChild.savings} من ${selectedChild.savingGoal} ريال`}
            progress={savingsProgress}
            icon="wallet-outline"
            accent={PALETTE.turquoise}
            soft={PALETTE.turquoiseSoft}
          />
        </View>

        <View style={styles.chartCard}>
          <View style={styles.chartSummary}>
            <View style={styles.chartBadge}>
              <Ionicons
                name="trending-up"
                size={20}
                color={PALETTE.turquoise}
              />
              <Text style={styles.chartBadgeText}>+18%</Text>
            </View>
            <Text style={styles.chartHeading}>أسبوع رائع!</Text>
          </View>

          <View style={styles.chartBars}>
            {selectedChild.weeklyActivity.map((value, index) => {
              const days = ["ح", "ن", "ث", "ر", "خ", "ج", "س"];
              return (
                <View key={`${value}-${index}`} style={styles.chartColumn}>
                  <View style={styles.chartTrack}>
                    <View
                      style={[
                        styles.chartFill,
                        {
                          height: `${value}%`,
                          backgroundColor:
                            index === 5
                              ? selectedChild.accent
                              : selectedChild.softAccent,
                        },
                      ]}
                    />
                  </View>
                  <Text style={styles.chartDay}>{days[index]}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <Text style={styles.managementTitle}>إدارة حساب الطفل</Text>
        <View style={styles.managementGrid}>
          <ManagementCard
            title="إضافة مهمة"
            subtitle="مهمة ومكافأة جديدة"
            icon="add-circle-outline"
            background={PALETTE.coralSoft}
            color={PALETTE.coral}
          />
          <ManagementCard
            title="المصروف"
            subtitle="تحديد مبلغ دوري"
            icon="cash-outline"
            background={PALETTE.turquoiseSoft}
            color={PALETTE.turquoise}
          />
          <ManagementCard
            title="تعديل الحساب"
            subtitle="الصورة والبيانات"
            icon="create-outline"
            background={PALETTE.skySoft}
            color="#3197C5"
            onPress={() => setShowEditModal(true)}
          />
          <ManagementCard
            title="التقارير"
            subtitle="الإنجاز والتطور"
            icon="stats-chart-outline"
            background={PALETTE.lemonSoft}
            color="#C89911"
          />
        </View>
      </Animated.ScrollView>

      <Modal
        visible={showAddModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAddModal(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowAddModal(false)}
        >
          <Pressable
            style={styles.modalSheet}
            onPress={(event) => event.stopPropagation()}
          >
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.modalClose}
                onPress={() => setShowAddModal(false)}
              >
                <Ionicons name="close" size={24} color={PALETTE.ink} />
              </TouchableOpacity>
              <View>
                <Text style={styles.modalTitle}>إضافة طفل جديد</Text>
                <Text style={styles.modalSubtitle}>
                  أنشئي حسابًا خاصًا لطفلك
                </Text>
              </View>
            </View>

            <TouchableOpacity
              activeOpacity={0.85}
              style={styles.modalAvatarArea}
              onPress={() => pickImage("new")}
            >
              {newChildImage ? (
                <Image
                  source={{ uri: newChildImage }}
                  style={styles.modalAvatarImage}
                />
              ) : (
                <LinearGradient
                  colors={[PALETTE.coralSoft, PALETTE.lemonSoft]}
                  style={styles.modalAvatarPlaceholder}
                >
                  <Ionicons name="person" size={40} color={PALETTE.coral} />
                </LinearGradient>
              )}
              <View style={styles.modalCameraBadge}>
                <Ionicons name="camera" size={18} color="#FFFFFF" />
              </View>
            </TouchableOpacity>
            <Text style={styles.choosePhotoText}>اضغطي لاختيار صورة</Text>

            <View style={styles.inputRow}>
              <View style={styles.halfInput}>
                <InputField
                  label="العمر"
                  placeholder="10"
                  value={childAge}
                  onChangeText={setChildAge}
                  icon="calendar-outline"
                  keyboardType="number-pad"
                />
              </View>
              <View style={styles.halfInput}>
                <InputField
                  label="اسم الطفل"
                  placeholder="سارة"
                  value={childName}
                  onChangeText={setChildName}
                  icon="person-outline"
                />
              </View>
            </View>

            <InputField
              label="اسم المستخدم"
              placeholder="sara_wasad"
              value={username}
              onChangeText={setUsername}
              icon="at-outline"
              autoCapitalize="none"
            />
            <InputField
              label="كلمة المرور"
              placeholder="كلمة مرور آمنة"
              value={password}
              onChangeText={setPassword}
              icon="lock-closed-outline"
              secureTextEntry
            />

            <TouchableOpacity activeOpacity={0.88} onPress={addChild}>
              <LinearGradient
                colors={[PALETTE.coral, "#FF7759"]}
                style={styles.createButton}
              >
                <Ionicons name="person-add" size={22} color="#FFFFFF" />
                <Text style={styles.createButtonText}>إنشاء حساب الطفل</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal
        visible={showEditModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowEditModal(false)}
      >
        <Pressable
          style={styles.centerOverlay}
          onPress={() => setShowEditModal(false)}
        >
          <Pressable
            style={styles.editModal}
            onPress={(event) => event.stopPropagation()}
          >
            <TouchableOpacity
              style={styles.modalClose}
              onPress={() => setShowEditModal(false)}
            >
              <Ionicons name="close" size={24} color={PALETTE.ink} />
            </TouchableOpacity>

            <Avatar child={selectedChild} size={100} radius={30} />
            <Text style={styles.editName}>{selectedChild.name}</Text>
            <Text style={styles.editUsername}>@{selectedChild.username}</Text>

            <TouchableOpacity
              style={styles.outlineAction}
              onPress={() => pickImage("selected")}
            >
              <Ionicons name="camera-outline" size={21} color={PALETTE.coral} />
              <Text style={styles.outlineActionText}>تغيير صورة الطفل</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.solidAction}>
              <Ionicons name="create-outline" size={21} color="#FFFFFF" />
              <Text style={styles.solidActionText}>تعديل بيانات الحساب</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

function Avatar({
  child,
  size,
  radius,
}: {
  child: Child;
  size: number;
  radius: number;
}) {
  return child.image ? (
    <Image
      source={{ uri: child.image }}
      style={{ width: size, height: size, borderRadius: radius }}
    />
  ) : (
    <LinearGradient
      colors={[child.softAccent, "#FFFFFF"]}
      style={{
        width: size,
        height: size,
        borderRadius: radius,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Text style={{ fontSize: size * 0.5 }}>{child.emoji}</Text>
    </LinearGradient>
  );
}

function StatBox({
  icon,
  value,
  label,
  background,
  iconColor,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  value: string;
  label: string;
  background: string;
  iconColor: string;
}) {
  return (
    <View style={[styles.statBox, { backgroundColor: background }]}>
      <Ionicons name={icon} size={22} color={iconColor} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function ProgressCard({
  title,
  subtitle,
  progress,
  icon,
  accent,
  soft,
}: {
  title: string;
  subtitle: string;
  progress: number;
  icon: keyof typeof Ionicons.glyphMap;
  accent: string;
  soft: string;
}) {
  return (
    <View style={[styles.progressCard, { backgroundColor: soft }]}>
      <View style={styles.progressTopRow}>
        <View style={[styles.progressCircle, { borderColor: accent }]}>
          <Text style={[styles.progressNumber, { color: accent }]}>
            {progress}%
          </Text>
        </View>
        <View style={styles.progressIconWrap}>
          <Ionicons name={icon} size={24} color={accent} />
        </View>
      </View>
      <Text style={styles.progressTitle}>{title}</Text>
      <Text style={styles.progressSubtitle}>{subtitle}</Text>
      <View style={styles.progressTrackLine}>
        <View
          style={[
            styles.progressFillLine,
            { width: `${progress}%`, backgroundColor: accent },
          ]}
        />
      </View>
    </View>
  );
}

function ActivityTimelineItem({
  icon,
  title,
  subtitle,
  time,
  background,
  color,
  last = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  time: string;
  background: string;
  color: string;
  last?: boolean;
}) {
  return (
    <View
      style={[
        styles.activityTimelineItem,
        last && styles.activityTimelineItemLast,
      ]}
    >
      <Text style={styles.activityTimelineTime}>{time}</Text>
      <View style={styles.activityTimelineMain}>
        <View style={styles.activityTimelineCopy}>
          <Text style={styles.activityTimelineTitle}>{title}</Text>
          <Text style={styles.activityTimelineSubtitle}>{subtitle}</Text>
        </View>
        <View
          style={[styles.activityTimelineIcon, { backgroundColor: background }]}
        >
          <Ionicons name={icon} size={23} color={color} />
        </View>
      </View>
    </View>
  );
}

function SavingsEntry({
  label,
  amount,
  date,
  last = false,
}: {
  label: string;
  amount: string;
  date: string;
  last?: boolean;
}) {
  const positive = amount.trim().startsWith("+");
  return (
    <View style={[styles.savingsEntry, last && styles.savingsEntryLast]}>
      <View style={styles.savingsEntryAmountWrap}>
        <Text
          style={[
            styles.savingsEntryAmount,
            { color: positive ? PALETTE.turquoise : PALETTE.coral },
          ]}
        >
          {amount}
        </Text>
        <Text style={styles.savingsEntryDate}>{date}</Text>
      </View>
      <View style={styles.savingsEntryLabelWrap}>
        <Text style={styles.savingsEntryLabel}>{label}</Text>
        <View
          style={[
            styles.savingsEntryDot,
            { backgroundColor: positive ? PALETTE.turquoise : PALETTE.coral },
          ]}
        />
      </View>
    </View>
  );
}

function ManagementCard({
  title,
  subtitle,
  icon,
  background,
  color,
  onPress,
}: {
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
  background: string;
  color: string;
  onPress?: () => void;
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.85}
      style={[styles.managementCard, { backgroundColor: background }]}
      onPress={onPress}
    >
      <View style={styles.managementIconWrap}>
        <Ionicons name={icon} size={25} color={color} />
      </View>
      <Text style={styles.managementCardTitle}>{title}</Text>
      <Text style={styles.managementCardSubtitle}>{subtitle}</Text>
      <View style={[styles.managementArrow, { backgroundColor: color }]}>
        <Ionicons name="arrow-back" size={17} color="#FFFFFF" />
      </View>
    </TouchableOpacity>
  );
}

function InputField({
  label,
  placeholder,
  value,
  onChangeText,
  icon,
  keyboardType = "default",
  secureTextEntry = false,
  autoCapitalize = "sentences",
}: {
  label: string;
  placeholder: string;
  value: string;
  onChangeText: (value: string) => void;
  icon: keyof typeof Ionicons.glyphMap;
  keyboardType?: "default" | "number-pad";
  secureTextEntry?: boolean;
  autoCapitalize?: "none" | "sentences" | "words" | "characters";
}) {
  return (
    <View style={styles.inputGroup}>
      <Text style={styles.inputLabel}>{label}</Text>
      <View style={styles.inputContainer}>
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#A9A3A0"
          keyboardType={keyboardType}
          secureTextEntry={secureTextEntry}
          autoCapitalize={autoCapitalize}
          textAlign="right"
          style={styles.textInput}
        />
        <Ionicons name={icon} size={21} color={PALETTE.muted} />
      </View>
    </View>
  );
}

const font = {
  regular: "Tajawal_400Regular",
  medium: "Tajawal_500Medium",
  bold: "Tajawal_700Bold",
  extraBold: "Tajawal_800ExtraBold",
  black: "Tajawal_900Black",
};

const shadow = {
  shadowColor: PALETTE.shadow,
  shadowOpacity: Platform.OS === "ios" ? 0.13 : 0.2,
  shadowRadius: 16,
  shadowOffset: { width: 0, height: 8 },
  elevation: 6,
};

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: PALETTE.background },
  backgroundShapes: { ...StyleSheet.absoluteFill, overflow: "hidden" },
  sunBlob: {
    position: "absolute",
    width: 210,
    height: 210,
    borderRadius: 105,
    backgroundColor: "rgba(255, 215, 106, 0.22)",
    top: -90,
    left: -70,
  },
  aquaBlob: {
    position: "absolute",
    width: 190,
    height: 190,
    borderRadius: 95,
    backgroundColor: "rgba(42, 183, 169, 0.11)",
    top: 430,
    right: -100,
  },
  coralDot: {
    position: "absolute",
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: PALETTE.coral,
    top: 26,
    right: 30,
    opacity: 0.75,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 8,
    paddingBottom: 140,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  headerCopy: { alignItems: "flex-end" },
  pageTitle: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 34,
    lineHeight: 43,
  },
  pageSubtitle: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 15,
    marginTop: 2,
  },
  notificationButton: {
    width: 50,
    height: 50,
    borderRadius: 17,
    backgroundColor: PALETTE.surface,
    alignItems: "center",
    justifyContent: "center",
    ...shadow,
  },
  notificationDot: {
    position: "absolute",
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: PALETTE.coral,
    top: 9,
    right: 10,
    borderWidth: 2,
    borderColor: PALETTE.surface,
  },
  familyPanelShadow: {
    marginHorizontal: 0,
    borderRadius: 32,
    shadowColor: "#7B9CA4",
    shadowOpacity: Platform.OS === "ios" ? 0.15 : 0.2,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
    elevation: 7,
  },
  familyPanel: {
    borderRadius: 32,
    paddingHorizontal: 18,
    paddingTop: 22,
    paddingBottom: 24,
    overflow: "hidden",
  },
  panelBubbleOne: {
    position: "absolute",
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(255,255,255,0.42)",
    left: -60,
    top: -75,
  },
  panelBubbleTwo: {
    position: "absolute",
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "rgba(255,255,255,0.34)",
    right: -35,
    bottom: -50,
  },
  familyPanelHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  panelMenu: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: "rgba(255,255,255,0.72)",
    alignItems: "center",
    justifyContent: "center",
  },
  familyPanelTitle: {
    color: PALETTE.familyInk,
    fontFamily: font.black,
    fontSize: 24,
    textAlign: "right",
  },
  familyPanelSubtitle: {
    color: PALETTE.familyMuted,
    fontFamily: font.medium,
    fontSize: 13,
    marginTop: 2,
    textAlign: "right",
  },
  familyMembers: {
    flexDirection: "row",
    gap: 14,
    paddingTop: 18,
    paddingBottom: 16,
    paddingHorizontal: 4,
  },
  memberItem: { width: 65, alignItems: "center" },
  addMemberAnimated: {
    width: 84,
    padding: 4,
  },
  addMemberCard: {
    width: 76,
    minHeight: 94,
    borderRadius: 23,
    backgroundColor: "rgba(255,255,255,0.78)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.95)",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 10,
    shadowColor: "#A36F78",
    shadowOpacity: 0.16,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 5,
  },
  addMemberPlus: {
    width: 46,
    height: 46,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: PALETTE.coral,
    shadowOpacity: 0.28,
    shadowRadius: 9,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },
  addMemberTitle: {
    color: PALETTE.familyInk,
    fontFamily: font.extraBold,
    fontSize: 12,
    marginTop: 7,
    textAlign: "center",
  },
  addMemberSubtitle: {
    color: PALETTE.familyMuted,
    fontFamily: font.medium,
    fontSize: 9,
    marginTop: 1,
    textAlign: "center",
  },
  memberAvatarFrame: {
    width: 62,
    height: 62,
    borderRadius: 20,
    padding: 3,
    borderWidth: 2,
    borderColor: "transparent",
    alignItems: "center",
    justifyContent: "center",
  },
  memberName: {
    color: PALETTE.familyMuted,
    fontFamily: font.bold,
    fontSize: 12,
    marginTop: 7,
    maxWidth: 64,
    textAlign: "center",
  },
  memberNameActive: { color: PALETTE.familyInk },
  profileCard: {
    backgroundColor: PALETTE.surface,
    borderRadius: 25,
    padding: 16,
    marginTop: 2,
  },
  profileTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  profileActions: { flexDirection: "row", gap: 8 },
  whiteIconButton: {
    width: 39,
    height: 39,
    borderRadius: 13,
    backgroundColor: PALETTE.background,
    alignItems: "center",
    justifyContent: "center",
  },
  profileIdentity: { flexDirection: "row", alignItems: "center", gap: 12 },
  profileTextBox: { alignItems: "flex-end" },
  profileName: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 25,
  },
  profileUsername: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 13,
    marginTop: 1,
  },
  levelPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: PALETTE.coralSoft,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 11,
    marginTop: 8,
  },
  levelPillText: {
    color: PALETTE.coral,
    fontFamily: font.bold,
    fontSize: 12,
  },
  largeAvatarWrap: { position: "relative" },
  cameraBadge: {
    position: "absolute",
    left: -4,
    bottom: -3,
    width: 31,
    height: 31,
    borderRadius: 11,
    backgroundColor: PALETTE.coral,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: PALETTE.surface,
  },
  statsRow: { flexDirection: "row", gap: 9, marginTop: 15 },
  statBox: {
    flex: 1,
    minHeight: 94,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  statValue: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 19,
    marginTop: 4,
  },
  statLabel: {
    color: PALETTE.muted,
    fontFamily: font.bold,
    fontSize: 12,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 28,
    marginBottom: 14,
  },
  sectionTitle: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 23,
    textAlign: "right",
  },
  sectionSubtitle: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 13,
    textAlign: "right",
    marginTop: 1,
  },
  sectionLink: {
    color: PALETTE.coral,
    fontFamily: font.bold,
    fontSize: 14,
  },
  activityTimelineCard: {
    backgroundColor: PALETTE.surface,
    borderRadius: 26,
    paddingHorizontal: 16,
    ...shadow,
  },
  activityTimelineItem: {
    minHeight: 88,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: PALETTE.border,
  },
  activityTimelineItemLast: { borderBottomWidth: 0 },
  activityTimelineTime: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 12,
    maxWidth: 76,
  },
  activityTimelineMain: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 12,
  },
  activityTimelineCopy: { flex: 1, alignItems: "flex-end" },
  activityTimelineTitle: {
    color: PALETTE.ink,
    fontFamily: font.extraBold,
    fontSize: 16,
    textAlign: "right",
  },
  activityTimelineSubtitle: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 13,
    marginTop: 4,
    textAlign: "right",
  },
  activityTimelineIcon: {
    width: 49,
    height: 49,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },
  savingsOverviewCard: {
    borderRadius: 28,
    padding: 18,
    overflow: "hidden",
    ...shadow,
  },
  savingsDecorOne: {
    position: "absolute",
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(255,255,255,0.34)",
    left: -55,
    top: -70,
  },
  savingsTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  savingsPercentBadge: {
    width: 64,
    height: 64,
    borderRadius: 22,
    backgroundColor: PALETTE.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 5,
    borderColor: "rgba(42,183,169,0.2)",
  },
  savingsPercentText: {
    color: PALETTE.turquoise,
    fontFamily: font.black,
    fontSize: 17,
  },
  savingsHeadingWrap: { alignItems: "flex-end" },
  savingsGoalLabel: {
    color: PALETTE.muted,
    fontFamily: font.bold,
    fontSize: 13,
  },
  savingsGoalTitle: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 22,
    marginTop: 3,
  },
  savingsAmountRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 20,
    backgroundColor: "rgba(255,255,255,0.65)",
    borderRadius: 20,
    paddingVertical: 13,
  },
  savingsAmountBox: { flex: 1, alignItems: "center" },
  savingsAmountDivider: {
    width: 1,
    height: 42,
    backgroundColor: "rgba(29,45,68,0.10)",
  },
  savingsAmountLabel: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 12,
  },
  savingsAmountValue: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 18,
    marginTop: 3,
  },
  savingsTrack: {
    height: 11,
    borderRadius: 8,
    backgroundColor: "rgba(255,255,255,0.75)",
    overflow: "hidden",
    marginTop: 17,
  },
  savingsFill: {
    height: "100%",
    borderRadius: 8,
    backgroundColor: PALETTE.turquoise,
  },
  savingsTransactions: {
    marginTop: 18,
    backgroundColor: "rgba(255,255,255,0.72)",
    borderRadius: 20,
    paddingHorizontal: 14,
  },
  savingsEntry: {
    minHeight: 66,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "rgba(29,45,68,0.08)",
  },
  savingsEntryLast: { borderBottomWidth: 0 },
  savingsEntryAmountWrap: { alignItems: "flex-start" },
  savingsEntryAmount: { fontFamily: font.black, fontSize: 15 },
  savingsEntryDate: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 11,
    marginTop: 2,
  },
  savingsEntryLabelWrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  savingsEntryLabel: {
    color: PALETTE.ink,
    fontFamily: font.bold,
    fontSize: 14,
  },
  savingsEntryDot: { width: 9, height: 9, borderRadius: 5 },
  progressGrid: { flexDirection: "row", gap: 12 },
  progressCard: {
    flex: 1,
    minHeight: 190,
    borderRadius: 24,
    padding: 15,
    ...shadow,
  },
  progressTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  progressCircle: {
    width: 53,
    height: 53,
    borderRadius: 27,
    borderWidth: 4,
    backgroundColor: "rgba(255,255,255,0.55)",
    alignItems: "center",
    justifyContent: "center",
  },
  progressNumber: { fontFamily: font.black, fontSize: 14 },
  progressIconWrap: {
    width: 43,
    height: 43,
    borderRadius: 15,
    backgroundColor: "rgba(255,255,255,0.58)",
    alignItems: "center",
    justifyContent: "center",
  },
  progressTitle: {
    color: PALETTE.ink,
    fontFamily: font.extraBold,
    fontSize: 18,
    textAlign: "right",
    marginTop: 18,
  },
  progressSubtitle: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 13,
    textAlign: "right",
    marginTop: 3,
  },
  progressTrackLine: {
    height: 9,
    backgroundColor: "rgba(255,255,255,0.66)",
    borderRadius: 6,
    overflow: "hidden",
    marginTop: 18,
  },
  progressFillLine: { height: "100%", borderRadius: 6 },
  chartCard: {
    backgroundColor: PALETTE.surface,
    borderRadius: 26,
    padding: 17,
    ...shadow,
    marginTop: 18,
  },
  chartSummary: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  chartBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: PALETTE.turquoiseSoft,
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  chartBadgeText: {
    color: PALETTE.turquoise,
    fontFamily: font.black,
    fontSize: 13,
  },
  chartHeading: {
    color: PALETTE.ink,
    fontFamily: font.extraBold,
    fontSize: 18,
  },
  chartBars: {
    height: 160,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    marginTop: 18,
  },
  chartColumn: { flex: 1, alignItems: "center" },
  chartTrack: {
    width: 24,
    height: 116,
    borderRadius: 12,
    backgroundColor: "#F4F0EC",
    justifyContent: "flex-end",
    overflow: "hidden",
  },
  chartFill: { width: "100%", borderRadius: 12 },
  chartDay: {
    color: PALETTE.muted,
    fontFamily: font.bold,
    fontSize: 13,
    marginTop: 8,
  },
  managementTitle: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 23,
    textAlign: "right",
    marginTop: 30,
    marginBottom: 14,
  },
  managementGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: 12,
  },
  managementCard: {
    width: "48%",
    minHeight: 165,
    borderRadius: 24,
    padding: 15,
    ...shadow,
  },
  managementIconWrap: {
    width: 45,
    height: 45,
    borderRadius: 15,
    backgroundColor: "rgba(255,255,255,0.62)",
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "flex-end",
  },
  managementCardTitle: {
    color: PALETTE.ink,
    fontFamily: font.extraBold,
    fontSize: 18,
    textAlign: "right",
    marginTop: 14,
  },
  managementCardSubtitle: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 12,
    textAlign: "right",
    marginTop: 2,
  },
  managementArrow: {
    width: 31,
    height: 31,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(18, 34, 48, 0.46)",
    justifyContent: "flex-end",
  },
  modalSheet: {
    maxHeight: "94%",
    backgroundColor: PALETTE.surface,
    borderTopLeftRadius: 34,
    borderTopRightRadius: 34,
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 28,
  },
  modalHandle: {
    width: 50,
    height: 5,
    borderRadius: 3,
    backgroundColor: "#D7D0CA",
    alignSelf: "center",
    marginBottom: 17,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  modalClose: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: PALETTE.background,
    alignItems: "center",
    justifyContent: "center",
  },
  modalTitle: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 24,
    textAlign: "right",
  },
  modalSubtitle: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 13,
    textAlign: "right",
    marginTop: 1,
  },
  modalAvatarArea: {
    width: 96,
    height: 96,
    alignSelf: "center",
    marginTop: 18,
  },
  modalAvatarImage: { width: 96, height: 96, borderRadius: 30 },
  modalAvatarPlaceholder: {
    width: 96,
    height: 96,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  modalCameraBadge: {
    position: "absolute",
    right: -4,
    bottom: -4,
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: PALETTE.coral,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: PALETTE.surface,
  },
  choosePhotoText: {
    color: PALETTE.coral,
    fontFamily: font.bold,
    fontSize: 13,
    textAlign: "center",
    marginTop: 8,
    marginBottom: 16,
  },
  inputRow: { flexDirection: "row", gap: 10 },
  halfInput: { flex: 1 },
  inputGroup: { marginBottom: 13 },
  inputLabel: {
    color: PALETTE.ink,
    fontFamily: font.bold,
    fontSize: 14,
    textAlign: "right",
    marginBottom: 7,
  },
  inputContainer: {
    height: 56,
    borderRadius: 17,
    backgroundColor: PALETTE.background,
    borderWidth: 1,
    borderColor: PALETTE.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
  },
  textInput: {
    flex: 1,
    color: PALETTE.ink,
    fontFamily: font.medium,
    fontSize: 15,
  },
  createButton: {
    height: 58,
    borderRadius: 19,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 5,
    ...shadow,
  },
  createButtonText: {
    color: "#FFFFFF",
    fontFamily: font.extraBold,
    fontSize: 16,
  },
  centerOverlay: {
    flex: 1,
    backgroundColor: "rgba(18, 34, 48, 0.46)",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  editModal: {
    width: "100%",
    backgroundColor: PALETTE.surface,
    borderRadius: 31,
    padding: 22,
    alignItems: "center",
  },
  editName: {
    color: PALETTE.ink,
    fontFamily: font.black,
    fontSize: 26,
    marginTop: 12,
  },
  editUsername: {
    color: PALETTE.muted,
    fontFamily: font.medium,
    fontSize: 14,
    marginTop: 1,
  },
  outlineAction: {
    width: "100%",
    height: 54,
    borderRadius: 17,
    borderWidth: 1.5,
    borderColor: PALETTE.coral,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 20,
  },
  outlineActionText: {
    color: PALETTE.coral,
    fontFamily: font.extraBold,
    fontSize: 15,
  },
  solidAction: {
    width: "100%",
    height: 54,
    borderRadius: 17,
    backgroundColor: PALETTE.navy,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 10,
  },
  solidActionText: {
    color: "#FFFFFF",
    fontFamily: font.extraBold,
    fontSize: 15,
  },
});