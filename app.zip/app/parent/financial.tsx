import React, { useMemo, useState } from "react";
import {
  Dimensions,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const { width } = Dimensions.get("window");

const COLORS = {
  background: "#F7FAFC",
  surface: "#FFFFFF",
  text: "#17243D",
  muted: "#7C8799",

  blue: "#3E7BFA",
  blueDark: "#245FD2",
  blueSoft: "#EAF1FF",

  mint: "#36C7A0",
  mintDark: "#20A986",
  mintSoft: "#E5FAF4",

  coral: "#FF826E",
  coralDark: "#ED6450",
  coralSoft: "#FFF0ED",

  purple: "#8B74F7",
  purpleDark: "#6E57E8",
  purpleSoft: "#F0EDFF",

  gold: "#F4B94A",
  goldSoft: "#FFF6DF",

  border: "#E9EDF4",
};

type Child = {
  id: number;
  name: string;
  avatarColor: string;
  balance: number;
  available: number;
  savings: number;
  invested: number;
};

const CHILDREN: Child[] = [
  {
    id: 1,
    name: "ريم",
    avatarColor: "#FFB5A7",
    balance: 1268,
    available: 620,
    savings: 380,
    invested: 268,
  },
  {
    id: 2,
    name: "سلمان",
    avatarColor: "#9AD7F5",
    balance: 940,
    available: 410,
    savings: 330,
    invested: 200,
  },
  {
    id: 3,
    name: "ليان",
    avatarColor: "#B9E8D2",
    balance: 730,
    available: 350,
    savings: 280,
    invested: 100,
  },
];

export default function FinancialScreen() {
  const router = useRouter();

  const [selectedChildId, setSelectedChildId] = useState(1);

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  const selectedChild = useMemo(
    () =>
      CHILDREN.find((child) => child.id === selectedChildId) ?? CHILDREN[0],
    [selectedChildId]
  );

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  const navigateTo = (screen: string) => {
    router.push(screen as never);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Background Decorations */}
        <View style={styles.topDecorationOne} />
        <View style={styles.topDecorationTwo} />

        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerTextContainer}>
            <Text style={styles.pageTitle}>القسم المالي</Text>
            <Text style={styles.pageSubtitle}>
              تابعي أموال أطفالك وأهدافهم واستثماراتهم
            </Text>
          </View>

          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.notificationButton}
          >
            <Ionicons
              name="notifications-outline"
              size={24}
              color={COLORS.text}
            />

            <View style={styles.notificationDot} />
          </TouchableOpacity>
        </View>

        {/* Children Selector */}
        <View style={styles.childrenSection}>
          <Text style={styles.sectionLabel}>اختاري الطفل</Text>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.childrenList}
          >
            {CHILDREN.map((child) => {
              const selected = child.id === selectedChildId;

              return (
                <TouchableOpacity
                  key={child.id}
                  activeOpacity={0.85}
                  onPress={() => setSelectedChildId(child.id)}
                  style={[
                    styles.childButton,
                    selected && styles.selectedChildButton,
                  ]}
                >
                  <View
                    style={[
                      styles.childAvatar,
                      { backgroundColor: child.avatarColor },
                    ]}
                  >
                    <Text style={styles.childAvatarText}>
                      {child.name.charAt(0)}
                    </Text>
                  </View>

                  <Text
                    style={[
                      styles.childName,
                      selected && styles.selectedChildName,
                    ]}
                  >
                    {child.name}
                  </Text>

                  {selected && (
                    <View style={styles.selectedCheck}>
                      <Ionicons
                        name="checkmark"
                        size={11}
                        color={COLORS.surface}
                      />
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Financial Pulse */}
        <LinearGradient
          colors={["#245FD2", "#3E7BFA", "#65A5FF"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.pulseCard}
        >
          <View style={styles.pulseCircleLarge} />
          <View style={styles.pulseCircleSmall} />

          <View style={styles.pulseHeader}>
            <View style={styles.pulseTitleRow}>
              <View style={styles.pulseIconContainer}>
                <Ionicons name="pulse" size={21} color={COLORS.surface} />
              </View>

              <View>
                <Text style={styles.pulseTitle}>النبض المالي</Text>
                <Text style={styles.pulseSubtitle}>
                  ملخص محفظة {selectedChild.name}
                </Text>
              </View>
            </View>

            <View style={styles.statusBadge}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>مستقر</Text>
            </View>
          </View>

          <View style={styles.totalBalanceSection}>
            <Text style={styles.totalBalanceLabel}>إجمالي رصيد الطفل</Text>

            <View style={styles.balanceRow}>
              <Text style={styles.totalBalance}>
                {selectedChild.balance.toLocaleString("ar-SA")}
              </Text>
              <Text style={styles.currencyText}>ر.س</Text>
            </View>
          </View>

          <View style={styles.balanceStats}>
            <View style={styles.balanceStatItem}>
              <View style={styles.balanceStatIcon}>
                <Ionicons
                  name="wallet-outline"
                  size={18}
                  color={COLORS.surface}
                />
              </View>

              <Text style={styles.balanceStatLabel}>متاح للصرف</Text>
              <Text style={styles.balanceStatValue}>
                {selectedChild.available} ر.س
              </Text>
            </View>

            <View style={styles.statSeparator} />

            <View style={styles.balanceStatItem}>
              <View style={styles.balanceStatIcon}>
                <Ionicons
                  name="archive-outline"
                  size={18}
                  color={COLORS.surface}
                />
              </View>

              <Text style={styles.balanceStatLabel}>مدخر</Text>
              <Text style={styles.balanceStatValue}>
                {selectedChild.savings} ر.س
              </Text>
            </View>

            <View style={styles.statSeparator} />

            <View style={styles.balanceStatItem}>
              <View style={styles.balanceStatIcon}>
                <Ionicons
                  name="trending-up-outline"
                  size={18}
                  color={COLORS.surface}
                />
              </View>

              <Text style={styles.balanceStatLabel}>مستثمر</Text>
              <Text style={styles.balanceStatValue}>
                {selectedChild.invested} ر.س
              </Text>
            </View>
          </View>
        </LinearGradient>

        {/* Quick Notice */}
        <View style={styles.smartNotice}>
          <View style={styles.noticeIcon}>
            <Ionicons name="sparkles" size={20} color={COLORS.gold} />
          </View>

          <View style={styles.noticeContent}>
            <Text style={styles.noticeTitle}>ملاحظة ذكية</Text>
            <Text style={styles.noticeText}>
              ارتفع ادخار {selectedChild.name} هذا الشهر، ويمكن تخصيص جزء بسيط
              للاستثمار طويل المدى.
            </Text>
          </View>

          <Ionicons
            name="chevron-back"
            size={20}
            color={COLORS.muted}
          />
        </View>

        {/* Financial Sections */}
        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>إدارة أموال الطفل</Text>
            <Text style={styles.sectionSubtitle}>
              كل ما يخص الأهداف والاستثمار والتحالفات
            </Text>
          </View>
        </View>

        {/* Goals */}
        <TouchableOpacity
          activeOpacity={0.88}
          onPress={() => navigateTo("/parent/goals")}
          style={styles.featureCard}
        >
          <LinearGradient
            colors={["#FFF6ED", "#FFFDFC"]}
            style={styles.featureCardGradient}
          >
            <View style={styles.featureTopRow}>
              <View style={styles.featureTitleContainer}>
                <View
                  style={[
                    styles.featureIcon,
                    { backgroundColor: COLORS.coralSoft },
                  ]}
                >
                  <Ionicons
                    name="flag-outline"
                    size={25}
                    color={COLORS.coralDark}
                  />
                </View>

                <View>
                  <Text style={styles.featureTitle}>الأهداف المالية</Text>
                  <Text style={styles.featureDescription}>
                    تابعي أهداف الطفل ونسبة تقدمه
                  </Text>
                </View>
              </View>

              <View
                style={[
                  styles.arrowButton,
                  { backgroundColor: COLORS.coralSoft },
                ]}
              >
                <Ionicons
                  name="arrow-back"
                  size={19}
                  color={COLORS.coralDark}
                />
              </View>
            </View>

            <View style={styles.goalPreview}>
              <View style={styles.goalPreviewHeader}>
                <View>
                  <Text style={styles.previewLabel}>الهدف الأقرب</Text>
                  <Text style={styles.previewTitle}>شراء دراجة جديدة</Text>
                </View>

                <View style={styles.goalPercentageBadge}>
                  <Text style={styles.goalPercentage}>68%</Text>
                </View>
              </View>

              <View style={styles.progressBackground}>
                <LinearGradient
                  colors={[COLORS.coralDark, COLORS.coral]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[styles.progressFill, { width: "68%" }]}
                />
              </View>

              <View style={styles.previewFooter}>
                <Text style={styles.previewAmount}>340 من 500 ر.س</Text>

                <View style={styles.previewCount}>
                  <Ionicons
                    name="flag"
                    size={14}
                    color={COLORS.coralDark}
                  />
                  <Text style={styles.previewCountText}>3 أهداف نشطة</Text>
                </View>
              </View>
            </View>
          </LinearGradient>
        </TouchableOpacity>

        {/* Investment */}
        <TouchableOpacity
          activeOpacity={0.88}
          onPress={() => navigateTo("/parent/investments")}
          style={styles.featureCard}
        >
          <LinearGradient
            colors={["#EAFBF7", "#FCFFFE"]}
            style={styles.featureCardGradient}
          >
            <View style={styles.featureTopRow}>
              <View style={styles.featureTitleContainer}>
                <View
                  style={[
                    styles.featureIcon,
                    { backgroundColor: COLORS.mintSoft },
                  ]}
                >
                  <Ionicons
                    name="trending-up-outline"
                    size={25}
                    color={COLORS.mintDark}
                  />
                </View>

                <View>
                  <Text style={styles.featureTitle}>الاستثمار</Text>
                  <Text style={styles.featureDescription}>
                    استثمري من محفظة الطفل لصالح مستقبله
                  </Text>
                </View>
              </View>

              <View
                style={[
                  styles.arrowButton,
                  { backgroundColor: COLORS.mintSoft },
                ]}
              >
                <Ionicons
                  name="arrow-back"
                  size={19}
                  color={COLORS.mintDark}
                />
              </View>
            </View>

            <View style={styles.investmentPreview}>
              <View style={styles.investmentHeader}>
                <View style={styles.investmentStatus}>
                  <View style={styles.investmentStatusDot} />
                  <Text style={styles.investmentStatusText}>استثمار نشط</Text>
                </View>

                <Text style={styles.investmentName}>
                  استثمار {selectedChild.name}
                </Text>
              </View>

              <View style={styles.investmentStats}>
                <View style={styles.investmentStatBox}>
                  <Text style={styles.investmentStatLabel}>رأس المال</Text>
                  <Text style={styles.investmentStatValue}>250 ر.س</Text>
                </View>

                <View style={styles.investmentStatBox}>
                  <Text style={styles.investmentStatLabel}>العائد الحالي</Text>
                  <Text
                    style={[
                      styles.investmentStatValue,
                      { color: COLORS.mintDark },
                    ]}
                  >
                    +18 ر.س
                  </Text>
                </View>

                <View style={styles.investmentStatBox}>
                  <Text style={styles.investmentStatLabel}>القيمة الحالية</Text>
                  <Text style={styles.investmentStatValue}>268 ر.س</Text>
                </View>
              </View>

              <View style={styles.investmentNote}>
                <Ionicons
                  name="shield-checkmark-outline"
                  size={17}
                  color={COLORS.mintDark}
                />

                <Text style={styles.investmentNoteText}>
                  رأس المال والعائد يعودان بالكامل لمحفظة الطفل
                </Text>
              </View>
            </View>
          </LinearGradient>
        </TouchableOpacity>

        {/* Alliances */}
        <TouchableOpacity
          activeOpacity={0.88}
          onPress={() => navigateTo("/parent/alliances")}
          style={styles.featureCard}
        >
          <LinearGradient
            colors={["#F2EFFF", "#FDFDFF"]}
            style={styles.featureCardGradient}
          >
            <View style={styles.featureTopRow}>
              <View style={styles.featureTitleContainer}>
                <View
                  style={[
                    styles.featureIcon,
                    { backgroundColor: COLORS.purpleSoft },
                  ]}
                >
                  <Ionicons
                    name="people-outline"
                    size={25}
                    color={COLORS.purpleDark}
                  />
                </View>

                <View>
                  <Text style={styles.featureTitle}>التحالفات</Text>
                  <Text style={styles.featureDescription}>
                    أهداف مشتركة بين أكثر من طفل
                  </Text>
                </View>
              </View>

              <View
                style={[
                  styles.arrowButton,
                  { backgroundColor: COLORS.purpleSoft },
                ]}
              >
                <Ionicons
                  name="arrow-back"
                  size={19}
                  color={COLORS.purpleDark}
                />
              </View>
            </View>

            <View style={styles.alliancePreview}>
              <View style={styles.allianceImages}>
                <View
                  style={[
                    styles.allianceAvatar,
                    {
                      backgroundColor: "#FFB5A7",
                      zIndex: 3,
                    },
                  ]}
                >
                  <Text style={styles.allianceAvatarText}>ر</Text>
                </View>

                <View
                  style={[
                    styles.allianceAvatar,
                    styles.overlapAvatar,
                    {
                      backgroundColor: "#9AD7F5",
                      zIndex: 2,
                    },
                  ]}
                >
                  <Text style={styles.allianceAvatarText}>س</Text>
                </View>

                <View
                  style={[
                    styles.allianceAvatar,
                    styles.overlapAvatar,
                    {
                      backgroundColor: "#B9E8D2",
                      zIndex: 1,
                    },
                  ]}
                >
                  <Text style={styles.allianceAvatarText}>ل</Text>
                </View>
              </View>

              <View style={styles.allianceContent}>
                <Text style={styles.allianceTitle}>رحلة العائلة</Text>
                <Text style={styles.allianceDescription}>
                  يساهم 3 أطفال لتحقيق هدف مشترك
                </Text>

                <View style={styles.allianceProgressRow}>
                  <View style={styles.allianceProgressBackground}>
                    <View
                      style={[
                        styles.allianceProgressFill,
                        { width: "54%" },
                      ]}
                    />
                  </View>

                  <Text style={styles.alliancePercentage}>54%</Text>
                </View>
              </View>
            </View>
          </LinearGradient>
        </TouchableOpacity>

        {/* Recent Activity */}
        <View style={styles.recentSection}>
          <View style={styles.recentHeader}>
            <Text style={styles.sectionTitle}>آخر العمليات</Text>

            <TouchableOpacity activeOpacity={0.8}>
              <Text style={styles.viewAllText}>عرض الكل</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.activitiesCard}>
            <TransactionItem
              icon="trending-up"
              iconColor={COLORS.mintDark}
              iconBackground={COLORS.mintSoft}
              title="عائد استثماري"
              subtitle="تمت إضافته لمحفظة ريم"
              amount="+18 ر.س"
              amountColor={COLORS.mintDark}
            />

            <View style={styles.transactionSeparator} />

            <TransactionItem
              icon="flag"
              iconColor={COLORS.coralDark}
              iconBackground={COLORS.coralSoft}
              title="مساهمة في هدف"
              subtitle="شراء دراجة جديدة"
              amount="-40 ر.س"
              amountColor={COLORS.text}
            />

            <View style={styles.transactionSeparator} />

            <TransactionItem
              icon="people"
              iconColor={COLORS.purpleDark}
              iconBackground={COLORS.purpleSoft}
              title="مساهمة في تحالف"
              subtitle="رحلة العائلة"
              amount="-25 ر.س"
              amountColor={COLORS.text}
            />
          </View>
        </View>

        <View style={styles.bottomSpace} />
      </ScrollView>
    </SafeAreaView>
  );
}

type TransactionItemProps = {
  icon: keyof typeof Ionicons.glyphMap;
  iconColor: string;
  iconBackground: string;
  title: string;
  subtitle: string;
  amount: string;
  amountColor: string;
};

function TransactionItem({
  icon,
  iconColor,
  iconBackground,
  title,
  subtitle,
  amount,
  amountColor,
}: TransactionItemProps) {
  return (
    <View style={styles.transactionItem}>
      <View style={styles.transactionRight}>
        <View
          style={[
            styles.transactionIcon,
            { backgroundColor: iconBackground },
          ]}
        >
          <Ionicons name={icon} size={20} color={iconColor} />
        </View>

        <View>
          <Text style={styles.transactionTitle}>{title}</Text>
          <Text style={styles.transactionSubtitle}>{subtitle}</Text>
        </View>
      </View>

      <Text style={[styles.transactionAmount, { color: amountColor }]}>
        {amount}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 12,
  },

  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.background,
  },

  loadingText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 16,
    color: COLORS.text,
  },

  topDecorationOne: {
    position: "absolute",
    width: 190,
    height: 190,
    borderRadius: 95,
    backgroundColor: "#E6F0FF",
    top: -85,
    left: -80,
    opacity: 0.85,
  },

  topDecorationTwo: {
    position: "absolute",
    width: 95,
    height: 95,
    borderRadius: 48,
    backgroundColor: "#E8FAF5",
    top: 70,
    right: -45,
    opacity: 0.9,
  },

  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 24,
  },

  headerTextContainer: {
    flex: 1,
    alignItems: "flex-end",
  },

  pageTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 29,
    color: COLORS.text,
    textAlign: "right",
  },

  pageSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 14,
    color: COLORS.muted,
    marginTop: 4,
    textAlign: "right",
  },

  notificationButton: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: COLORS.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: "#344054",
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 3,
  },

  notificationDot: {
    position: "absolute",
    top: 11,
    right: 12,
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: COLORS.coral,
    borderWidth: 1.5,
    borderColor: COLORS.surface,
  },

  childrenSection: {
    marginBottom: 20,
  },

  sectionLabel: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
    textAlign: "right",
    marginBottom: 11,
  },

  childrenList: {
    gap: 10,
    paddingHorizontal: 2,
  },

  childButton: {
    minWidth: 90,
    height: 46,
    borderRadius: 15,
    backgroundColor: COLORS.surface,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
  },

  selectedChildButton: {
    backgroundColor: COLORS.blueSoft,
    borderColor: COLORS.blue,
  },

  childAvatar: {
    width: 31,
    height: 31,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },

  childAvatarText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: COLORS.text,
  },

  childName: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.muted,
  },

  selectedChildName: {
    color: COLORS.blueDark,
  },

  selectedCheck: {
    position: "absolute",
    top: -4,
    left: -4,
    width: 17,
    height: 17,
    borderRadius: 6,
    backgroundColor: COLORS.blue,
    alignItems: "center",
    justifyContent: "center",
  },

  pulseCard: {
    minHeight: 285,
    borderRadius: 28,
    padding: 20,
    overflow: "hidden",
    marginBottom: 15,
    shadowColor: COLORS.blueDark,
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.22,
    shadowRadius: 22,
    elevation: 9,
  },

  pulseCircleLarge: {
    position: "absolute",
    width: 230,
    height: 230,
    borderRadius: 115,
    borderWidth: 35,
    borderColor: "rgba(255,255,255,0.07)",
    left: -90,
    bottom: -100,
  },

  pulseCircleSmall: {
    position: "absolute",
    width: 105,
    height: 105,
    borderRadius: 53,
    backgroundColor: "rgba(255,255,255,0.07)",
    right: -25,
    top: -30,
  },

  pulseHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },

  pulseTitleRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },

  pulseIconContainer: {
    width: 43,
    height: 43,
    borderRadius: 15,
    backgroundColor: "rgba(255,255,255,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },

  pulseTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 18,
    color: COLORS.surface,
    textAlign: "right",
  },

  pulseSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: "rgba(255,255,255,0.78)",
    textAlign: "right",
    marginTop: 1,
  },

  statusBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.16)",
    paddingVertical: 7,
    paddingHorizontal: 11,
    borderRadius: 12,
  },

  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: "#A8FFD9",
  },

  statusText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.surface,
  },

  totalBalanceSection: {
    alignItems: "flex-end",
    marginTop: 27,
  },

  totalBalanceLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "rgba(255,255,255,0.75)",
  },

  balanceRow: {
    flexDirection: "row-reverse",
    alignItems: "flex-end",
    gap: 7,
    marginTop: 2,
  },

  totalBalance: {
    fontFamily: "Tajawal_900Black",
    fontSize: 38,
    color: COLORS.surface,
    letterSpacing: 0.5,
  },

  currencyText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "rgba(255,255,255,0.88)",
    marginBottom: 7,
  },

  balanceStats: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "rgba(255,255,255,0.13)",
    borderRadius: 19,
    paddingVertical: 13,
    paddingHorizontal: 7,
    marginTop: 24,
  },

  balanceStatItem: {
    flex: 1,
    alignItems: "center",
  },

  balanceStatIcon: {
    width: 31,
    height: 31,
    borderRadius: 11,
    backgroundColor: "rgba(255,255,255,0.13)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 5,
  },

  balanceStatLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "rgba(255,255,255,0.72)",
  },

  balanceStatValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.surface,
    marginTop: 2,
  },

  statSeparator: {
    width: 1,
    height: 47,
    backgroundColor: "rgba(255,255,255,0.18)",
  },

  smartNotice: {
    backgroundColor: COLORS.surface,
    borderRadius: 19,
    padding: 14,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 11,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 25,
  },

  noticeIcon: {
    width: 41,
    height: 41,
    borderRadius: 14,
    backgroundColor: COLORS.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },

  noticeContent: {
    flex: 1,
    alignItems: "flex-end",
  },

  noticeTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.text,
  },

  noticeText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11.5,
    lineHeight: 18,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },

  sectionHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 13,
  },

  sectionTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 19,
    color: COLORS.text,
    textAlign: "right",
  },

  sectionSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: COLORS.muted,
    marginTop: 2,
    textAlign: "right",
  },

  featureCard: {
    borderRadius: 24,
    marginBottom: 14,
    shadowColor: "#344054",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowOpacity: 0.065,
    shadowRadius: 16,
    elevation: 3,
  },

  featureCardGradient: {
    borderRadius: 24,
    padding: 17,
    borderWidth: 1,
    borderColor: "rgba(220,225,235,0.7)",
  },

  featureTopRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },

  featureTitleContainer: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 11,
    flex: 1,
  },

  featureIcon: {
    width: 51,
    height: 51,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },

  featureTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 17,
    color: COLORS.text,
    textAlign: "right",
  },

  featureDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11.5,
    color: COLORS.muted,
    marginTop: 2,
    textAlign: "right",
  },

  arrowButton: {
    width: 37,
    height: 37,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },

  goalPreview: {
    backgroundColor: "rgba(255,255,255,0.84)",
    borderRadius: 18,
    padding: 14,
    marginTop: 15,
  },

  goalPreviewHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },

  previewLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    textAlign: "right",
  },

  previewTitle: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
    textAlign: "right",
    marginTop: 2,
  },

  goalPercentageBadge: {
    backgroundColor: COLORS.coralSoft,
    paddingVertical: 7,
    paddingHorizontal: 10,
    borderRadius: 11,
  },

  goalPercentage: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.coralDark,
  },

  progressBackground: {
    height: 8,
    borderRadius: 5,
    backgroundColor: "#F4E5E2",
    overflow: "hidden",
    marginTop: 13,
  },

  progressFill: {
    height: "100%",
    borderRadius: 5,
  },

  previewFooter: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 9,
  },

  previewAmount: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11.5,
    color: COLORS.text,
  },

  previewCount: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
  },

  previewCountText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
  },

  investmentPreview: {
    backgroundColor: "rgba(255,255,255,0.86)",
    borderRadius: 18,
    padding: 14,
    marginTop: 15,
  },

  investmentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  investmentStatus: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.mintSoft,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 10,
  },

  investmentStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: COLORS.mintDark,
  },

  investmentStatusText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10.5,
    color: COLORS.mintDark,
  },

  investmentName: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
  },

  investmentStats: {
    flexDirection: "row-reverse",
    gap: 7,
    marginTop: 13,
  },

  investmentStatBox: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#F8FBFA",
    borderRadius: 13,
    paddingVertical: 10,
  },

  investmentStatLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 9.5,
    color: COLORS.muted,
  },

  investmentStatValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12.5,
    color: COLORS.text,
    marginTop: 3,
  },

  investmentNote: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 7,
    marginTop: 11,
    backgroundColor: COLORS.mintSoft,
    padding: 10,
    borderRadius: 12,
  },

  investmentNoteText: {
    flex: 1,
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.mintDark,
    textAlign: "right",
  },

  alliancePreview: {
    backgroundColor: "rgba(255,255,255,0.86)",
    borderRadius: 18,
    padding: 14,
    marginTop: 15,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 13,
  },

  allianceImages: {
    width: 85,
    flexDirection: "row-reverse",
    alignItems: "center",
  },

  allianceAvatar: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: COLORS.surface,
  },

  overlapAvatar: {
    marginRight: -14,
  },

  allianceAvatarText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: COLORS.text,
  },

  allianceContent: {
    flex: 1,
    alignItems: "flex-end",
  },

  allianceTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: COLORS.text,
  },

  allianceDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    marginTop: 1,
    textAlign: "right",
  },

  allianceProgressRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 9,
    marginTop: 10,
    width: "100%",
  },

  allianceProgressBackground: {
    flex: 1,
    height: 7,
    borderRadius: 5,
    backgroundColor: "#E8E3FA",
    overflow: "hidden",
  },

  allianceProgressFill: {
    height: "100%",
    borderRadius: 5,
    backgroundColor: COLORS.purple,
  },

  alliancePercentage: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 11,
    color: COLORS.purpleDark,
  },

  recentSection: {
    marginTop: 13,
  },

  recentHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },

  viewAllText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.blue,
  },

  activitiesCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 22,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
  },

  transactionItem: {
    minHeight: 72,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },

  transactionRight: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
    flex: 1,
  },

  transactionIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },

  transactionTitle: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: COLORS.text,
    textAlign: "right",
  },

  transactionSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 1,
  },

  transactionAmount: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
  },

  transactionSeparator: {
    height: 1,
    backgroundColor: COLORS.border,
    marginHorizontal: 4,
  },

  bottomSpace: {
    height: 120,
  },
});