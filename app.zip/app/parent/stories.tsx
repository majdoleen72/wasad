import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const { width } = Dimensions.get("window");

const COLORS = {
  background: "#F7F8FC",
  surface: "#FFFFFF",
  primary: "#7357DF",
  primaryDark: "#5740BE",
  primarySoft: "#EEE9FF",

  navy: "#24334B",
  text: "#263247",
  muted: "#8992A5",
  border: "#E9EBF2",

  yellow: "#FFC857",
  yellowSoft: "#FFF4D9",

  green: "#54C79A",
  greenSoft: "#DFF7EE",

  blue: "#5F9DF7",
  blueSoft: "#E3EEFF",

  coral: "#FF8D79",
  coralSoft: "#FFE7E2",

  pink: "#EF7EB5",
  pinkSoft: "#FCE5F1",
};

type StoryStatus = "new" | "published" | "completed";

type Story = {
  id: string;
  title: string;
  description: string;
  childName: string;
  topic: string;
  readingMinutes: number;
  reward: number;
  icon: keyof typeof Ionicons.glyphMap;
  colors: [string, string];
  status: StoryStatus;
  progress: number;
};

type Topic = {
  id: string;
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  background: string;
};

const topics: Topic[] = [
  {
    id: "saving",
    title: "الادخار",
    icon: "wallet-outline",
    color: COLORS.primary,
    background: COLORS.primarySoft,
  },
  {
    id: "goals",
    title: "تحقيق الأهداف",
    icon: "flag-outline",
    color: COLORS.coral,
    background: COLORS.coralSoft,
  },
  {
    id: "spending",
    title: "إدارة المصروف",
    icon: "cash-outline",
    color: COLORS.blue,
    background: COLORS.blueSoft,
  },
  {
    id: "giving",
    title: "العطاء",
    icon: "heart-outline",
    color: COLORS.pink,
    background: COLORS.pinkSoft,
  },
  {
    id: "investment",
    title: "الاستثمار",
    icon: "trending-up-outline",
    color: COLORS.green,
    background: COLORS.greenSoft,
  },
];

const storiesData: Story[] = [
  {
    id: "1",
    title: "نورة وحصالة الأمنيات",
    description:
      "تتعلم نورة كيف تدخر جزءًا من مصروفها حتى تحقق حلمها الصغير.",
    childName: "نورة",
    topic: "الادخار",
    readingMinutes: 4,
    reward: 5,
    icon: "sparkles-outline",
    colors: ["#8568EA", "#B59EF7"],
    status: "new",
    progress: 0,
  },
  {
    id: "2",
    title: "رحلة سالم إلى متجر الألعاب",
    description:
      "يكتشف سالم الفرق بين الأشياء التي يحتاجها والأشياء التي يريدها.",
    childName: "سالم",
    topic: "إدارة المصروف",
    readingMinutes: 6,
    reward: 8,
    icon: "cart-outline",
    colors: ["#5C9DF7", "#8CC6FF"],
    status: "published",
    progress: 45,
  },
  {
    id: "3",
    title: "شجرة العطاء",
    description:
      "قصة لطيفة تعلّم الأطفال كيف يمكن للمبلغ البسيط أن يصنع فرقًا كبيرًا.",
    childName: "ليان",
    topic: "العطاء",
    readingMinutes: 5,
    reward: 6,
    icon: "heart-outline",
    colors: ["#F07BB4", "#F6A6CA"],
    status: "completed",
    progress: 100,
  },
  {
    id: "4",
    title: "هدف فهد الكبير",
    description:
      "يقسم فهد هدفه الكبير إلى خطوات صغيرة ويحتفل بكل تقدم يحققه.",
    childName: "فهد",
    topic: "تحقيق الأهداف",
    readingMinutes: 7,
    reward: 10,
    icon: "flag-outline",
    colors: ["#FF907B", "#FFB59D"],
    status: "published",
    progress: 70,
  },
];

const children = [
  {
    id: "1",
    name: "نورة",
    age: 9,
    icon: "happy-outline" as keyof typeof Ionicons.glyphMap,
    color: "#7B65DA",
  },
  {
    id: "2",
    name: "سالم",
    age: 11,
    icon: "happy-outline" as keyof typeof Ionicons.glyphMap,
    color: "#5797E9",
  },
  {
    id: "3",
    name: "ليان",
    age: 7,
    icon: "happy-outline" as keyof typeof Ionicons.glyphMap,
    color: "#EF84B6",
  },
];

export default function StoriesScreen() {
  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  const [selectedFilter, setSelectedFilter] = useState("الكل");
  const [createModalVisible, setCreateModalVisible] = useState(false);

  const [selectedChild, setSelectedChild] = useState(children[0]);
  const [selectedTopic, setSelectedTopic] = useState(topics[0]);
  const [selectedLength, setSelectedLength] = useState("متوسطة");
  const [childGoal, setChildGoal] = useState("");

  const filters = ["الكل", "الجديدة", "قيد القراءة", "المكتملة"];

  const filteredStories = useMemo(() => {
    if (selectedFilter === "الجديدة") {
      return storiesData.filter((story) => story.status === "new");
    }

    if (selectedFilter === "قيد القراءة") {
      return storiesData.filter((story) => story.status === "published");
    }

    if (selectedFilter === "المكتملة") {
      return storiesData.filter((story) => story.status === "completed");
    }

    return storiesData;
  }, [selectedFilter]);

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  const renderStoryCard = ({ item }: { item: Story }) => {
    const isCompleted = item.status === "completed";

    return (
      <TouchableOpacity
        activeOpacity={0.9}
        style={styles.storyCard}
        onPress={() => {
          console.log("Open story:", item.id);
        }}
      >
        <LinearGradient
          colors={item.colors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.storyCover}
        >
          <View style={styles.coverCircleLarge} />
          <View style={styles.coverCircleSmall} />

          <View style={styles.storyStatusBadge}>
            <Text style={styles.storyStatusText}>
              {item.status === "new"
                ? "جديدة"
                : item.status === "completed"
                  ? "مكتملة"
                  : "قيد القراءة"}
            </Text>
          </View>

          <View style={styles.storyIllustration}>
            <View style={styles.bookBack}>
              <Ionicons name={item.icon} size={34} color="#FFFFFF" />
            </View>

            <View style={styles.sparkleOne}>
              <Ionicons name="sparkles" size={18} color="#FFF3BC" />
            </View>

            <View style={styles.sparkleTwo}>
              <Ionicons name="star" size={13} color="#FFFFFF" />
            </View>
          </View>
        </LinearGradient>

        <View style={styles.storyContent}>
          <View style={styles.storyTopRow}>
            <View style={styles.topicBadge}>
              <Text style={styles.topicBadgeText}>{item.topic}</Text>
            </View>

            <TouchableOpacity style={styles.moreButton}>
              <Ionicons
                name="ellipsis-horizontal"
                size={19}
                color={COLORS.muted}
              />
            </TouchableOpacity>
          </View>

          <Text style={styles.storyTitle}>{item.title}</Text>

          <Text style={styles.storyDescription} numberOfLines={2}>
            {item.description}
          </Text>

          <View style={styles.storyDetailsRow}>
            <View style={styles.storyDetail}>
              <Ionicons
                name="person-outline"
                size={15}
                color={COLORS.muted}
              />

              <Text style={styles.storyDetailText}>{item.childName}</Text>
            </View>

            <View style={styles.detailDivider} />

            <View style={styles.storyDetail}>
              <Ionicons
                name="time-outline"
                size={15}
                color={COLORS.muted}
              />

              <Text style={styles.storyDetailText}>
                {item.readingMinutes} دقائق
              </Text>
            </View>

            <View style={styles.detailDivider} />

            <View style={styles.storyDetail}>
              <Ionicons name="star" size={14} color={COLORS.yellow} />

              <Text style={styles.storyDetailText}>{item.reward} نقاط</Text>
            </View>
          </View>

          {item.status !== "new" && (
            <View style={styles.progressSection}>
              <View style={styles.progressTextRow}>
                <Text style={styles.progressLabel}>
                  {isCompleted ? "تمت القراءة" : "تقدم القراءة"}
                </Text>

                <Text style={styles.progressValue}>{item.progress}%</Text>
              </View>

              <View style={styles.progressTrack}>
                <View
                  style={[
                    styles.progressFill,
                    {
                      width: `${item.progress}%`,
                      backgroundColor: isCompleted
                        ? COLORS.green
                        : COLORS.primary,
                    },
                  ]}
                />
              </View>
            </View>
          )}

          <TouchableOpacity
            activeOpacity={0.85}
            style={[
              styles.storyActionButton,
              isCompleted && styles.completedActionButton,
            ]}
          >
            <Text
              style={[
                styles.storyActionText,
                isCompleted && styles.completedActionText,
              ]}
            >
              {item.status === "new"
                ? "إرسال للطفل"
                : item.status === "completed"
                  ? "عرض النتائج"
                  : "متابعة القصة"}
            </Text>

            <Ionicons
              name={isCompleted ? "checkmark-circle" : "arrow-back"}
              size={18}
              color={isCompleted ? COLORS.green : "#FFFFFF"}
            />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />

      <View style={styles.container}>
        <FlatList
          data={filteredStories}
          keyExtractor={(item) => item.id}
          renderItem={renderStoryCard}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={
            <>
              <View style={styles.header}>
                <View style={styles.headerTextContainer}>
                  <Text style={styles.helloText}>قصص وَسَد</Text>

                  <Text style={styles.headerTitle}>
                    حكايات صغيرة{"\n"}بأثر مالي كبير
                  </Text>

                  <Text style={styles.headerDescription}>
                    أنشئي قصصًا ممتعة ومخصصة تساعد طفلك على فهم المال بطريقة
                    بسيطة.
                  </Text>
                </View>

                <View style={styles.headerIconContainer}>
                  <LinearGradient
                    colors={["#7357DF", "#9E87F4"]}
                    style={styles.headerIconGradient}
                  >
                    <Ionicons
                      name="book-outline"
                      size={34}
                      color="#FFFFFF"
                    />
                  </LinearGradient>

                  <View style={styles.headerStar}>
                    <Ionicons
                      name="sparkles"
                      size={17}
                      color={COLORS.yellow}
                    />
                  </View>
                </View>
              </View>

              <View style={styles.summaryCard}>
                <View style={styles.summaryShapeOne} />
                <View style={styles.summaryShapeTwo} />

                <View style={styles.summaryContent}>
                  <View style={styles.summaryTextContainer}>
                    <View style={styles.aiBadge}>
                      <Ionicons
                        name="sparkles"
                        size={15}
                        color={COLORS.primary}
                      />

                      <Text style={styles.aiBadgeText}>بمساعدة الذكاء</Text>
                    </View>

                    <Text style={styles.summaryTitle}>
                      اصنعي قصة تناسب طفلك
                    </Text>

                    <Text style={styles.summaryDescription}>
                      اختاري الطفل والموضوع والهدف، وسنجهز له تجربة قصصية
                      ممتعة.
                    </Text>

                    <TouchableOpacity
                      activeOpacity={0.85}
                      style={styles.createStoryButton}
                      onPress={() => setCreateModalVisible(true)}
                    >
                      <Ionicons name="add" size={20} color="#FFFFFF" />

                      <Text style={styles.createStoryButtonText}>
                        إنشاء قصة جديدة
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View style={styles.summaryIllustration}>
                    <View style={styles.storyBook}>
                      <View style={styles.bookPageLeft}>
                        <Ionicons
                          name="star-outline"
                          size={22}
                          color="#7357DF"
                        />
                      </View>

                      <View style={styles.bookPageRight}>
                        <Ionicons
                          name="wallet-outline"
                          size={22}
                          color="#7357DF"
                        />
                      </View>
                    </View>

                    <View style={styles.coinOne}>
                      <Text style={styles.coinText}>﷼</Text>
                    </View>

                    <View style={styles.coinTwo}>
                      <Ionicons name="star" size={13} color="#FFFFFF" />
                    </View>
                  </View>
                </View>
              </View>

              <View style={styles.sectionHeader}>
                <View>
                  <Text style={styles.sectionTitle}>استكشفي المواضيع</Text>

                  <Text style={styles.sectionSubtitle}>
                    اختاري المهارة المالية المناسبة
                  </Text>
                </View>

                <TouchableOpacity>
                  <Text style={styles.seeAllText}>عرض الكل</Text>
                </TouchableOpacity>
              </View>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.topicsContainer}
              >
                {topics.map((topic) => (
                  <TouchableOpacity
                    key={topic.id}
                    activeOpacity={0.85}
                    style={styles.topicCard}
                    onPress={() => {
                      setSelectedTopic(topic);
                      setCreateModalVisible(true);
                    }}
                  >
                    <View
                      style={[
                        styles.topicIconContainer,
                        { backgroundColor: topic.background },
                      ]}
                    >
                      <Ionicons
                        name={topic.icon}
                        size={23}
                        color={topic.color}
                      />
                    </View>

                    <Text style={styles.topicTitle}>{topic.title}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <View style={styles.sectionHeader}>
                <View>
                  <Text style={styles.sectionTitle}>قصص أطفالي</Text>

                  <Text style={styles.sectionSubtitle}>
                    تابعي القراءة والتقدم
                  </Text>
                </View>

                <View style={styles.storyCountBadge}>
                  <Text style={styles.storyCountText}>
                    {storiesData.length} قصص
                  </Text>
                </View>
              </View>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.filtersContainer}
              >
                {filters.map((filter) => {
                  const active = selectedFilter === filter;

                  return (
                    <TouchableOpacity
                      key={filter}
                      activeOpacity={0.85}
                      style={[
                        styles.filterButton,
                        active && styles.activeFilterButton,
                      ]}
                      onPress={() => setSelectedFilter(filter)}
                    >
                      <Text
                        style={[
                          styles.filterText,
                          active && styles.activeFilterText,
                        ]}
                      >
                        {filter}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </>
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <View style={styles.emptyIcon}>
                <Ionicons
                  name="book-outline"
                  size={34}
                  color={COLORS.primary}
                />
              </View>

              <Text style={styles.emptyTitle}>ما فيه قصص هنا حاليًا</Text>

              <Text style={styles.emptyDescription}>
                أنشئي قصة جديدة لطفلك وستظهر في هذه القائمة.
              </Text>
            </View>
          }
        />

        <TouchableOpacity
          activeOpacity={0.9}
          style={styles.floatingButton}
          onPress={() => setCreateModalVisible(true)}
        >
          <LinearGradient
            colors={["#7357DF", "#9079EC"]}
            style={styles.floatingGradient}
          >
            <Ionicons name="add" size={28} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      <Modal
        visible={createModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setCreateModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHandle} />

            <View style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setCreateModalVisible(false)}
              >
                <Ionicons name="close" size={22} color={COLORS.text} />
              </TouchableOpacity>

              <View style={styles.modalHeaderText}>
                <Text style={styles.modalTitle}>إنشاء قصة جديدة</Text>

                <Text style={styles.modalSubtitle}>
                  خصصي القصة لتناسب طفلك
                </Text>
              </View>

              <View style={styles.modalHeaderIcon}>
                <Ionicons
                  name="sparkles"
                  size={21}
                  color={COLORS.primary}
                />
              </View>
            </View>

            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.modalScrollContent}
            >
              <Text style={styles.inputLabel}>اختاري الطفل</Text>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.childrenContainer}
              >
                {children.map((child) => {
                  const active = selectedChild.id === child.id;

                  return (
                    <TouchableOpacity
                      key={child.id}
                      activeOpacity={0.85}
                      style={[
                        styles.childCard,
                        active && styles.activeChildCard,
                      ]}
                      onPress={() => setSelectedChild(child)}
                    >
                      {active && (
                        <View style={styles.childCheck}>
                          <Ionicons
                            name="checkmark"
                            size={12}
                            color="#FFFFFF"
                          />
                        </View>
                      )}

                      <View
                        style={[
                          styles.childAvatar,
                          {
                            backgroundColor: `${child.color}1A`,
                          },
                        ]}
                      >
                        <Ionicons
                          name={child.icon}
                          size={26}
                          color={child.color}
                        />
                      </View>

                      <Text style={styles.childName}>{child.name}</Text>

                      <Text style={styles.childAge}>{child.age} سنوات</Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>

              <Text style={styles.inputLabel}>موضوع القصة</Text>

              <View style={styles.topicSelectionGrid}>
                {topics.map((topic) => {
                  const active = selectedTopic.id === topic.id;

                  return (
                    <TouchableOpacity
                      key={topic.id}
                      activeOpacity={0.85}
                      style={[
                        styles.topicSelectionCard,
                        active && {
                          borderColor: topic.color,
                          backgroundColor: topic.background,
                        },
                      ]}
                      onPress={() => setSelectedTopic(topic)}
                    >
                      <View
                        style={[
                          styles.smallTopicIcon,
                          {
                            backgroundColor: active
                              ? COLORS.surface
                              : topic.background,
                          },
                        ]}
                      >
                        <Ionicons
                          name={topic.icon}
                          size={19}
                          color={topic.color}
                        />
                      </View>

                      <Text
                        style={[
                          styles.topicSelectionText,
                          active && {
                            color: topic.color,
                            fontFamily: "Tajawal_800ExtraBold",
                          },
                        ]}
                      >
                        {topic.title}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <Text style={styles.inputLabel}>هدف الطفل</Text>

              <View style={styles.goalInputContainer}>
                <Ionicons
                  name="flag-outline"
                  size={21}
                  color={COLORS.primary}
                />

                <TextInput
                  value={childGoal}
                  onChangeText={setChildGoal}
                  placeholder="مثال: شراء دراجة جديدة"
                  placeholderTextColor="#A5ACB9"
                  style={styles.goalInput}
                  textAlign="right"
                />
              </View>

              <Text style={styles.inputLabel}>طول القصة</Text>

              <View style={styles.lengthContainer}>
                {[
                  {
                    title: "قصيرة",
                    description: "3 دقائق",
                  },
                  {
                    title: "متوسطة",
                    description: "5 دقائق",
                  },
                  {
                    title: "طويلة",
                    description: "8 دقائق",
                  },
                ].map((length) => {
                  const active = selectedLength === length.title;

                  return (
                    <TouchableOpacity
                      key={length.title}
                      activeOpacity={0.85}
                      style={[
                        styles.lengthCard,
                        active && styles.activeLengthCard,
                      ]}
                      onPress={() => setSelectedLength(length.title)}
                    >
                      <Ionicons
                        name={
                          length.title === "قصيرة"
                            ? "flash-outline"
                            : length.title === "متوسطة"
                              ? "book-outline"
                              : "library-outline"
                        }
                        size={21}
                        color={active ? COLORS.primary : COLORS.muted}
                      />

                      <Text
                        style={[
                          styles.lengthTitle,
                          active && styles.activeLengthTitle,
                        ]}
                      >
                        {length.title}
                      </Text>

                      <Text style={styles.lengthDescription}>
                        {length.description}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={styles.previewBox}>
                <View style={styles.previewIcon}>
                  <Ionicons
                    name="bulb-outline"
                    size={21}
                    color={COLORS.yellow}
                  />
                </View>

                <View style={styles.previewTextContainer}>
                  <Text style={styles.previewTitle}>
                    القصة ستكون مخصصة لـ {selectedChild.name}
                  </Text>

                  <Text style={styles.previewDescription}>
                    موضوعها {selectedTopic.title}، وبأسلوب مناسب لعمر{" "}
                    {selectedChild.age} سنوات.
                  </Text>
                </View>
              </View>

              <TouchableOpacity
                activeOpacity={0.9}
                style={styles.generateButton}
                onPress={() => {
                  console.log({
                    selectedChild,
                    selectedTopic,
                    selectedLength,
                    childGoal,
                  });

                  setCreateModalVisible(false);
                }}
              >
                <LinearGradient
                  colors={["#7357DF", "#8E76ED"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.generateGradient}
                >
                  <Ionicons name="sparkles" size={21} color="#FFFFFF" />

                  <Text style={styles.generateButtonText}>
                    إنشاء القصة
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <Text style={styles.demoNote}>
                الزر حاليًا للتصميم فقط، وبعدها نربطه بالذكاء الاصطناعي.
              </Text>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.background,
  },

  listContent: {
    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 125,
  },

  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },

  headerTextContainer: {
    flex: 1,
    alignItems: "flex-end",
  },

  helloText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.primary,
    textAlign: "right",
    marginBottom: 5,
  },

  headerTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 27,
    lineHeight: 35,
    color: COLORS.navy,
    textAlign: "right",
  },

  headerDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    lineHeight: 21,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 6,
    maxWidth: width * 0.68,
  },

  headerIconContainer: {
    width: 82,
    height: 96,
    marginLeft: 15,
    alignItems: "center",
    justifyContent: "center",
  },

  headerIconGradient: {
    width: 66,
    height: 66,
    borderRadius: 23,
    alignItems: "center",
    justifyContent: "center",
    transform: [{ rotate: "-6deg" }],
    shadowColor: COLORS.primary,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.23,
    shadowRadius: 14,
    elevation: 7,
  },

  headerStar: {
    position: "absolute",
    top: 3,
    right: 0,
    width: 29,
    height: 29,
    borderRadius: 12,
    backgroundColor: COLORS.yellowSoft,
    alignItems: "center",
    justifyContent: "center",
  },

  summaryCard: {
    minHeight: 218,
    borderRadius: 28,
    backgroundColor: COLORS.primarySoft,
    overflow: "hidden",
    marginBottom: 28,
  },

  summaryShapeOne: {
    position: "absolute",
    width: 155,
    height: 155,
    borderRadius: 80,
    backgroundColor: "rgba(115,87,223,0.10)",
    left: -35,
    bottom: -70,
  },

  summaryShapeTwo: {
    position: "absolute",
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "rgba(255,255,255,0.50)",
    right: -30,
    top: -35,
  },

  summaryContent: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 22,
  },

  summaryTextContainer: {
    flex: 1,
    alignItems: "flex-end",
    zIndex: 2,
  },

  aiBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.75)",
    marginBottom: 10,
  },

  aiBadgeText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: COLORS.primary,
  },

  summaryTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 19,
    color: COLORS.navy,
    textAlign: "right",
  },

  summaryDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12.5,
    lineHeight: 20,
    color: "#6E7290",
    textAlign: "right",
    marginTop: 7,
  },

  createStoryButton: {
    height: 44,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    paddingHorizontal: 16,
    marginTop: 15,
    shadowColor: COLORS.primary,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },

  createStoryButtonText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: "#FFFFFF",
  },

  summaryIllustration: {
    width: 125,
    height: 145,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 8,
  },

  storyBook: {
    flexDirection: "row",
    alignItems: "center",
    transform: [{ rotate: "-4deg" }],
  },

  bookPageLeft: {
    width: 53,
    height: 70,
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 18,
    borderBottomLeftRadius: 12,
    borderTopRightRadius: 6,
    borderBottomRightRadius: 6,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#403386",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 4,
  },

  bookPageRight: {
    width: 53,
    height: 70,
    backgroundColor: "#FBFAFF",
    borderTopRightRadius: 18,
    borderBottomRightRadius: 12,
    borderTopLeftRadius: 6,
    borderBottomLeftRadius: 6,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#403386",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 4,
  },

  coinOne: {
    position: "absolute",
    left: 5,
    top: 15,
    width: 35,
    height: 35,
    borderRadius: 18,
    backgroundColor: COLORS.yellow,
    alignItems: "center",
    justifyContent: "center",
    transform: [{ rotate: "-14deg" }],
  },

  coinText: {
    fontFamily: "Tajawal_900Black",
    fontSize: 14,
    color: "#FFFFFF",
  },

  coinTwo: {
    position: "absolute",
    right: 1,
    bottom: 19,
    width: 29,
    height: 29,
    borderRadius: 15,
    backgroundColor: COLORS.coral,
    alignItems: "center",
    justifyContent: "center",
  },

  sectionHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 13,
  },

  sectionTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 18,
    color: COLORS.navy,
    textAlign: "right",
  },

  sectionSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },

  seeAllText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.primary,
  },

  topicsContainer: {
    gap: 11,
    paddingBottom: 26,
    flexDirection: "row-reverse",
  },

  topicCard: {
    width: 112,
    minHeight: 108,
    borderRadius: 21,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 9,
  },

  topicIconContainer: {
    width: 47,
    height: 47,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 9,
  },

  topicTitle: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.text,
    textAlign: "center",
  },

  storyCountBadge: {
    backgroundColor: COLORS.primarySoft,
    paddingHorizontal: 11,
    paddingVertical: 6,
    borderRadius: 11,
  },

  storyCountText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: COLORS.primary,
  },

  filtersContainer: {
    flexDirection: "row-reverse",
    gap: 8,
    paddingBottom: 15,
  },

  filterButton: {
    height: 38,
    borderRadius: 13,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 16,
  },

  activeFilterButton: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },

  filterText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.muted,
  },

  activeFilterText: {
    color: "#FFFFFF",
  },

  storyCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 25,
    marginBottom: 17,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: "#34405B",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowOpacity: 0.07,
    shadowRadius: 14,
    elevation: 3,
  },

  storyCover: {
    height: 145,
    padding: 15,
    overflow: "hidden",
  },

  coverCircleLarge: {
    position: "absolute",
    width: 170,
    height: 170,
    borderRadius: 90,
    backgroundColor: "rgba(255,255,255,0.13)",
    right: -55,
    bottom: -75,
  },

  coverCircleSmall: {
    position: "absolute",
    width: 70,
    height: 70,
    borderRadius: 40,
    backgroundColor: "rgba(255,255,255,0.13)",
    left: -12,
    top: -20,
  },

  storyStatusBadge: {
    alignSelf: "flex-end",
    backgroundColor: "rgba(255,255,255,0.22)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
    borderRadius: 11,
    paddingHorizontal: 11,
    paddingVertical: 5,
  },

  storyStatusText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: "#FFFFFF",
  },

  storyIllustration: {
    position: "absolute",
    alignSelf: "center",
    top: 37,
    alignItems: "center",
    justifyContent: "center",
  },

  bookBack: {
    width: 82,
    height: 70,
    borderRadius: 22,
    backgroundColor: "rgba(255,255,255,0.22)",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.48)",
    alignItems: "center",
    justifyContent: "center",
    transform: [{ rotate: "-5deg" }],
  },

  sparkleOne: {
    position: "absolute",
    right: -31,
    top: -11,
  },

  sparkleTwo: {
    position: "absolute",
    left: -26,
    bottom: 3,
  },

  storyContent: {
    padding: 17,
  },

  storyTopRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },

  topicBadge: {
    backgroundColor: COLORS.primarySoft,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 9,
  },

  topicBadgeText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10.5,
    color: COLORS.primary,
  },

  moreButton: {
    width: 33,
    height: 33,
    borderRadius: 11,
    backgroundColor: COLORS.background,
    alignItems: "center",
    justifyContent: "center",
  },

  storyTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 17,
    color: COLORS.navy,
    textAlign: "right",
    marginTop: 10,
  },

  storyDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12.5,
    lineHeight: 20,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 5,
  },

  storyDetailsRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    marginTop: 13,
    gap: 8,
  },

  storyDetail: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 4,
  },

  storyDetailText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
  },

  detailDivider: {
    width: 3,
    height: 3,
    borderRadius: 2,
    backgroundColor: "#CDD1DA",
  },

  progressSection: {
    marginTop: 14,
  },

  progressTextRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginBottom: 7,
  },

  progressLabel: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10.5,
    color: COLORS.muted,
  },

  progressValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 10.5,
    color: COLORS.primary,
  },

  progressTrack: {
    height: 7,
    borderRadius: 5,
    backgroundColor: COLORS.border,
    overflow: "hidden",
  },

  progressFill: {
    height: "100%",
    borderRadius: 5,
  },

  storyActionButton: {
    height: 44,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    marginTop: 15,
  },

  completedActionButton: {
    backgroundColor: COLORS.greenSoft,
  },

  storyActionText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12.5,
    color: "#FFFFFF",
  },

  completedActionText: {
    color: COLORS.green,
  },

  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 40,
  },

  emptyIcon: {
    width: 70,
    height: 70,
    borderRadius: 24,
    backgroundColor: COLORS.primarySoft,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 13,
  },

  emptyTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 16,
    color: COLORS.navy,
  },

  emptyDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: COLORS.muted,
    textAlign: "center",
    marginTop: 5,
  },

  floatingButton: {
    position: "absolute",
    left: 20,
    bottom: 24,
    borderRadius: 23,
    shadowColor: COLORS.primary,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.28,
    shadowRadius: 12,
    elevation: 8,
  },

  floatingGradient: {
    width: 58,
    height: 58,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(28,34,48,0.38)",
    justifyContent: "flex-end",
  },

  modalContainer: {
    maxHeight: "92%",
    backgroundColor: COLORS.background,
    borderTopLeftRadius: 31,
    borderTopRightRadius: 31,
    overflow: "hidden",
  },

  modalHandle: {
    alignSelf: "center",
    width: 47,
    height: 5,
    borderRadius: 4,
    backgroundColor: "#D9DCE4",
    marginTop: 10,
    marginBottom: 5,
  },

  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    paddingTop: 9,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },

  closeButton: {
    width: 39,
    height: 39,
    borderRadius: 13,
    backgroundColor: COLORS.surface,
    alignItems: "center",
    justifyContent: "center",
  },

  modalHeaderText: {
    flex: 1,
    alignItems: "center",
  },

  modalTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 17,
    color: COLORS.navy,
  },

  modalSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11.5,
    color: COLORS.muted,
    marginTop: 2,
  },

  modalHeaderIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    backgroundColor: COLORS.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },

  modalScrollContent: {
    paddingHorizontal: 18,
    paddingTop: 19,
    paddingBottom: 35,
  },

  inputLabel: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: COLORS.navy,
    textAlign: "right",
    marginBottom: 10,
    marginTop: 3,
  },

  childrenContainer: {
    flexDirection: "row-reverse",
    gap: 10,
    paddingBottom: 22,
  },

  childCard: {
    width: 103,
    height: 122,
    borderRadius: 20,
    backgroundColor: COLORS.surface,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
  },

  activeChildCard: {
    borderColor: COLORS.primary,
    backgroundColor: "#FBFAFF",
  },

  childCheck: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 20,
    height: 20,
    borderRadius: 8,
    backgroundColor: COLORS.primary,
    alignItems: "center",
    justifyContent: "center",
  },

  childAvatar: {
    width: 48,
    height: 48,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 7,
  },

  childName: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.navy,
  },

  childAge: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    marginTop: 2,
  },

  topicSelectionGrid: {
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: 9,
    marginBottom: 22,
  },

  topicSelectionCard: {
    width: "48.5%",
    minHeight: 61,
    borderRadius: 16,
    backgroundColor: COLORS.surface,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 10,
    gap: 8,
  },

  smallTopicIcon: {
    width: 37,
    height: 37,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },

  topicSelectionText: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 11.5,
    color: COLORS.text,
    textAlign: "right",
  },

  goalInputContainer: {
    height: 57,
    borderRadius: 17,
    backgroundColor: COLORS.surface,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 14,
    gap: 9,
    marginBottom: 22,
  },

  goalInput: {
    flex: 1,
    height: "100%",
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: COLORS.text,
  },

  lengthContainer: {
    flexDirection: "row-reverse",
    gap: 8,
    marginBottom: 22,
  },

  lengthCard: {
    flex: 1,
    minHeight: 101,
    borderRadius: 18,
    backgroundColor: COLORS.surface,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
  },

  activeLengthCard: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primarySoft,
  },

  lengthTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
    color: COLORS.text,
    marginTop: 6,
  },

  activeLengthTitle: {
    color: COLORS.primary,
  },

  lengthDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10,
    color: COLORS.muted,
    marginTop: 2,
  },

  previewBox: {
    borderRadius: 18,
    backgroundColor: COLORS.yellowSoft,
    flexDirection: "row-reverse",
    alignItems: "flex-start",
    padding: 13,
    marginBottom: 17,
  },

  previewIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    backgroundColor: "rgba(255,255,255,0.70)",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 10,
  },

  previewTextContainer: {
    flex: 1,
    alignItems: "flex-end",
  },

  previewTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12.5,
    color: "#6B5523",
    textAlign: "right",
  },

  previewDescription: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    lineHeight: 18,
    color: "#8B7542",
    textAlign: "right",
    marginTop: 3,
  },

  generateButton: {
    borderRadius: 17,
    overflow: "hidden",
  },

  generateGradient: {
    height: 55,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  generateButtonText: {
    fontFamily: "Tajawal_900Black",
    fontSize: 14,
    color: "#FFFFFF",
  },

  demoNote: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    textAlign: "center",
    marginTop: 10,
  },
});