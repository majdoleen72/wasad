import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  Animated,
  Easing,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

type TaskStatus = "active" | "pending" | "completed";

type Task = {
  id: number;
  title: string;
  description: string;
  childName: string;
  childInitial: string;
  reward: number;
  date: string;
  status: TaskStatus;
  progress?: number;
  icon: keyof typeof Ionicons.glyphMap;
};

const COLORS = {
  background: "#F5F8FC",
  surface: "#FFFFFF",

  navy: "#19354F",
  navySoft: "#294C67",

  text: "#1D2E3E",
  muted: "#7B8995",
  lightMuted: "#A4AFB8",

  blue: "#639FE5",
  blueDark: "#497FC9",
  blueSoft: "#E9F3FF",

  teal: "#54BFAE",
  tealDark: "#389B8C",
  tealSoft: "#E5F8F4",

  coral: "#F28472",
  coralDark: "#DE6857",
  coralSoft: "#FFF0EC",

  yellow: "#F1C65B",
  yellowSoft: "#FFF7DC",

  green: "#43A981",
  greenSoft: "#E6F7EF",

  border: "#E6ECF1",
  white: "#FFFFFF",
};

const TASKS: Task[] = [
  {
    id: 1,
    title: "ترتيب الغرفة",
    description: "رتب السرير والألعاب وضع الملابس في مكانها",
    childName: "سلمان",
    childInitial: "س",
    reward: 15,
    date: "اليوم، 6:00 م",
    status: "active",
    progress: 40,
    icon: "bed-outline",
  },
  {
    id: 2,
    title: "قراءة عشر صفحات",
    description: "قراءة عشر صفحات من الكتاب المختار",
    childName: "ليان",
    childInitial: "ل",
    reward: 10,
    date: "غدًا، 8:00 م",
    status: "active",
    progress: 70,
    icon: "book-outline",
  },
  {
    id: 3,
    title: "ترتيب طاولة الطعام",
    description: "ترتيب الأطباق والملاعق بعد تناول الغداء",
    childName: "سلمان",
    childInitial: "س",
    reward: 20,
    date: "أُرسلت منذ 25 دقيقة",
    status: "pending",
    icon: "restaurant-outline",
  },
  {
    id: 4,
    title: "إنهاء الواجب المدرسي",
    description: "إكمال واجب الرياضيات وتسليمه",
    childName: "ليان",
    childInitial: "ل",
    reward: 12,
    date: "اكتملت أمس",
    status: "completed",
    icon: "school-outline",
  },
];

const TABS: {
  key: TaskStatus;
  label: string;
}[] = [
  {
    key: "active",
    label: "الحالية",
  },
  {
    key: "pending",
    label: "بانتظار الموافقة",
  },
  {
    key: "completed",
    label: "المكتملة",
  },
];

export default function TasksScreen() {
  const [selectedTab, setSelectedTab] =
    useState<TaskStatus>("active");

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  const headerAnimation = useRef(
    new Animated.Value(0)
  ).current;

  const contentAnimation = useRef(
    new Animated.Value(0)
  ).current;

  const buttonScale = useRef(
    new Animated.Value(1)
  ).current;

  const pendingPulse = useRef(
    new Animated.Value(1)
  ).current;

  const floatingShape = useRef(
    new Animated.Value(0)
  ).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(headerAnimation, {
        toValue: 1,
        duration: 550,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),

      Animated.timing(contentAnimation, {
        toValue: 1,
        duration: 700,
        delay: 130,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(floatingShape, {
          toValue: 1,
          duration: 2600,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),

        Animated.timing(floatingShape, {
          toValue: 0,
          duration: 2600,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(pendingPulse, {
          toValue: 1.025,
          duration: 900,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),

        Animated.timing(pendingPulse, {
          toValue: 1,
          duration: 900,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [
    contentAnimation,
    floatingShape,
    headerAnimation,
    pendingPulse,
  ]);

  const filteredTasks = useMemo(() => {
    return TASKS.filter(
      (task) => task.status === selectedTab
    );
  }, [selectedTab]);

  const activeCount = TASKS.filter(
    (task) => task.status === "active"
  ).length;

  const pendingCount = TASKS.filter(
    (task) => task.status === "pending"
  ).length;

  const completedCount = TASKS.filter(
    (task) => task.status === "completed"
  ).length;

  const handleCreatePressIn = () => {
    Animated.spring(buttonScale, {
      toValue: 0.97,
      useNativeDriver: true,
      speed: 30,
      bounciness: 4,
    }).start();
  };

  const handleCreatePressOut = () => {
    Animated.spring(buttonScale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 25,
      bounciness: 7,
    }).start();
  };

  const handleCreateTask = () => {
    console.log("الانتقال إلى صفحة إنشاء المهمة");
  };

  const handleReviewTask = (task: Task) => {
    console.log("مراجعة المهمة", task.id);
  };

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>
          جاري التحميل...
        </Text>
      </View>
    );
  }

  const headerTranslate = headerAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: [-20, 0],
  });

  const contentTranslate = contentAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: [28, 0],
  });

  const floatingTranslate = floatingShape.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 15],
  });

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor={COLORS.background}
      />

      <View style={styles.container}>
        {/* أشكال خلفية متحركة */}

        <Animated.View
          style={[
            styles.backgroundShapeOne,
            {
              transform: [
                {
                  translateY: floatingTranslate,
                },
              ],
            },
          ]}
        />

        <Animated.View
          style={[
            styles.backgroundShapeTwo,
            {
              transform: [
                {
                  translateY: Animated.multiply(
                    floatingTranslate,
                    -0.7
                  ),
                },
              ],
            },
          ]}
        />

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          {/* Header */}

          <Animated.View
            style={[
              styles.header,
              {
                opacity: headerAnimation,
                transform: [
                  {
                    translateY: headerTranslate,
                  },
                ],
              },
            ]}
          >
            <View style={styles.headerText}>
              <Text style={styles.pageTitle}>المهام</Text>

              <Text style={styles.pageSubtitle}>
                تابع إنجاز أطفالك ومكافآتهم
              </Text>
            </View>

            <TouchableOpacity
              activeOpacity={0.8}
              style={styles.notificationButton}
            >
              <LinearGradient
                colors={["#FFFFFF", "#EDF5FD"]}
                style={styles.notificationGradient}
              >
                <Ionicons
                  name="notifications-outline"
                  size={25}
                  color={COLORS.navy}
                />
              </LinearGradient>

              {pendingCount > 0 && (
                <View style={styles.notificationBadge}>
                  <Text style={styles.notificationBadgeText}>
                    {pendingCount}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          </Animated.View>

          <Animated.View
            style={{
              opacity: contentAnimation,
              transform: [
                {
                  translateY: contentTranslate,
                },
              ],
            }}
          >
            {/* Create Task */}

            <Animated.View
              style={{
                transform: [
                  {
                    scale: buttonScale,
                  },
                ],
              }}
            >
              <Pressable
                onPress={handleCreateTask}
                onPressIn={handleCreatePressIn}
                onPressOut={handleCreatePressOut}
              >
                <LinearGradient
                  colors={[
                    "#234E6C",
                    "#2A7181",
                    "#4CB7A7",
                  ]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.createTaskCard}
                >
                  <View style={styles.createCircleOne} />
                  <View style={styles.createCircleTwo} />

                  <View style={styles.createContent}>
                    <LinearGradient
                      colors={["#FFFFFF", "#E9FFF9"]}
                      style={styles.createIcon}
                    >
                      <Ionicons
                        name="add"
                        size={30}
                        color={COLORS.tealDark}
                      />
                    </LinearGradient>

                    <View style={styles.createTextContainer}>
                      <Text style={styles.createTitle}>
                        إنشاء مهمة جديدة
                      </Text>

                      <Text style={styles.createSubtitle}>
                        أضف مهمة وحدد الطفل والمكافأة
                      </Text>
                    </View>
                  </View>

                  <View style={styles.createArrow}>
                    <Ionicons
                      name="arrow-back"
                      size={20}
                      color={COLORS.white}
                    />
                  </View>
                </LinearGradient>
              </Pressable>
            </Animated.View>

            {/* Stats */}

            <View style={styles.statsRow}>
              <StatCard
                value={activeCount}
                label="مهام حالية"
                icon="flash-outline"
                colors={["#EAF4FF", "#D7EAFE"]}
                iconColor={COLORS.blueDark}
              />

              <Animated.View
                style={[
                  styles.statWrapper,
                  {
                    transform: [
                      {
                        scale: pendingPulse,
                      },
                    ],
                  },
                ]}
              >
                <StatCard
                  value={pendingCount}
                  label="تنتظر موافقتك"
                  icon="hourglass-outline"
                  colors={["#FFF4EF", "#FFE1D9"]}
                  iconColor={COLORS.coralDark}
                  important
                />
              </Animated.View>

              <StatCard
                value={completedCount}
                label="مكتملة"
                icon="checkmark-done-outline"
                colors={["#EBFAF6", "#D7F2E9"]}
                iconColor={COLORS.green}
              />
            </View>

            {/* Pending Notice */}

            {pendingCount > 0 && (
              <Animated.View
                style={{
                  transform: [
                    {
                      scale: pendingPulse,
                    },
                  ],
                }}
              >
                <TouchableOpacity
                  activeOpacity={0.86}
                  onPress={() => setSelectedTab("pending")}
                >
                  <LinearGradient
                    colors={["#FFF6F2", "#FFE8E1"]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.pendingBanner}
                  >
                    <View style={styles.pendingBannerIcon}>
                      <Ionicons
                        name="sparkles-outline"
                        size={23}
                        color={COLORS.coralDark}
                      />
                    </View>

                    <View style={styles.pendingBannerText}>
                      <Text style={styles.pendingBannerTitle}>
                        مهمة جديدة تنتظر مراجعتك
                      </Text>

                      <Text style={styles.pendingBannerSubtitle}>
                        راجع الإنجاز للموافقة وتحويل المكافأة
                      </Text>
                    </View>

                    <View style={styles.pendingBannerArrow}>
                      <Ionicons
                        name="chevron-back"
                        size={20}
                        color={COLORS.coralDark}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              </Animated.View>
            )}

            {/* Section */}

            <View style={styles.sectionHeader}>
              <View>
                <Text style={styles.sectionTitle}>
                  مهام الأطفال
                </Text>

                <Text style={styles.sectionSubtitle}>
                  كل المهام في مكان واحد
                </Text>
              </View>

              <View style={styles.countBubble}>
                <Text style={styles.countBubbleText}>
                  {filteredTasks.length}
                </Text>
              </View>
            </View>

            {/* Tabs */}

            <View style={styles.tabsContainer}>
              {TABS.map((tab) => {
                const selected = selectedTab === tab.key;

                return (
                  <TouchableOpacity
                    key={tab.key}
                    activeOpacity={0.8}
                    onPress={() => setSelectedTab(tab.key)}
                    style={styles.tabTouchable}
                  >
                    {selected ? (
                      <LinearGradient
                        colors={
                          tab.key === "pending"
                            ? ["#FF9A86", "#F27765"]
                            : tab.key === "completed"
                              ? ["#58C2AA", "#3FA18C"]
                              : ["#6BA8EC", "#4D86CE"]
                        }
                        style={styles.selectedTab}
                      >
                        <Text style={styles.selectedTabText}>
                          {tab.label}
                        </Text>

                        {tab.key === "pending" &&
                          pendingCount > 0 && (
                            <View
                              style={
                                styles.selectedTabCount
                              }
                            >
                              <Text
                                style={
                                  styles.selectedTabCountText
                                }
                              >
                                {pendingCount}
                              </Text>
                            </View>
                          )}
                      </LinearGradient>
                    ) : (
                      <View style={styles.normalTab}>
                        <Text style={styles.normalTabText}>
                          {tab.label}
                        </Text>
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Tasks */}

            <View style={styles.tasksList}>
              {filteredTasks.map((task, index) => (
                <AnimatedTaskCard
                  key={task.id}
                  task={task}
                  index={index}
                  onReview={() =>
                    handleReviewTask(task)
                  }
                />
              ))}
            </View>
          </Animated.View>

          <View style={styles.bottomSpace} />
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

type StatCardProps = {
  value: number;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  colors: readonly [string, string, ...string[]];
  iconColor: string;
  important?: boolean;
};

function StatCard({
  value,
  label,
  icon,
  colors,
  iconColor,
  important = false,
}: StatCardProps) {
  return (
    <View style={styles.statWrapper}>
      <LinearGradient
        colors={colors}
        style={[
          styles.statCard,
          important && styles.importantStatCard,
        ]}
      >
        <View
          style={[
            styles.statIcon,
            {
              backgroundColor: "rgba(255,255,255,0.72)",
            },
          ]}
        >
          <Ionicons
            name={icon}
            size={22}
            color={iconColor}
          />
        </View>

        <Text style={styles.statValue}>{value}</Text>

        <Text numberOfLines={2} style={styles.statLabel}>
          {label}
        </Text>
      </LinearGradient>
    </View>
  );
}

type AnimatedTaskCardProps = {
  task: Task;
  index: number;
  onReview: () => void;
};

function AnimatedTaskCard({
  task,
  index,
  onReview,
}: AnimatedTaskCardProps) {
  const animation = useRef(
    new Animated.Value(0)
  ).current;

  useEffect(() => {
    Animated.timing(animation, {
      toValue: 1,
      delay: index * 110,
      duration: 480,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [animation, index]);

  const translateY = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [24, 0],
  });

  const style = getTaskStyle(task.status);

  return (
    <Animated.View
      style={{
        opacity: animation,
        transform: [
          {
            translateY,
          },
        ],
      }}
    >
      <View style={styles.taskShadow}>
        <LinearGradient
          colors={["#FFFFFF", style.cardEnd]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.taskCard}
        >
          <View
            style={[
              styles.taskAccent,
              {
                backgroundColor: style.color,
              },
            ]}
          />

          <View style={styles.taskTopRow}>
            <LinearGradient
              colors={style.iconGradient}
              style={styles.taskIcon}
            >
              <Ionicons
                name={task.icon}
                size={25}
                color={style.color}
              />
            </LinearGradient>

            <View style={styles.taskInfo}>
              <View style={styles.taskTitleRow}>
                <Text
                  numberOfLines={1}
                  style={styles.taskTitle}
                >
                  {task.title}
                </Text>

                <View
                  style={[
                    styles.statusBadge,
                    {
                      backgroundColor: style.badgeBackground,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.statusText,
                      {
                        color: style.color,
                      },
                    ]}
                  >
                    {style.label}
                  </Text>
                </View>
              </View>

              <Text
                numberOfLines={2}
                style={styles.taskDescription}
              >
                {task.description}
              </Text>
            </View>
          </View>

          <View style={styles.taskMetaRow}>
            <View style={styles.metaItem}>
              <View
                style={[
                  styles.avatar,
                  {
                    backgroundColor:
                      style.badgeBackground,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.avatarText,
                    {
                      color: style.color,
                    },
                  ]}
                >
                  {task.childInitial}
                </Text>
              </View>

              <View>
                <Text style={styles.metaLabel}>الطفل</Text>

                <Text style={styles.metaValue}>
                  {task.childName}
                </Text>
              </View>
            </View>

            <View style={styles.metaDivider} />

            <View style={styles.metaItem}>
              <View style={styles.rewardIcon}>
                <Ionicons
                  name="wallet-outline"
                  size={18}
                  color="#D5A42C"
                />
              </View>

              <View>
                <Text style={styles.metaLabel}>
                  المكافأة
                </Text>

                <Text style={styles.metaValue}>
                  {task.reward} ر.س
                </Text>
              </View>
            </View>
          </View>

          {task.status === "active" && (
            <View style={styles.progressSection}>
              <View style={styles.progressTop}>
                <View style={styles.dateRow}>
                  <Ionicons
                    name="calendar-outline"
                    size={16}
                    color={COLORS.muted}
                  />

                  <Text style={styles.dateText}>
                    {task.date}
                  </Text>
                </View>

                <Text
                  style={[
                    styles.progressPercentage,
                    {
                      color: style.color,
                    },
                  ]}
                >
                  {task.progress}%
                </Text>
              </View>

              <View style={styles.progressTrack}>
                <LinearGradient
                  colors={style.progressGradient}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[
                    styles.progressFill,
                    {
                      width: `${Math.max(0, Math.min(100, task.progress ?? 0))}%` as `${number}%`,
                    },
                  ]}
                />
              </View>
            </View>
          )}

          {task.status === "pending" && (
            <View style={styles.pendingFooter}>
              <View style={styles.pendingTimeRow}>
                <Ionicons
                  name="time-outline"
                  size={18}
                  color={COLORS.coralDark}
                />

                <Text style={styles.pendingTimeText}>
                  {task.date}
                </Text>
              </View>

              <TouchableOpacity
                activeOpacity={0.85}
                onPress={onReview}
              >
                <LinearGradient
                  colors={["#FF927F", "#E96D5C"]}
                  style={styles.reviewButton}
                >
                  <Text style={styles.reviewButtonText}>
                    مراجعة الإنجاز
                  </Text>

                  <Ionicons
                    name="arrow-back"
                    size={17}
                    color={COLORS.white}
                  />
                </LinearGradient>
              </TouchableOpacity>
            </View>
          )}

          {task.status === "completed" && (
            <LinearGradient
              colors={["#EFFAF6", "#E0F5EC"]}
              style={styles.completedFooter}
            >
              <View style={styles.completedMessage}>
                <View style={styles.completedCheck}>
                  <Ionicons
                    name="checkmark"
                    size={17}
                    color={COLORS.white}
                  />
                </View>

                <View>
                  <Text style={styles.completedTitle}>
                    تمت الموافقة وتحويل المكافأة
                  </Text>

                  <Text style={styles.completedDate}>
                    {task.date}
                  </Text>
                </View>
              </View>

              <Text style={styles.completedAmount}>
                +{task.reward} ر.س
              </Text>
            </LinearGradient>
          )}
        </LinearGradient>
      </View>
    </Animated.View>
  );
}

function getTaskStyle(status: TaskStatus) {
  if (status === "pending") {
    return {
      color: COLORS.coralDark,
      label: "تحتاج مراجعة",
      cardEnd: "#FFF9F7",
      badgeBackground: "#FFE8E2",
      iconGradient: ["#FFF1ED", "#FFE2DB"] as const,
      progressGradient: ["#FF9A86", "#EC715F"] as const,
    };
  }

  if (status === "completed") {
    return {
      color: COLORS.green,
      label: "مكتملة",
      cardEnd: "#F8FFFC",
      badgeBackground: "#E1F5EC",
      iconGradient: ["#EAF9F3", "#D9F2E8"] as const,
      progressGradient: ["#55C19F", "#3DA47F"] as const,
    };
  }

  return {
    color: COLORS.blueDark,
    label: "قيد التنفيذ",
    cardEnd: "#F8FBFF",
    badgeBackground: "#E4F0FF",
    iconGradient: ["#EEF6FF", "#DDEEFF"] as const,
    progressGradient: ["#75B5F2", "#4A82CC"] as const,
  };
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    overflow: "hidden",
  },

  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.background,
  },

  loadingText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 16,
    color: COLORS.navy,
  },

  backgroundShapeOne: {
    position: "absolute",
    width: 210,
    height: 210,
    borderRadius: 105,
    backgroundColor: "#DDEEFF",
    top: -110,
    right: -85,
    opacity: 0.65,
  },

  backgroundShapeTwo: {
    position: "absolute",
    width: 170,
    height: 170,
    borderRadius: 85,
    backgroundColor: "#DFF7F0",
    top: 335,
    left: -110,
    opacity: 0.7,
  },

  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 14,
  },

  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 22,
  },

  headerText: {
    flex: 1,
    alignItems: "flex-end",
  },

  pageTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 33,
    lineHeight: 43,
    color: COLORS.navy,
    textAlign: "right",
  },

  pageSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 16,
    lineHeight: 23,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: -2,
  },

  notificationButton: {
    width: 50,
    height: 50,
    marginRight: 14,
  },

  notificationGradient: {
    width: "100%",
    height: "100%",
    borderRadius: 17,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: COLORS.border,
  },

  notificationBadge: {
    position: "absolute",
    top: -4,
    right: -4,
    minWidth: 21,
    height: 21,
    borderRadius: 11,
    paddingHorizontal: 5,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.coral,
    borderWidth: 2,
    borderColor: COLORS.background,
  },

  notificationBadgeText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 10,
    color: COLORS.white,
  },

  createTaskCard: {
    minHeight: 112,
    borderRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 18,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    overflow: "hidden",
    marginBottom: 18,

    shadowColor: "#19354F",
    shadowOpacity: 0.24,
    shadowRadius: 14,
    shadowOffset: {
      width: 0,
      height: 8,
    },

    elevation: 7,
  },

  createCircleOne: {
    position: "absolute",
    width: 135,
    height: 135,
    borderRadius: 68,
    backgroundColor: "rgba(255,255,255,0.08)",
    top: -70,
    left: -40,
  },

  createCircleTwo: {
    position: "absolute",
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "rgba(255,255,255,0.07)",
    bottom: -45,
    right: 25,
  },

  createContent: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
    zIndex: 2,
  },

  createIcon: {
    width: 57,
    height: 57,
    borderRadius: 19,
    justifyContent: "center",
    alignItems: "center",
  },

  createTextContainer: {
    flex: 1,
    marginRight: 14,
  },

  createTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 20,
    lineHeight: 28,
    color: COLORS.white,
    textAlign: "right",
  },

  createSubtitle: {
    fontFamily: "Tajawal_400Regular",
    fontSize: 14,
    lineHeight: 21,
    color: "#E2F3F1",
    textAlign: "right",
    marginTop: 2,
  },

  createArrow: {
    width: 39,
    height: 39,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.14)",
    zIndex: 2,
  },

  statsRow: {
    flexDirection: "row-reverse",
    gap: 10,
    marginBottom: 18,
  },

  statWrapper: {
    flex: 1,
  },

  statCard: {
    minHeight: 126,
    borderRadius: 21,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 8,
    paddingVertical: 13,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.8)",
  },

  importantStatCard: {
    shadowColor: COLORS.coral,
    shadowOpacity: 0.16,
    shadowRadius: 10,
    shadowOffset: {
      width: 0,
      height: 5,
    },
    elevation: 4,
  },

  statIcon: {
    width: 41,
    height: 41,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 7,
  },

  statValue: {
    fontFamily: "Tajawal_900Black",
    fontSize: 25,
    lineHeight: 31,
    color: COLORS.navy,
  },

  statLabel: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12.5,
    lineHeight: 18,
    color: COLORS.navySoft,
    textAlign: "center",
  },

  pendingBanner: {
    minHeight: 83,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 13,
    flexDirection: "row-reverse",
    alignItems: "center",
    marginBottom: 24,
    borderWidth: 1,
    borderColor: "#FFD8CF",
  },

  pendingBannerIcon: {
    width: 47,
    height: 47,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.8)",
  },

  pendingBannerText: {
    flex: 1,
    marginHorizontal: 12,
  },

  pendingBannerTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15.5,
    lineHeight: 22,
    color: COLORS.navy,
    textAlign: "right",
  },

  pendingBannerSubtitle: {
    fontFamily: "Tajawal_400Regular",
    fontSize: 12.5,
    lineHeight: 19,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 1,
  },

  pendingBannerArrow: {
    width: 36,
    height: 36,
    borderRadius: 13,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.7)",
  },

  sectionHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 13,
  },

  sectionTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 22,
    lineHeight: 29,
    color: COLORS.navy,
    textAlign: "right",
  },

  sectionSubtitle: {
    fontFamily: "Tajawal_400Regular",
    fontSize: 13,
    color: COLORS.muted,
    textAlign: "right",
  },

  countBubble: {
    minWidth: 41,
    height: 41,
    borderRadius: 15,
    backgroundColor: COLORS.blueSoft,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 10,
  },

  countBubbleText: {
    fontFamily: "Tajawal_900Black",
    fontSize: 17,
    color: COLORS.blueDark,
  },

  tabsContainer: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: "#EAF0F5",
    borderRadius: 19,
    padding: 4,
    marginBottom: 17,
  },

  tabTouchable: {
    flex: 1,
  },

  selectedTab: {
    minHeight: 46,
    borderRadius: 15,
    paddingHorizontal: 5,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
  },

  normalTab: {
    minHeight: 46,
    borderRadius: 15,
    paddingHorizontal: 5,
    alignItems: "center",
    justifyContent: "center",
  },

  selectedTabText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12.5,
    color: COLORS.white,
    textAlign: "center",
  },

  normalTabText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12.5,
    color: COLORS.muted,
    textAlign: "center",
  },

  selectedTabCount: {
    minWidth: 19,
    height: 19,
    borderRadius: 10,
    paddingHorizontal: 4,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.white,
  },

  selectedTabCountText: {
    fontFamily: "Tajawal_900Black",
    fontSize: 9,
    color: COLORS.coralDark,
  },

  tasksList: {
    gap: 14,
  },

  taskShadow: {
    shadowColor: "#213A4E",
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    elevation: 4,
  },

  taskCard: {
    position: "relative",
    borderRadius: 22,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(226,234,240,0.9)",
    overflow: "hidden",
  },

  taskAccent: {
    position: "absolute",
    right: 0,
    top: 18,
    bottom: 18,
    width: 4,
    borderTopLeftRadius: 4,
    borderBottomLeftRadius: 4,
  },

  taskTopRow: {
    flexDirection: "row-reverse",
    alignItems: "flex-start",
  },

  taskIcon: {
    width: 53,
    height: 53,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 12,
  },

  taskInfo: {
    flex: 1,
  },

  taskTitleRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },

  taskTitle: {
    flex: 1,
    fontFamily: "Tajawal_900Black",
    fontSize: 18,
    lineHeight: 25,
    color: COLORS.text,
    textAlign: "right",
  },

  statusBadge: {
    borderRadius: 10,
    paddingHorizontal: 9,
    paddingVertical: 5,
  },

  statusText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10.5,
  },

  taskDescription: {
    fontFamily: "Tajawal_400Regular",
    fontSize: 13.5,
    lineHeight: 21,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 5,
  },

  taskMetaRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: "rgba(247,250,252,0.85)",
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 11,
    marginTop: 15,
  },

  metaItem: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
  },

  avatar: {
    width: 38,
    height: 38,
    borderRadius: 13,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 9,
  },

  avatarText: {
    fontFamily: "Tajawal_900Black",
    fontSize: 17,
  },

  metaLabel: {
    fontFamily: "Tajawal_400Regular",
    fontSize: 11,
    color: COLORS.lightMuted,
    textAlign: "right",
  },

  metaValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: COLORS.text,
    textAlign: "right",
    marginTop: 1,
  },

  metaDivider: {
    width: 1,
    height: 36,
    backgroundColor: COLORS.border,
    marginHorizontal: 10,
  },

  rewardIcon: {
    width: 38,
    height: 38,
    borderRadius: 13,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.yellowSoft,
    marginLeft: 9,
  },

  progressSection: {
    marginTop: 15,
  },

  progressTop: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },

  dateRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
  },

  dateText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12.5,
    color: COLORS.muted,
  },

  progressPercentage: {
    fontFamily: "Tajawal_900Black",
    fontSize: 13,
  },

  progressTrack: {
    height: 8,
    borderRadius: 5,
    backgroundColor: "#DDE8F2",
    overflow: "hidden",
  },

  progressFill: {
    height: "100%",
    borderRadius: 5,
  },

  pendingFooter: {
    marginTop: 15,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },

  pendingTimeRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    marginBottom: 11,
  },

  pendingTimeText: {
    fontFamily: "Tajawal_600SemiBold",
    fontSize: 12.5,
    color: COLORS.muted,
  },

  reviewButton: {
    minHeight: 47,
    borderRadius: 15,
    flexDirection: "row-reverse",
    justifyContent: "center",
    alignItems: "center",
    gap: 7,
  },

  reviewButtonText: {
    fontFamily: "Tajawal_900Black",
    fontSize: 14,
    color: COLORS.white,
  },

  completedFooter: {
    marginTop: 15,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 12,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },

  completedMessage: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
  },

  completedCheck: {
    width: 36,
    height: 36,
    borderRadius: 13,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.green,
    marginLeft: 9,
  },

  completedTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12.5,
    color: COLORS.green,
    textAlign: "right",
  },

  completedDate: {
    fontFamily: "Tajawal_400Regular",
    fontSize: 11,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 1,
  },

  completedAmount: {
    fontFamily: "Tajawal_900Black",
    fontSize: 17,
    color: COLORS.green,
  },

  bottomSpace: {
    height: 125,
  },
});