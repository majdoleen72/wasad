import React, { useState } from "react";
import {
  Modal,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  Tajawal_400Regular,
  Tajawal_500Medium,
  Tajawal_700Bold,
  Tajawal_800ExtraBold,
  Tajawal_900Black,
  useFonts,
} from "@expo-google-fonts/tajawal";

const COLORS = {
  background: "#FFF8F5",
  surface: "#FFFFFF",
  text: "#352620",
  muted: "#917E76",
  coral: "#F47160",
  coralDark: "#D85242",
  coralSoft: "#FFE7E1",
  orange: "#F5A24C",
  border: "#F1E4DF",
};

type Goal = {
  id: number;
  title: string;
  saved: number;
  target: number;
  icon: keyof typeof Ionicons.glyphMap;
  remaining: string;
};

const INITIAL_GOALS: Goal[] = [
  {
    id: 1,
    title: "شراء دراجة جديدة",
    saved: 340,
    target: 500,
    icon: "bicycle-outline",
    remaining: "160 ر.س متبقية",
  },
  {
    id: 2,
    title: "جهاز لوحي للدراسة",
    saved: 260,
    target: 900,
    icon: "tablet-portrait-outline",
    remaining: "640 ر.س متبقية",
  },
  {
    id: 3,
    title: "هدية لأمي",
    saved: 80,
    target: 150,
    icon: "gift-outline",
    remaining: "70 ر.س متبقية",
  },
];

export default function GoalsScreen() {
  const [goals, setGoals] = useState<Goal[]>(INITIAL_GOALS);
  const [showModal, setShowModal] = useState(false);
  const [goalName, setGoalName] = useState("");
  const [target, setTarget] = useState("");

  const [fontsLoaded] = useFonts({
    Tajawal_400Regular,
    Tajawal_500Medium,
    Tajawal_700Bold,
    Tajawal_800ExtraBold,
    Tajawal_900Black,
  });

  if (!fontsLoaded) {
    return <View style={styles.loading} />;
  }

  const totalSaved = goals.reduce((sum, goal) => sum + goal.saved, 0);
  const totalTargets = goals.reduce((sum, goal) => sum + goal.target, 0);

  const createGoal = () => {
    const targetAmount = Number(target);

    if (!goalName.trim() || !targetAmount) {
      return;
    }

    setGoals((current) => [
      {
        id: Date.now(),
        title: goalName.trim(),
        saved: 0,
        target: targetAmount,
        icon: "flag-outline",
        remaining: `${targetAmount} ر.س متبقية`,
      },
      ...current,
    ]);

    setGoalName("");
    setTarget("");
    setShowModal(false);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.replace("/parent/financial")}>
            <Ionicons name="arrow-forward" size={22} color={COLORS.text} />
          </TouchableOpacity>

          <View style={styles.headerText}>
            <Text style={styles.pageTitle}>أهداف الطفل</Text>
            <Text style={styles.pageSubtitle}>
              تابعي رحلة الطفل حتى يحقق ما يتمناه
            </Text>
          </View>
        </View>

        <LinearGradient
          colors={["#D95644", "#F2735F", "#FFAE78"]}
          start={{ x: 0, y: 1 }}
          end={{ x: 1, y: 0 }}
          style={styles.heroCard}
        >
          <GoalPathBackground />

          <View style={styles.heroIcon}>
            <Ionicons name="flag" size={25} color="#FFFFFF" />
          </View>

          <Text style={styles.heroLabel}>إجمالي ما ادخره الطفل لأهدافه</Text>

          <View style={styles.heroAmountRow}>
            <Text style={styles.heroAmount}>
              {totalSaved.toLocaleString("ar-SA")}
            </Text>
            <Text style={styles.heroCurrency}>ر.س</Text>
          </View>

          <Text style={styles.heroTarget}>
            من أصل {totalTargets.toLocaleString("ar-SA")} ر.س
          </Text>

          <View style={styles.heroStats}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{goals.length}</Text>
              <Text style={styles.heroStatLabel}>أهداف نشطة</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>68%</Text>
              <Text style={styles.heroStatLabel}>أقرب هدف</Text>
            </View>

            <View style={styles.heroDivider} />

            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>+90</Text>
              <Text style={styles.heroStatLabel}>هذا الشهر</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.tipCard}>
          <View style={styles.tipIcon}>
            <Ionicons name="bulb" size={21} color={COLORS.orange} />
          </View>

          <View style={styles.tipContent}>
            <Text style={styles.tipTitle}>خطوة صغيرة تصنع فرقًا</Text>
            <Text style={styles.tipText}>
              يمكن تحويل جزء من مكافآت المهام تلقائيًا إلى أقرب هدف للطفل.
            </Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>الأهداف الحالية</Text>
            <Text style={styles.sectionSubtitle}>مرتبة حسب نسبة الإنجاز</Text>
          </View>

          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowModal(true)}
          >
            <Ionicons name="add" size={19} color="#FFFFFF" />
            <Text style={styles.addButtonText}>هدف جديد</Text>
          </TouchableOpacity>
        </View>

        {goals.map((goal) => {
          const percentage = Math.min(
            Math.round((goal.saved / goal.target) * 100),
            100
          );

          return (
            <View style={styles.goalCard} key={goal.id}>
              <View style={styles.goalHeader}>
                <View style={styles.goalTitleRow}>
                  <View style={styles.goalIcon}>
                    <Ionicons
                      name={goal.icon}
                      size={23}
                      color={COLORS.coralDark}
                    />
                  </View>

                  <View>
                    <Text style={styles.goalTitle}>{goal.title}</Text>
                    <Text style={styles.goalRemaining}>{goal.remaining}</Text>
                  </View>
                </View>

                <View style={styles.percentageBadge}>
                  <Text style={styles.percentageText}>{percentage}%</Text>
                </View>
              </View>

              <View style={styles.goalAmounts}>
                <Text style={styles.savedAmount}>{goal.saved} ر.س</Text>
                <Text style={styles.targetAmount}>من {goal.target} ر.س</Text>
              </View>

              <View style={styles.progressTrack}>
                <LinearGradient
                  colors={["#D95644", "#FF9A76"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[styles.progressFill, { width: `${percentage}%` }]}
                />
              </View>

              <View style={styles.goalFooter}>
                <TouchableOpacity style={styles.contributeButton}>
                  <Ionicons name="add-circle" size={17} color="#FFFFFF" />
                  <Text style={styles.contributeText}>إضافة مبلغ</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.detailsButton}>
                  <Text style={styles.detailsText}>تفاصيل الهدف</Text>
                  <Ionicons
                    name="chevron-back"
                    size={17}
                    color={COLORS.coralDark}
                  />
                </TouchableOpacity>
              </View>
            </View>
          );
        })}

        <View style={styles.bottomSpace} />
      </ScrollView>

      <Modal
        visible={showModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />

            <View style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.modalClose}
                onPress={() => setShowModal(false)}
              >
                <Ionicons name="close" size={21} color={COLORS.text} />
              </TouchableOpacity>

              <View>
                <Text style={styles.modalTitle}>إنشاء هدف جديد</Text>
                <Text style={styles.modalSubtitle}>
                  حددي ما يريد الطفل الادخار له
                </Text>
              </View>
            </View>

            <Text style={styles.inputLabel}>اسم الهدف</Text>
            <TextInput
              value={goalName}
              onChangeText={setGoalName}
              placeholder="مثال: شراء دراجة"
              placeholderTextColor="#AA9992"
              style={styles.input}
              textAlign="right"
            />

            <Text style={styles.inputLabel}>المبلغ المطلوب</Text>

            <View style={styles.amountInputBox}>
              <TextInput
                value={target}
                onChangeText={setTarget}
                placeholder="500"
                placeholderTextColor="#AA9992"
                keyboardType="numeric"
                style={styles.amountInput}
                textAlign="right"
              />

              <Text style={styles.currency}>ر.س</Text>
            </View>

            <TouchableOpacity style={styles.confirmButton} onPress={createGoal}>
              <LinearGradient
                colors={["#D95644", "#F2735F"]}
                style={styles.confirmGradient}
              >
                <Text style={styles.confirmText}>إنشاء الهدف</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function GoalPathBackground() {
  return (
    <View pointerEvents="none" style={styles.pathBackground}>
      <View style={[styles.pathSegment, styles.pathOne]} />
      <View style={[styles.pathSegment, styles.pathTwo]} />
      <View style={[styles.pathSegment, styles.pathThree]} />
      <View style={[styles.pathSegment, styles.pathFour]} />

      <View style={[styles.pathDot, styles.goalDotOne]} />
      <View style={[styles.pathDot, styles.goalDotTwo]} />
      <View style={[styles.pathDot, styles.goalDotThree]} />

      <Ionicons
        name="flag"
        size={39}
        color="rgba(255,255,255,0.22)"
        style={styles.goalFlag}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loading: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  backButton: {
    width: 46,
    height: 46,
    borderRadius: 15,
    backgroundColor: COLORS.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerText: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 13,
  },
  pageTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 27,
    color: COLORS.text,
  },
  pageSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 12,
    color: COLORS.muted,
    marginTop: 3,
  },
  heroCard: {
    minHeight: 295,
    borderRadius: 29,
    padding: 21,
    overflow: "hidden",
    marginBottom: 15,
  },
  pathBackground: {
    ...StyleSheet.absoluteFill,
  },
  pathSegment: {
    position: "absolute",
    height: 5,
    borderRadius: 4,
    backgroundColor: "rgba(255,255,255,0.17)",
  },
  pathOne: {
    width: 90,
    left: -15,
    bottom: 44,
    transform: [{ rotate: "-25deg" }],
  },
  pathTwo: {
    width: 94,
    left: 60,
    bottom: 72,
    transform: [{ rotate: "33deg" }],
  },
  pathThree: {
    width: 92,
    left: 139,
    bottom: 106,
    transform: [{ rotate: "-25deg" }],
  },
  pathFour: {
    width: 132,
    right: -20,
    bottom: 143,
    transform: [{ rotate: "37deg" }],
  },
  pathDot: {
    position: "absolute",
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: "rgba(255,255,255,0.35)",
    borderWidth: 3,
    borderColor: "rgba(255,255,255,0.12)",
  },
  goalDotOne: {
    left: 51,
    bottom: 58,
  },
  goalDotTwo: {
    left: 136,
    bottom: 96,
  },
  goalDotThree: {
    left: 217,
    bottom: 126,
  },
  goalFlag: {
    position: "absolute",
    right: 19,
    bottom: 165,
  },
  heroIcon: {
    width: 48,
    height: 48,
    borderRadius: 17,
    backgroundColor: "rgba(255,255,255,0.17)",
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "flex-end",
  },
  heroLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 13,
    color: "rgba(255,255,255,0.76)",
    textAlign: "right",
    marginTop: 23,
  },
  heroAmountRow: {
    flexDirection: "row-reverse",
    alignItems: "flex-end",
    gap: 7,
  },
  heroAmount: {
    fontFamily: "Tajawal_900Black",
    fontSize: 39,
    color: "#FFFFFF",
  },
  heroCurrency: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 15,
    color: "rgba(255,255,255,0.85)",
    marginBottom: 8,
  },
  heroTarget: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: "rgba(255,255,255,0.72)",
    textAlign: "right",
  },
  heroStats: {
    flexDirection: "row-reverse",
    backgroundColor: "rgba(255,255,255,0.13)",
    borderRadius: 18,
    paddingVertical: 13,
    marginTop: 28,
  },
  heroStat: {
    flex: 1,
    alignItems: "center",
  },
  heroStatValue: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: "#FFFFFF",
  },
  heroStatLabel: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 9.5,
    color: "rgba(255,255,255,0.68)",
    marginTop: 2,
  },
  heroDivider: {
    width: 1,
    height: 37,
    backgroundColor: "rgba(255,255,255,0.18)",
  },
  tipCard: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: COLORS.surface,
    borderRadius: 19,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 24,
  },
  tipIcon: {
    width: 43,
    height: 43,
    borderRadius: 15,
    backgroundColor: "#FFF1DE",
    alignItems: "center",
    justifyContent: "center",
  },
  tipContent: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 11,
  },
  tipTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 13,
    color: COLORS.text,
  },
  tipText: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    textAlign: "right",
    lineHeight: 17,
    marginTop: 2,
  },
  sectionHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 13,
  },
  sectionTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 19,
    color: COLORS.text,
    textAlign: "right",
  },
  sectionSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    marginTop: 2,
    textAlign: "right",
  },
  addButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.coral,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 13,
  },
  addButtonText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: "#FFFFFF",
  },
  goalCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 23,
    padding: 16,
    marginBottom: 13,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  goalHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },
  goalTitleRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  goalIcon: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: COLORS.coralSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  goalTitle: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 14,
    color: COLORS.text,
    textAlign: "right",
  },
  goalRemaining: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 10.5,
    color: COLORS.muted,
    marginTop: 2,
    textAlign: "right",
  },
  percentageBadge: {
    backgroundColor: COLORS.coralSoft,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 11,
  },
  percentageText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 12,
    color: COLORS.coralDark,
  },
  goalAmounts: {
    flexDirection: "row-reverse",
    alignItems: "center",
    marginTop: 17,
  },
  savedAmount: {
    fontFamily: "Tajawal_900Black",
    fontSize: 19,
    color: COLORS.text,
  },
  targetAmount: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    marginRight: 6,
  },
  progressTrack: {
    height: 9,
    borderRadius: 5,
    backgroundColor: "#F4E3DE",
    overflow: "hidden",
    marginTop: 9,
  },
  progressFill: {
    height: "100%",
    borderRadius: 5,
  },
  goalFooter: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 15,
  },
  contributeButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 5,
    backgroundColor: COLORS.coral,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 12,
  },
  contributeText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 10.5,
    color: "#FFFFFF",
  },
  detailsButton: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 2,
  },
  detailsText: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 11,
    color: COLORS.coralDark,
  },
  bottomSpace: {
    height: 80,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(50,32,25,0.4)",
  },
  modalCard: {
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingTop: 11,
    paddingBottom: 30,
  },
  modalHandle: {
    width: 52,
    height: 5,
    borderRadius: 3,
    backgroundColor: "#E5D9D4",
    alignSelf: "center",
    marginBottom: 17,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 23,
  },
  modalClose: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "#FAF3F0",
    alignItems: "center",
    justifyContent: "center",
  },
  modalTitle: {
    fontFamily: "Tajawal_900Black",
    fontSize: 22,
    color: COLORS.text,
    textAlign: "right",
  },
  modalSubtitle: {
    fontFamily: "Tajawal_500Medium",
    fontSize: 11,
    color: COLORS.muted,
    textAlign: "right",
    marginTop: 2,
  },
  inputLabel: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 13,
    color: COLORS.text,
    textAlign: "right",
    marginBottom: 8,
    marginTop: 4,
  },
  input: {
    height: 55,
    borderRadius: 16,
    backgroundColor: "#FCF7F5",
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 14,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 15,
  },
  amountInputBox: {
    height: 55,
    flexDirection: "row-reverse",
    alignItems: "center",
    borderRadius: 16,
    backgroundColor: "#FCF7F5",
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 14,
  },
  amountInput: {
    flex: 1,
    fontFamily: "Tajawal_700Bold",
    fontSize: 14,
    color: COLORS.text,
  },
  currency: {
    fontFamily: "Tajawal_700Bold",
    fontSize: 12,
    color: COLORS.coralDark,
  },
  confirmButton: {
    borderRadius: 17,
    overflow: "hidden",
    marginTop: 23,
  },
  confirmGradient: {
    height: 55,
    alignItems: "center",
    justifyContent: "center",
  },
  confirmText: {
    fontFamily: "Tajawal_800ExtraBold",
    fontSize: 15,
    color: "#FFFFFF",
  },
});